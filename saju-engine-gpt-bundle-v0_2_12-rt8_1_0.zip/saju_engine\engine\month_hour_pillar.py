"""Step 7 — 월주·시주 + 원국 조립 (§A4·§A6·§⑥ / ASK1 §4·§6). tier1 chart 잠금 이정표.

- 월주: prev_jie(boundary_dt)(≤ 소유 — D-011와 동일 의미론) → 월지(§A4 매핑),
  월간 = 오호둔[년간] 기준 寅月 천간 + (월지idx−2) 오프셋 (§⑥-1).
- 시주: 시지 = hour_branch_natal(solar_dt) (정본 D-026), 시간 = 오서둔[일간] 기준 子時 천간 + 시지idx (§⑥-2).
- 조립(four_pillars): TimeContext의 세 시각이 각자 제 기둥으로 — clock→일주, boundary→년·월주,
  solar→시주. S1·S4가 조립 수준에서도 시그니처로 강제된다. Condition B는 hour=None 전파(S6).
- 모듈 명명: 조립자는 본 파일 내 four_pillars로 — Step 1 스텁 명명 유지(A6 회피, D-028).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Union

from saju_engine.assets.lookup.dun import WUHU_YIN_MONTH_STEM, WUSHU_ZI_HOUR_STEM
from saju_engine.assets.solar_terms import JIE_TO_MONTH_BRANCH, SolarTerms
from saju_engine.constants import BRANCHES, BRANCH_INDEX, STEM_INDEX, STEMS, sexagenary_from_index
from saju_engine.engine.day_pillar import DayPillarResult, day_pillar_for_birth
from saju_engine.engine.hour_branch import hour_branch_natal
from saju_engine.engine.year_pillar import YearPillarResult, year_pillar_for_birth
from saju_engine.constants import DayBoundaryRule
from saju_engine.timecontext import TimeContext


@dataclass(frozen=True)
class MonthPillarResult:
    ganji: str
    index: int                 # 60갑자 인덱스
    ref_jie: str               # 월령 소유 節
    ref_jie_dt: datetime


@dataclass(frozen=True)
class HourPillarResult:
    ganji: str
    branch: str
    stem: str


def month_pillar_for_birth(boundary_dt: datetime, year_stem: str, st: SolarTerms) -> MonthPillarResult:
    jie, jdt = st.prev_jie(boundary_dt)
    branch = JIE_TO_MONTH_BRANCH[jie]
    yin_stem = WUHU_YIN_MONTH_STEM[year_stem]
    stem = STEMS[(STEM_INDEX[yin_stem] + (BRANCH_INDEX[branch] - 2) % 12) % 10]
    ganji = stem + branch
    idx = next(i for i in range(60) if sexagenary_from_index(i) == ganji)
    return MonthPillarResult(ganji=ganji, index=idx, ref_jie=jie, ref_jie_dt=jdt)


def hour_pillar_for_birth(solar_dt: datetime, day_stem: str) -> HourPillarResult:
    branch = hour_branch_natal(solar_dt)
    stem = STEMS[(STEM_INDEX[WUSHU_ZI_HOUR_STEM[day_stem]] + BRANCH_INDEX[branch]) % 10]
    return HourPillarResult(ganji=stem + branch, branch=branch, stem=stem)


def hour_ganji_table(day_stem: str) -> list:
    """오서둔 12시진 간지 표 (子→亥, 지지 index 순) — D-051: ASK 13 시간대 가이드 전사 공급.
    산식은 hour_pillar_for_birth와 동일(§⑥-2 — 子時干 + 시지idx). 시지 결정 없이 표 전개만 —
    단일 정의 원칙(S8) 준수: 오프셋 공식을 emitter에 복제하지 않기 위해 본 모듈이 소유한다."""
    zi = STEM_INDEX[WUSHU_ZI_HOUR_STEM[day_stem]]
    return [STEMS[(zi + i) % 10] + BRANCHES[i] for i in range(12)]


@dataclass(frozen=True)
class FourPillars:
    year: YearPillarResult
    month: MonthPillarResult
    day: DayPillarResult
    hour: Optional[HourPillarResult]   # Condition B → None (S6)

    @property
    def ganji(self):
        return (self.year.ganji, self.month.ganji, self.day.ganji,
                self.hour.ganji if self.hour else None)


def four_pillars(tc: TimeContext, st: SolarTerms,
                 *, day_boundary_rule: Union[str, DayBoundaryRule] = DayBoundaryRule.midnight) -> FourPillars:
    """원국 조립 — 시각 3종이 각자 제 기둥만 결정한다 (S1·S4 조립 수준 강제)."""
    day = day_pillar_for_birth(tc.clock_dt, rule=day_boundary_rule)
    year = year_pillar_for_birth(tc.boundary_dt, st)
    month = month_pillar_for_birth(tc.boundary_dt, year.ganji[0], st)
    hour = hour_pillar_for_birth(tc.solar_dt, day.ganji[0]) if tc.solar_dt is not None else None
    return FourPillars(year=year, month=month, day=day, hour=hour)
