#!/usr/bin/env python3
"""module_manifest 생성기 + STAGE CONTRACT 정합 검증 (CI 게이트).

ask_modules.md의 <ASK N> 블록 머리에 있는 ```stage-contract``` 펜스 헤더를
유일 SoT로 파싱해 module_manifest.json을 생성한다. 헤더가 곧 진실원이며
매니페스트는 그 파생 인덱스다(손편집 드리프트 차단 — gen_golden 철학 상속).

    python tools/gen_manifest.py          # module_manifest.json 생성/갱신
    python tools/gen_manifest.py --check  # 생성 없이 검증(위반·드리프트 시 exit 1)

검증 3종:
  1. output 소유권 충돌 — 두 빌더(ask_1..6) 스테이지가 같은 leaf 경로를 산출하면 실패
     (disease=ask_4 / yong_mechanism=ask_5 / operative_branch=ask_6 정합화 자동 잠금).
  2. 의존순서 — 어떤 스테이지의 inputs.prior 경로는 빌드 순서상 *선행* 스테이지가
     산출해야 한다(전방 의존=순환 차단). 빌드 순서 = ask_1 → {ask_2,ask_3} → ask_4
     → ask_5 → ask_6 → ask_7.
  3. judgment_scope 실재 — 경로형 judgment_scope 키는 같은 스테이지 output에 매칭돼야 한다.
+ 드리프트 — 재생성 결과가 커밋된 module_manifest.json과 다르면 실패(--check).

의존: stdlib만. 프롬프트 .md 부재(번들-only 배포)면 graceful skip.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

# ── 경로: 이 파일 = <repo>/_extract/tools/gen_manifest.py ──
HERE = Path(__file__).resolve()
ENGINE_ROOT = HERE.parent.parent                      # = _extract
REPO_ROOT = ENGINE_ROOT.parent                        # = 워크트리 루트 (ask_modules.md 위치)
ASK_MODULES = REPO_ROOT / "ask_modules.md"
MANIFEST = REPO_ROOT / "module_manifest.json"

# ── 빌드 순서 / 의존 DAG (선형 — ask_3 가 ask_2.verdict_code 인용하므로 2∥3 병렬 아님) ──
BUILD_RANK = {"ask_1": 0, "ask_2": 1, "ask_3": 2, "ask_4": 3,
              "ask_5": 4, "ask_6": 5, "ask_7": 6}
BUILDERS = ("ask_1", "ask_2", "ask_3", "ask_4", "ask_5", "ask_6")  # ask_7=assembler(직렬화, 충돌 면제)

_BLOCK_RE = re.compile(r"(?ms)^```stage-contract[ \t]*\n(.*?)^```[ \t]*$")
_LIST_FIELDS = ("reads_reference", "inputs.tier1", "inputs.prior", "output", "judgment_scope")
_PATHISH = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*$")


# ───────────────────────── 파서 ─────────────────────────
def _split_top(s: str, sep: str = ",") -> list[str]:
    """{} () 깊이 0에서만 sep로 분할."""
    out, depth, cur = [], 0, []
    for ch in s:
        if ch in "{(":
            depth += 1
        elif ch in "})":
            depth -= 1
        if ch == sep and depth == 0:
            out.append("".join(cur)); cur = []
        else:
            cur.append(ch)
    if cur:
        out.append("".join(cur))
    return [x.strip() for x in out if x.strip()]


def _expand_braces(tok: str) -> list[str]:
    """prefix.{a, b.{x,y}, c} → 평탄 leaf 경로 리스트 (재귀)."""
    i = tok.find("{")
    if i == -1:
        return [tok]
    depth, j = 0, -1
    for k in range(i, len(tok)):
        if tok[k] == "{":
            depth += 1
        elif tok[k] == "}":
            depth -= 1
            if depth == 0:
                j = k; break
    if j == -1:
        return [tok]                       # 불균형 brace → 원형 반환(검증에서 노출)
    prefix, inside, suffix = tok[:i], tok[i + 1:j], tok[j + 1:]
    out = []
    for part in _split_top(inside, ","):
        out.extend(_expand_braces(prefix + part + suffix))
    return out


def _strip_annotation(item: str) -> str:
    """항목 말미의 ' (주석…)' 과 인라인 '# …' 제거 → 선두 토큰."""
    item = item.split("#", 1)[0].strip()
    p = item.find("(")                     # 최상위 괄호 주석 시작
    if p != -1:
        item = item[:p].strip()
    return item


def _parse_list(raw: str, expand: bool) -> list[str]:
    raw = raw.split("#", 1)[0].strip()     # 값 레벨 인라인 주석 제거(브래킷 추출 전)
    if raw.startswith("["):
        raw = raw[1:]
    if raw.endswith("]"):
        raw = raw[:-1]
    items = []
    for it in _split_top(raw, ","):
        tok = _strip_annotation(it)
        if not tok:
            continue
        items.extend(_expand_braces(tok) if expand else [tok])
    return items


def parse_contracts(md_text: str) -> dict:
    """ask_modules.md → {id: contract dict}. 순서 보존."""
    contracts: dict[str, dict] = {}
    for body in _BLOCK_RE.findall(md_text):
        fields: dict[str, str] = {}
        for line in body.splitlines():
            line = line.rstrip()
            if not line.strip():
                continue
            # 첫 메타 라인은 '·'로 다중 k:v
            segs = line.split("·") if (line.lstrip().startswith("id:") and "·" in line) else [line]
            for seg in segs:
                if ":" not in seg:
                    continue
                key, val = seg.split(":", 1)
                fields[key.strip()] = val.strip()
        cid = fields.get("id")
        if not cid:
            continue
        expand = True   # 경로 필드는 brace 전개
        contracts[cid] = {
            "tier": fields.get("tier", ""),
            "inherits_kernel": _parse_list(fields.get("inherits_kernel", "[]"), expand=False),
            "reads_reference": _parse_list(fields.get("reads_reference", "[]"), expand=False),
            "inputs": {
                "tier1": _parse_list(fields.get("inputs.tier1", "[]"), expand),
                "prior": _parse_list(fields.get("inputs.prior", "[]"), expand),
            },
            "output": _parse_list(fields.get("output", "[]"), expand),
            "judgment_scope": _parse_list(fields.get("judgment_scope", "[]"), expand=False),
            "note": fields.get("note", ""),
        }
    return contracts


# ───────────────────────── 검증 ─────────────────────────
def _prefix_match(a: str, b: str) -> bool:
    """a 와 b 가 경로 prefix 관계(또는 동일)인가."""
    return a == b or a.startswith(b + ".") or b.startswith(a + ".")


def _jscope_in_output(key: str, outputs: list[str]) -> bool:
    for o in outputs:
        if o == key or o.endswith("." + key) or ("." + key + ".") in o or o.startswith(key + "."):
            return True
    return False


def validate(contracts: dict) -> list[str]:
    v: list[str] = []
    ids = list(contracts)

    # (0) 필수 스테이지 존재
    for need in BUILD_RANK:
        if need not in contracts:
            v.append(f"[누락] STAGE CONTRACT 헤더 없음: {need}")

    # (1) output 소유권 충돌 (빌더 한정, assembler 면제)
    owner: dict[str, str] = {}
    for cid in BUILDERS:
        c = contracts.get(cid)
        if not c:
            continue
        for leaf in c["output"]:
            if leaf in owner:
                v.append(f"[충돌] output 경로 '{leaf}' 를 {owner[leaf]} 와 {cid} 가 동시 산출")
            else:
                owner[leaf] = cid

    # (2) 의존순서 — inputs.prior 는 선행 스테이지 output 이 산출해야
    all_out = {cid: contracts[cid]["output"] for cid in contracts}
    for cid, c in contracts.items():
        rank = BUILD_RANK.get(cid, 99)
        for p in c["inputs"]["prior"]:
            if not _PATHISH.match(p):
                continue                    # prose/설명 항목은 면제
            produced_by = [o for o in all_out
                           if BUILD_RANK.get(o, 99) < rank
                           and any(_prefix_match(p, leaf) for leaf in all_out[o])]
            if not produced_by:
                v.append(f"[의존] {cid}.inputs.prior '{p}' 를 선행 스테이지가 산출하지 않음(전방 의존/오타?)")

    # (3) judgment_scope 실재 — 경로형 키는 같은 스테이지 output 에 매칭
    for cid, c in contracts.items():
        for key in c["judgment_scope"]:
            tok = _strip_annotation(key)
            if not _PATHISH.match(tok):
                continue                    # prose 판단(예: '조후/억부 최종판정')은 면제
            if not _jscope_in_output(tok, c["output"]):
                v.append(f"[scope] {cid}.judgment_scope '{tok}' 가 output 에 없음")
    return v


def build_manifest(contracts: dict) -> dict:
    return {
        "_meta": {
            "source": "ask_modules.md (stage-contract 헤더)",
            "note": "DERIVED — 직접 편집 금지. 헤더 수정 후 `python tools/gen_manifest.py` 재생성.",
            "build_order": ["ask_1", "ask_2", "ask_3", "ask_4", "ask_5", "ask_6", "ask_7"],
        },
        "dependency_rank": BUILD_RANK,
        "modules": contracts,
    }


def _dumps(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n"


def main(argv: list[str]) -> int:
    check = "--check" in argv
    if not ASK_MODULES.exists():
        print(f"[skip] {ASK_MODULES.name} 부재(번들-only 배포?) — manifest 생성/검증 생략.")
        return 0
    contracts = parse_contracts(ASK_MODULES.read_text(encoding="utf-8"))
    if not contracts:
        print("[fail] stage-contract 헤더를 0개 파싱 — 포맷 확인 필요.")
        return 1
    violations = validate(contracts)
    manifest = build_manifest(contracts)
    live = _dumps(manifest)

    if check:
        drift = (not MANIFEST.exists()) or \
            (MANIFEST.read_text(encoding="utf-8").replace("\r\n", "\n") != live)
        print(f"[check] 스테이지 {len(contracts)}개 · 위반 {len(violations)}건 · "
              f"드리프트 {'있음' if drift else '없음'}")
        for x in violations:
            print("   " + x)
        if drift:
            print("   DRIFT: module_manifest.json 이 헤더와 불일치 — `python tools/gen_manifest.py` 재생성·커밋 필요.")
        return 1 if (violations or drift) else 0

    if violations:
        print(f"[fail] 위반 {len(violations)}건 — manifest 미기록:")
        for x in violations:
            print("   " + x)
        return 1
    MANIFEST.write_text(live, encoding="utf-8", newline="")
    print(f"완료: {len(contracts)}개 스테이지 → {MANIFEST}  ({len(live)} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
