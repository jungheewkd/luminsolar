#!/usr/bin/env python3
"""GPT 샌드박스 진입점.
사용: python3 run_emit.py 1990-05-15T08:30 F [경도|--region "지역명"] [--no-time] [--divination ISO]
      python3 run_emit.py --jieqi 2026        # 연 단위 12절 절입·월간지 emit (D-055 — 인물 무관)
경도와 --region은 상호배타(동시 입력 거부). --region은 출생지명→경도 결정론 변환(§A6)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from datetime import datetime


def _force_utf8_io():
    """D-068(F3): 출력 인코딩을 UTF-8로 고정. 비-UTF8 로케일(Windows cp949 등)에서 간지
    한자(爲·剝 등 cp949 미수록) 출력 시 UnicodeEncodeError 크래시를 차단한다.
    Code Interpreter(Linux/UTF-8)에선 사실상 no-op. PYTHONUTF8 환경변수 불요."""
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8")          # TextIOWrapper.reconfigure (py3.7+)
        except (AttributeError, ValueError, OSError):
            pass                                            # 재구성 불가 스트림은 그대로 둔다


def main(a):
    if "--assemble" in a:                    # SILENT_BUILD 조각 → saju.handoff.v3.8 결정론 봉인(birth 파싱 전 분기)
        from tools.assemble_handoff import run_cli
        sys.exit(run_cli(a))
    if "--jieqi" in a:                       # D-055: 인물 무관 단독 모드 — birth 파싱 전 분기
        from tools.emit_jieqi import build_jieqi_dict, to_json_str as _jj
        try:
            d = build_jieqi_dict(int(a[a.index("--jieqi") + 1]))
        except (LookupError, ValueError, IndexError) as e:
            sys.exit(f"[jieqi] {e} — 커버리지 밖 연도는 사용자에게 정확 절입 시각 확인을 요청하세요(Core §10).")
        print("```jieqi_facts"); print(_jj(d)); print("```"); return
    from tools.emit_tier1_standalone import build_tier1_dict, to_json_str
    try:                                     # D-063(F2): 입력 파싱 fail-loud (생일·성별·경도·divination)
        birth = datetime.fromisoformat(a[1])
        gender = a[2].upper()                # 성별 누락(a[2] IndexError)도 본 가드로 1줄 종료 — traceback 누출 차단
        lon = float(a[3]) if len(a) > 3 and not a[3].startswith("--") else None
        region = a[a.index("--region") + 1] if "--region" in a else None  # §A6: 출생지명→경도(엔진 변환)
        if lon is not None and region is not None:                        # 상호배타 — silent 우선순위 없이 명시 거부
            raise ValueError("경도 숫자와 --region 동시 입력 불가 — 하나만 쓰세요")
        div = datetime.fromisoformat(a[a.index("--divination") + 1]) if "--divination" in a else None
    except (ValueError, IndexError) as e:
        sys.exit(f"[tier1] 입력 파싱 불가: {e} — 생년월일시는 ISO 8601(YYYY-MM-DDTHH:MM), 성별은 F/M, "
                 f"경도는 숫자(124~132) 또는 --region \"지역명\"으로 입력하세요(KERNEL ON_FAIL ⓔ, 간지 추정·재시도 금지).")
    try:                                     # D-056: 커버리지 / D-063(F2): 입력검증 fail-loud (--jieqi와 동일 패턴)
        d = build_tier1_dict(birth, has_time="--no-time" not in a, gender=gender,
                             longitude=lon, birth_place=region, divination_dt=div)
    except LookupError as e:
        sys.exit(f"[tier1] {e} — 지원 출생 범위(1951-01-06 소한 이후 ~ 2035 수록 절기) 밖입니다. "
                 f"Core §10·KERNEL ON_FAIL ⓔ에 따라 사용자에게 안내하세요(간지 추정·재시도 금지).")
    except ValueError as e:                  # D-063(F2): 경도 범위밖·잘못된 성별 등 입력검증
        # solar_terms.py 빌드무결성 ValueError는 xlsx 경로 전용이라 본 emit(xlsx_path=None) 흐름엔 미도달.
        sys.exit(f"[tier1] 입력값 오류: {e} — 경도(124~132)·성별(F/M) 등 입력을 확인하세요"
                 f"(KERNEL ON_FAIL ⓔ, 간지 추정·재시도 금지).")
    print("```tier1_facts"); print(to_json_str(d)); print("```")

if __name__ == "__main__":
    _force_utf8_io()                             # D-068(F3): CLI 진입 시에만 — import 경로 stdout 불변
    main(sys.argv)
