"""DST(서머타임) 정확 시행일표 — 벽시계 [시작, 끝) 반개구간 (S1 토대 자산).

PROVENANCE: IANA tzdata `Asia/Seoul`에서 zoneinfo로 분 단위 추출 (2026-06-11, tools/extract_dst 절차).
- 시작 = 시계를 +1h 돌린 *직후* 벽시계 / 끝 = 되돌리기 직전 DST 벽시계 (반개구간).
- 1948~1951 4년 전부 시행 확인 (프롬프트 §A6의 "1948~51 일부"보다 정밀 — CORRECTIONS C-004).
- 1955~1960 DST는 당시 표준시 UTC+8:30 위에 +1h (벽시계 UTC+9:30) — 엔진 규칙 "벽시계 −1h"로 동일 처리.
- 표준시 변경(1954-03-21 → +8:30 / 1961-08-10 → +9)은 constants.UTC830_PERIODS와 분 단위 일치 검증 완료.

엔진은 런타임에 시스템 tzdata에 의존하지 않는다(D-014 naive KST) — 본 하드코딩이 SoT.
"""
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

DST_PERIODS: List[Tuple[datetime, datetime]] = [
    (datetime(1948, 6, 1, 1, 0),  datetime(1948, 9, 13, 0, 0)),
    (datetime(1949, 4, 3, 1, 0),  datetime(1949, 9, 11, 0, 0)),
    (datetime(1950, 4, 1, 1, 0),  datetime(1950, 9, 10, 0, 0)),
    (datetime(1951, 5, 6, 1, 0),  datetime(1951, 9, 9, 0, 0)),
    (datetime(1955, 5, 5, 1, 0),  datetime(1955, 9, 9, 0, 0)),
    (datetime(1956, 5, 20, 1, 0), datetime(1956, 9, 30, 0, 0)),
    (datetime(1957, 5, 5, 1, 0),  datetime(1957, 9, 22, 0, 0)),
    (datetime(1958, 5, 4, 1, 0),  datetime(1958, 9, 21, 0, 0)),
    (datetime(1959, 5, 3, 1, 0),  datetime(1959, 9, 20, 0, 0)),
    (datetime(1960, 5, 1, 1, 0),  datetime(1960, 9, 18, 0, 0)),
    (datetime(1987, 5, 10, 3, 0), datetime(1987, 10, 11, 3, 0)),
    (datetime(1988, 5, 8, 3, 0),  datetime(1988, 10, 9, 3, 0)),
]

# 존재 불가(skipped) / 중복 발생(ambiguous) 벽시계 창 — 입력 데이터 품질 플래그용
_SKIPPED: List[Tuple[datetime, datetime]] = [(s - timedelta(hours=1), s) for s, _ in DST_PERIODS]
_AMBIGUOUS: List[Tuple[datetime, datetime]] = [(e - timedelta(hours=1), e) for _, e in DST_PERIODS]


def get_dst_periods() -> List[Tuple[datetime, datetime]]:
    return DST_PERIODS


def dst_anomaly(dt: datetime) -> Optional[str]:
    """출생 기록 시각의 전환 이상 판정: 'skipped'(존재 불가 — 기록 오류 의심) / 'ambiguous'(2회 발생 — 확인 권장) / None."""
    for a, b in _SKIPPED:
        if a <= dt < b:
            return "skipped"
    for a, b in _AMBIGUOUS:
        if a <= dt < b:
            return "ambiguous"
    return None
