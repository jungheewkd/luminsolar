"""Step 10 — Strength% 정규화 + A6 기형 중재 + A7 경계 보류 + 조습 (ASK2 §1·§2-3·A6·A7 / §⑧-3).

산출 절차는 §1-5 '순서 고정'을 그대로: 득령raw → 득지raw(뿌리별 ×(1+k12)×(1+kHC) 후 합산·1회 캡)
→ 득세raw(±100 캡) → 정규화(×2 / 그대로 / (+100)/2) → 0.40/0.35/0.25 가중 → 임계표 → A6 → A7.

[해석 고정 — 원문 모호점, CORRECTIONS C-005]
  §1-2 '타지 지장간 합산 ≤40'의 '타지'는 **년지**로 해석(① 우선순위 목록이 일·월·시 본기만 ≤100 명시).
  년지 발 뿌리(본·중·여) adj 합산을 40에서 캡. 중·여기 base=35(30~40 중앙값), 인성 ×0.65(D-034).
[S5 종결 — §1-5 A5 원문] 합충 계수는 '그 지지에 한해 최대 단일 계수' — 지지별 max-magnitude 1개.
  계수원: 육합·육충만(§1-2-1-α — 형파해 0, 삼합·방국은 1-4-2 구성확인만). 성립 여부 무관 '존재' 기준.
[A6 — D-035] 不透通根(xing_only) 상향 목적지 = 中和(원문 '準身强/中和' 중 보수측) · 不透無根(neither) 강측 = 中和 강등 + 종격 표기.
[A7(e) — D-036] 결정 트리거 = §⑧-3 #1(금: 토근이 未戌뿐 + 火氣)·#2(화: 辰丑 ≥2). #3 木은 주석 전용.
[(d) — D-037] 보수 임계: 비겁0 ∧ 인성≥65 또는 비율≥2.5 → d / 잔여(비율≥1.5 등) → d_fuzzy(LLM 위임 플래그).
[v0.2.2 — D-052] khc 채택 계수를 위치별 khc_map{coefficient, basis}으로 보존 → emitter echo(tier1.v1.2).
  수치 경로 불변 — 동률(년·시 −0.05) 시 clash 우선은 구 min() 선두 채택과 동치임을 회귀로 잠금.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional, Set, Tuple

from saju_engine.assets.lookup.attributes import BRANCH_ATTR, STEM_ATTR
from saju_engine.assets.lookup.hidden_stems import HIDDEN_STEMS
from saju_engine.assets.lookup.twelve_stages import GROUP_BONUS, STAGE_GROUP, STAGE_MATRIX
from saju_engine.constants import FIVE_CONTROLS, FIVE_GENERATES, Q_STRENGTH
from saju_engine.engine.month_hour_pillar import FourPillars
from saju_engine.engine.relations import RelationHit

SCALE = ["weak", "quasi_weak", "balanced", "quasi_strong", "strong"]
DEUKRYEONG = {"旺": 50, "相": 35, "休": 15, "囚": 5, "死": 0}
KHC = {"clash": {"day": -0.30, "month": -0.20, "year": -0.05, "hour": -0.05},
       "combine_6": {"day": -0.20, "month": -0.10, "year": -0.05, "hour": -0.05}}
SE_W = {"year": 60, "month": 100, "hour": 80}
DRY_EARTH, WET_EARTH = {"未", "戌"}, {"辰", "丑"}


def _ryeong_state(day_e: str, month_e: str) -> str:
    if day_e == month_e: return "旺"
    if FIVE_GENERATES[month_e] == day_e: return "相"
    if FIVE_GENERATES[day_e] == month_e: return "休"
    if FIVE_CONTROLS[day_e] == month_e: return "囚"
    return "死"


def verdict_at(pct: float) -> str:
    return ("strong" if pct >= 65 else "quasi_strong" if pct >= 55 else
            "balanced" if pct >= 45 else "quasi_weak" if pct >= 35 else "weak")


def apply_a6(verdict: str, qi_xing: str) -> Tuple[str, bool, bool]:
    """A6 매트릭스 → (조정 verdict, 적용여부, 종격검토 플래그)."""
    if qi_xing == "qi_only" and verdict == "strong":
        return "quasi_strong", True, False
    if qi_xing == "xing_only" and verdict in ("weak", "quasi_weak"):
        return "balanced", True, False                       # D-035: 보수측 中和
    # ⚠️ 도달 불가·의도적 미사용 분기 (D-074, 종격 이론 검증): qi_xing=="neither"는 구조상 高pct에
    #   도달하지 못한다(test_neither_never_reaches_strong: 실측 max 43.9). 게다가 棄命류 종격
    #   (從財/從殺/從兒/從勢)의 정통 트리거는 極弱(low pct)∧無根∧無生扶로 부호가 반대 — 본 분기
    #   (neither∧strong)는 어느 종격에도 정합하지 않는다. 종격 확정은 ASK4 §1-1(전왕→종→화→정격)
    #   LLM에 위임하고(진종<5%·假從 다수·발산 방지), jonggyeok_review는 emit 미직렬화. 재배선·신호화는
    #   ROI상 보류(적천수 골든 회귀 대비 효용 미달). 거동 영향 0 — 도달 불가를 명시만 한다.
    if qi_xing == "neither" and verdict in ("strong", "quasi_strong"):
        return "balanced", True, True                        # (도달 불가 — 위 주석·D-074 참조)
    return verdict, False, False


@dataclass(frozen=True)
class Root:
    position: str
    slot: str          # 본기/중기/여기
    stem: str
    kind: str          # 비겁/인성
    base: float
    adj: float


@dataclass(frozen=True)
class StrengthResult:
    deuk_ryeong_raw: int
    deuk_ji_raw: float
    deuk_ji_uncapped: float
    deuk_se_raw: int
    deuk_se_uncapped: int
    strength_pct: float
    qi_xing: str
    a6_applied: bool
    jonggyeok_review: bool
    verdict_center: str
    boundary_hold: bool
    triggers: Dict[str, bool]
    candidates: Optional[Tuple[str, str]]
    roots: Tuple[Root, ...]
    khc_applied: Dict[str, Dict[str, object]] = field(default_factory=dict)  # v1.2 echo — 위치별 채택 계수(D-052)
    climate_notes: Tuple[str, ...] = ()
    boundary_evidence: Dict[str, object] = field(default_factory=dict)       # I7(D-067) 경계 비대칭 echo


def compute_strength_core(stems: Dict[str, Optional[str]], branches: Dict[str, Optional[str]],
                          clash_pos: Set[str], comb6_pos: Set[str]) -> StrengthResult:
    day_s = stems["day"]; day_e = STEM_ATTR[day_s]["element"]
    gen_me = {e for e, g in FIVE_GENERATES.items() if g == day_e}.pop()   # 인성 오행
    pos_b = [(p, branches[p]) for p in ("year", "month", "day", "hour") if branches.get(p)]

    # 1. 득령
    state = _ryeong_state(day_e, BRANCH_ATTR[branches["month"]]["element"])
    ryeong = DEUKRYEONG[state]

    # 2. 득지 — 뿌리별
    khc_map: Dict[str, Dict[str, object]] = {}               # v1.2 echo — 위치별 채택 계수·basis (D-052)
    for p, _b in pos_b:
        cands_k = ([(KHC["clash"][p], "clash")] if p in clash_pos else []) \
                + ([(KHC["combine_6"][p], "combine_6")] if p in comb6_pos else [])
        if cands_k:
            coef, basis = min(cands_k)                       # 최대 절대치 단일(§1-5 A5); 동률=clash 우선(구 min() 선두 동치·§④-6 위계 정합)
            khc_map[p] = {"coefficient": coef, "basis": basis}

    def khc(p: str) -> float:
        return float(khc_map[p]["coefficient"]) if p in khc_map else 0.0

    roots: List[Root] = []
    for p, b in pos_b:
        k12_g = GROUP_BONUS[STAGE_GROUP[STAGE_MATRIX[day_s][b]]]
        k12 = k12_g if p == "day" else k12_g * 0.5
        kc = khc(p)
        for slot, hs in zip(("본기", "중기", "여기"), HIDDEN_STEMS[b]):
            if hs is None: continue
            he = STEM_ATTR[hs]["element"]
            kind = "비겁" if he == day_e else ("인성" if he == gen_me else None)
            if kind is None: continue
            base = (100.0 if kind == "비겁" else 65.0) if slot == "본기" else (35.0 if kind == "비겁" else 22.75)
            roots.append(Root(p, slot, hs, kind, base, base * (1 + k12) * (1 + kc)))
    year_adj = sum(r.adj for r in roots if r.position == "year")
    year_capped = min(year_adj, 40.0)                        # C-005 해석: 타지=년지 합산 캡
    ji_unc = sum(r.adj for r in roots if r.position != "year") + year_capped
    ji = min(ji_unc, 100.0)

    # 3. 득세
    GROUP_PLUS = {"비겁", "인성"}
    def sgroup(s: str) -> str:
        e = STEM_ATTR[s]["element"]
        return "비겁" if e == day_e else "인성" if e == gen_me else "식재관"
    se_unc = sum((SE_W[p] if sgroup(s) in GROUP_PLUS else -SE_W[p])
                 for p, s in stems.items() if p != "day" and s)
    se = max(-100, min(100, se_unc))

    # 4·5. 정규화 + 가중
    pct = float((Decimal("0.40") * (ryeong * 2) + Decimal("0.35") * Decimal(str(ji))
                 + Decimal("0.25") * Decimal(str((se + 100) / 2))).quantize(Q_STRENGTH, ROUND_HALF_UP))

    # 기형 (氣 = 년·월·시간 생조 투출 / 形 = 본·중기 뿌리)
    gi = any(sgroup(s) in GROUP_PLUS for p, s in stems.items() if p != "day" and s)
    hyeong = any(r.slot in ("본기", "중기") for r in roots)
    qi_xing = "both" if gi and hyeong else "qi_only" if gi else "xing_only" if hyeong else "neither"

    center, a6, jong = apply_a6(verdict_at(pct), qi_xing)

    # A7
    in_p = sum(r.adj for r in roots if r.kind == "인성") + sum(SE_W[p] for p, s in stems.items()
                                                               if p != "day" and s and sgroup(s) == "인성")
    bi_p = sum(r.adj for r in roots if r.kind == "비겁") + sum(SE_W[p] for p, s in stems.items()
                                                               if p != "day" and s and sgroup(s) == "비겁")
    d = (bi_p == 0 and in_p >= 65) or (bi_p > 0 and in_p / bi_p >= 2.5)
    d_fuzzy = (not d) and ((bi_p == 0 and in_p >= 40) or (bi_p > 0 and in_p / bi_p >= 1.5))
    earth_roots = [b for _, b in pos_b for hs in HIDDEN_STEMS[b] if hs and STEM_ATTR[hs]["element"] == "土"
                   and STEM_ATTR[hs]["element"] == gen_me]
    fire_aid = any(s and STEM_ATTR[s]["element"] == "火" for s in stems.values()) or \
               any(b in ("巳", "午") for _, b in pos_b)
    e_metal = day_e == "金" and earth_roots and set(earth_roots) <= DRY_EARTH and fire_aid
    e_fire = day_e == "火" and sum(1 for _, b in pos_b if b in WET_EARTH) >= 2
    trig = {"a_numeric_band": 30 <= pct <= 40 or 60 <= pct <= 70,
            "b_qi_xing": qi_xing in ("qi_only", "xing_only"),
            "c_day_branch_clash": "day" in clash_pos,
            "d_resource_excess": d, "d_fuzzy_residual": d_fuzzy,
            "e_climate_nullified": bool(e_metal or e_fire)}
    hold = trig["a_numeric_band"] or trig["b_qi_xing"] or trig["c_day_branch_clash"] or d or trig["e_climate_nullified"]
    i = SCALE.index(center)
    cands = (SCALE[max(i - 1, 0)], SCALE[min(i + 1, 4)]) if hold else None

    # I7(D-067): 경계 비대칭 신뢰도 — 전부 기존 계산값 echo(신규 산술·판단 0, read-only).
    _raw_v = verdict_at(pct)
    _ratio = (in_p / bi_p) if bi_p else None
    boundary_evidence = {
        "raw_pct": pct,
        "raw_verdict": _raw_v,                                          # A6 이전 raw 판정
        "a6_shift_levels": SCALE.index(center) - SCALE.index(_raw_v),   # A6가 옮긴 칸수(+ = 상향)
        "dist_to_strong": round(pct - 65.0, 1),                         # 强 임계(65)까지 거리
        "dist_to_weak": round(pct - 35.0, 1),                           # 弱 임계(35)까지 거리
        "nearer_boundary": "weak" if abs(pct - 35.0) <= abs(pct - 65.0) else "strong",
        "in_p": round(in_p, 1), "bi_p": round(bi_p, 1),
        "resource_ratio": round(_ratio, 2) if _ratio is not None else None,        # 인성/비겁
        "ratio_to_d_gate": round(_ratio / 2.5, 2) if _ratio is not None else None,  # d(강제보류) 게이트까지
        "ratio_to_dfuzzy_gate": round(_ratio / 1.5, 2) if _ratio is not None else None,  # d_fuzzy(advisory)까지
        "d_fuzzy_residual": d_fuzzy,
    }

    notes = []
    if e_metal: notes.append("조토불생금 — 인성 생조 실효 의문(§⑧-3 #1)")
    if e_fire: notes.append("회화 — 火 설기·암약(§⑧-3 #2)")
    if day_e == "木" and sum(1 for _, b in pos_b if b in DRY_EARTH) >= 2:
        notes.append("조목(뿌리 마름) 위험 — 주석 전용(§⑧-3 #3, D-036)")
    if day_e == "木" and sum(1 for _, b in pos_b if b in ("亥", "子", "丑")) >= 3:
        notes.append("수범(水泛) 위험 — 주석 전용(§⑧-3 #3, D-036)")

    return StrengthResult(ryeong, round(ji, 1), round(ji_unc, 1), se, se_unc, pct, qi_xing,
                          a6, jong, center, hold, trig, cands, tuple(roots),
                          khc_applied=khc_map, climate_notes=tuple(notes),
                          boundary_evidence=boundary_evidence)


def strength_for_chart(fp: FourPillars, relations: List[RelationHit]) -> StrengthResult:
    stems = {"year": fp.year.ganji[0], "month": fp.month.ganji[0], "day": fp.day.ganji[0],
             "hour": fp.hour.ganji[0] if fp.hour else None}
    branches = {"year": fp.year.ganji[1], "month": fp.month.ganji[1], "day": fp.day.ganji[1],
                "hour": fp.hour.ganji[1] if fp.hour else None}
    clash_pos = {p for h in relations if h.type == "clash" for p in h.positions}
    comb6_pos = {p for h in relations if h.type == "combine_6" for p in h.positions}
    return compute_strength_core(stems, branches, clash_pos, comb6_pos)
