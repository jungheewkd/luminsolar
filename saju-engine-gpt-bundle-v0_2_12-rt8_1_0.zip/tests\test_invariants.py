"""불변식 — 임의 명식에 대해 항상 성립해야 하는 구조 속성(검산 echo 계약의 자동화).

640개 결정론 표본 × (조건 A·B)에 대해 검증한다. 어느 하나라도 깨지면
스키마/열거/범위 계약이 무너진 것이므로 회귀로 본다.
"""
from __future__ import annotations

import pytest

from tests.conftest import (
    PIN, VALID_STEMS, VALID_BRANCHES, VALID_TEN_GODS, VALID_STAGES,
    VALID_SCALE, VALID_QI_XING, VALID_RELATION_TYPES, VALID_RELATION_STATUS,
    VALID_ELEMENTS, VALID_FLOW_TYPES, VALID_FLOW_STATUS, VALID_FLOW_POSITIONS,
)
from tests.corpus import broad_sample
from tools.emit_tier1_standalone import build_tier1_dict
from saju_engine.engine.strength import SCALE as SCALE_LIST
from datetime import datetime


def check_invariants(d: dict, condition: str):
    """위반 문자열 리스트 반환(빈 리스트 = 통과)."""
    v = []

    def chk(cond, msg):
        if not cond:
            v.append(msg)

    # 핀
    chk(d["schema_version"] == PIN["schema_version"], "schema_version 불일치")
    chk(d["meta"]["engine_version"] == PIN["engine_version"], "engine_version 불일치")
    chk(d["meta"]["prompt_pin"] == PIN["prompt_pin"], "prompt_pin 불일치")
    chk(d["meta"]["condition"] == condition, "condition 불일치")

    # 원국 기둥
    pillars = d["chart"]
    chk(d["chart"]["hour"] is None if condition == "B" else d["chart"]["hour"] is not None,
        f"조건 {condition} 시주 None 규약 위반")
    for pos in ("year", "month", "day", "hour"):
        p = pillars[pos]
        if p is None:
            continue
        chk(p["stem"] in VALID_STEMS, f"{pos}.stem 비정상: {p['stem']}")
        chk(p["branch"] in VALID_BRANCHES, f"{pos}.branch 비정상: {p['branch']}")
        # 왕지(子午卯酉)는 중기가 없어 hidden_stems에 None 포함이 정상
        hs_nonnull = [h for h in p["hidden_stems"] if h is not None]
        chk(len(hs_nonnull) >= 1 and all(h in VALID_STEMS for h in hs_nonnull),
            f"{pos}.hidden_stems 비정상: {p['hidden_stems']}")
        if p["ten_god_stem"] is not None:
            chk(p["ten_god_stem"] in VALID_TEN_GODS, f"{pos}.ten_god_stem 비정상: {p['ten_god_stem']}")
        chk(p["ten_god_branch"] in VALID_TEN_GODS, f"{pos}.ten_god_branch 비정상")
        chk(p["twelve_stage"] in VALID_STAGES, f"{pos}.twelve_stage 비정상: {p['twelve_stage']}")

    # 강약
    s = d["strength"]
    chk(0.0 <= s["strength_pct"] <= 100.0, f"strength_pct 범위 밖: {s['strength_pct']}")
    chk(s["verdict_center"] in VALID_SCALE, f"verdict_center 비정상: {s['verdict_center']}")
    chk(s["qi_xing"] in VALID_QI_XING, f"qi_xing 비정상: {s['qi_xing']}")
    chk(isinstance(s["boundary_hold"], bool), "boundary_hold 비불리언")
    chk(-100 <= s["deuk_se_raw"] <= 100, f"deuk_se_raw 범위 밖: {s['deuk_se_raw']}")
    chk(s["deuk_ji_raw"] <= 100.0 + 1e-9, f"deuk_ji_raw 캡 위반: {s['deuk_ji_raw']}")
    cand = s["candidates"]
    if cand is not None:
        chk(len(cand) == 2 and all(x in VALID_SCALE for x in cand), f"candidates 비정상: {cand}")
        chk(s["boundary_hold"] is True, "candidates 존재하나 boundary_hold=False")
    else:
        chk(s["boundary_hold"] is False, "candidates None이나 boundary_hold=True")
    for r in s["roots"]:
        chk(r["slot"] in KO_SLOT, f"root.slot 비정상: {r['slot']}")
        chk(r["kind"] in KO_GROUP, f"root.kind 비정상: {r['kind']}")

    # boundary_evidence (I7) — read-only echo (강약 재계산 아님을 항등식으로 잠금)
    be = s.get("boundary_evidence")
    chk(be is not None, "boundary_evidence 부재")
    if be:
        chk(be["raw_pct"] == s["strength_pct"], "boundary_evidence.raw_pct가 strength_pct echo 아님")
        chk(be["raw_verdict"] in VALID_SCALE, f"raw_verdict 비정상: {be['raw_verdict']}")
        chk(be["nearer_boundary"] in ("weak", "strong"), f"nearer_boundary 비정상: {be['nearer_boundary']}")
        chk(be["dist_to_weak"] == round(s["strength_pct"] - 35.0, 1), "dist_to_weak echo 불일치")
        chk(be["dist_to_strong"] == round(s["strength_pct"] - 65.0, 1), "dist_to_strong echo 불일치")
        chk(be["d_fuzzy_residual"] == s["triggers"]["d_fuzzy_residual"], "d_fuzzy_residual echo 불일치")
        # a6_shift 정합: raw_verdict 인덱스 + shift == verdict_center 인덱스
        chk(SCALE_LIST.index(be["raw_verdict"]) + be["a6_shift_levels"] == SCALE_LIST.index(s["verdict_center"]),
            f"a6_shift_levels 정합 위반: {be['raw_verdict']}+{be['a6_shift_levels']}≠{s['verdict_center']}")

    # 대운
    dw = d["daewoon"]
    chk(dw["direction"] in ("forward", "reverse"), f"daewoon.direction 비정상: {dw['direction']}")
    chk(len(dw["table"]) == 8, f"daewoon.table 길이 {len(dw['table'])} (기대 8)")
    for row in dw["table"]:
        g = row["ganji"]
        chk(len(g) == 2 and g[0] in VALID_STEMS and g[1] in VALID_BRANCHES, f"대운 간지 비정상: {g}")
    if condition == "B":
        chk(dw["start_age_uncertainty_years"] == 1, "조건 B 대운 ±1년 유예 누락")

    # 관계 / 공망
    for r in d["relations"]:
        chk(r["type"] in VALID_RELATION_TYPES, f"relation.type 미지: {r['type']}")
        chk(r["status"] in VALID_RELATION_STATUS, f"relation.status 미지: {r['status']}")
    vb = d["void_branches"]
    chk(len(vb) == 2 and all(b in VALID_BRANCHES for b in vb), f"void_branches 비정상: {vb}")

    # 일주 교차검증 토큰
    chk(d["derivation"]["day_pillar_kasi_cross"] == "verified_full_1900_2050",
        f"day_pillar_kasi_cross 비정상: {d['derivation']['day_pillar_kasi_cross']}")

    # flow_signals (I8) — 운×원국 탐지
    fs = d.get("flow_signals")
    chk(fs is not None, "flow_signals 부재")
    if fs:
        chk(len(fs["daewoon"]) == 8, f"flow_signals.daewoon 길이 {len(fs['daewoon'])} (기대 8)")
        chk(fs["seyun"] is None, "비-divination인데 seyun 존재")   # broad 표본은 divination 없음
        for e in fs["daewoon"]:
            g = e["ganji"]
            chk(len(g) == 2 and g[0] in VALID_STEMS and g[1] in VALID_BRANCHES, f"대운 ganji 비정상: {g}")
            chk(e["signal_count"] == len(e["signals"]), f"signal_count 불일치: {g}")
            for s in e["signals"]:
                chk(s["channel"] in ("branch", "stem"), f"flow channel 비정상: {s['channel']}")
                chk(s["type"] in VALID_FLOW_TYPES, f"flow type 미지: {s['type']}")
                chk(s["target_position"] in VALID_FLOW_POSITIONS, f"flow target_position 비정상: {s['target_position']}")
                chk(s["target_element"] in VALID_ELEMENTS, f"flow target_element 비정상: {s['target_element']}")
                chk(s["transformed_element"] is None or s["transformed_element"] in VALID_ELEMENTS,
                    f"flow transformed_element 비정상: {s['transformed_element']}")
                chk(s["status"] in VALID_FLOW_STATUS, f"flow status 비정상: {s['status']}")
                chk(s["position_tier"] in ("T1", "T2"), f"flow position_tier 비정상: {s['position_tier']}")
                pool = VALID_BRANCHES if s["channel"] == "branch" else VALID_STEMS
                chk(s["luck_char"] in pool, f"flow luck_char 비정상: {s['luck_char']}")
    return v


# KO 코드 셋 (root 검증용)
from saju_engine.constants import KO2CODE_SLOT, KO2CODE_GROUP  # noqa: E402
KO_SLOT = set(KO2CODE_SLOT.values())
KO_GROUP = set(KO2CODE_GROUP.values())


@pytest.mark.invariant
@pytest.mark.parametrize("condition", ["A", "B"])
def test_invariants_broad(condition):
    violations = []
    for birth, has_time, g in broad_sample(condition):
        d = build_tier1_dict(datetime.fromisoformat(birth), has_time=has_time, gender=g)
        for msg in check_invariants(d, condition):
            violations.append(f"{birth}/{g}: {msg}")
    assert not violations, f"{len(violations)}건 불변식 위반:\n" + "\n".join(violations[:30])
