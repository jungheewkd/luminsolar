"""골든 스냅샷 (재)생성기 — 명시 실행 전용.

    python tests/gen_golden.py          # 전 케이스 베이스라인 생성/갱신
    python tests/gen_golden.py --check  # 생성 없이 현재 골든과 diff만 출력

⚠️ 회귀 잠금 철학: 테스트는 골든을 절대 자동 재생성하지 않는다. 엔진 출력이
   의도적으로 바뀌었을 때(가산 필드 등) 사람이 본 스크립트를 *명시적으로* 돌려
   베이스라인을 갱신하고, 그 diff를 리뷰·커밋한다(CHANGELOG 4모드 diff 규율).
"""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ENGINE_ROOT = HERE.parent
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

from tests.corpus import TIER1_CASES, JIEQI_CASES, case_json, jieqi_json  # noqa: E402

GOLDEN_DIR = HERE / "_golden"


def _write(name: str, text: str) -> None:
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    (GOLDEN_DIR / name).write_text(text, encoding="utf-8", newline="")


def _norm(s: str) -> str:
    return s.replace("\r\n", "\n").rstrip("\n")


def main(argv) -> int:
    check = "--check" in argv
    items = [(c.label, case_json, c) for c in TIER1_CASES] + \
            [(c.label, jieqi_json, c) for c in JIEQI_CASES]
    changed, created, ok = [], [], 0
    for label, fn, c in items:
        name = f"{label}.json"
        live = fn(c)
        path = GOLDEN_DIR / name
        if check:
            if not path.exists():
                created.append(name)
            elif _norm(path.read_text(encoding="utf-8")) != _norm(live):
                changed.append(name)
            else:
                ok += 1
        else:
            _write(name, live)
            print(f"  wrote {name}  ({len(live)} bytes)")
    if check:
        print(f"[check] 일치 {ok} · 변경 {len(changed)} · 신규 {len(created)}")
        for n in changed:
            print(f"   CHANGED: {n}")
        for n in created:
            print(f"   MISSING: {n}")
        return 1 if (changed or created) else 0
    print(f"완료: {len(items)}개 골든 생성/갱신 → {GOLDEN_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
