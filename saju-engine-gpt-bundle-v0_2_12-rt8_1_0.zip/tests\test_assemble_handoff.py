"""assemble_handoff CI 게이트 — derived_lookup 결정론·병합·검증·fail-loud.

직접 실행(pytest 미가용):  echo '{...}' | python tools/assemble_handoff.py --check
"""
from __future__ import annotations

import pytest

from tools import assemble_handoff as ah


def _build(**t2):
    return {"tier1_facts": {"chart": {}}, "tier2_interpretation": t2}


def test_stem_branch_element_closure():
    sbe = ah.stem_branch_element()
    assert len(sbe) == 22
    assert sbe["甲"] == "wood" and sbe["午"] == "fire" and sbe["子"] == "water"
    assert set(sbe.values()) <= set(ah.ELEMENTS)


def test_favorability_single_closure():
    h = ah.assemble(_build(yong_shen={"element": "wood"}, hee_shen={"element": "water"},
                           gi_shin={"element": "metal"}, gu_shin={"element": "earth"}))
    ef = h["derived_lookup"]["element_favorability"]["single"]
    assert ef == {"wood": "favorable", "water": "favorable",
                  "metal": "unfavorable", "earth": "unfavorable", "fire": "neutral"}
    assert ah.validate(h) == []


def test_hanja_element_normalized():
    h = ah.assemble(_build(yong_shen={"element": "火"}, gi_shin={"element": "水"}))
    ef = h["derived_lookup"]["element_favorability"]["single"]
    assert ef["fire"] == "favorable" and ef["water"] == "unfavorable"


def test_yong_gi_conflict_fail_loud():
    with pytest.raises(ValueError):
        ah.assemble(_build(yong_shen={"element": "wood"}, gi_shin={"element": "wood"}))


def test_missing_tier_fail_loud():
    with pytest.raises(ValueError):
        ah.assemble({"tier1_facts": {"x": 1}})       # tier2 누락
    with pytest.raises(ValueError):
        ah.assemble({"tier2_interpretation": {"yong_shen": {"element": "wood"}}})  # tier1 누락


def test_schema_and_tier_separation():
    h = ah.assemble(_build(yong_shen={"element": "wood"}))
    assert h["schema"] == ah.SCHEMA
    assert {"tier1_facts", "tier2_interpretation", "derived_lookup"} <= set(h)
    assert ah.validate(h) == []


# ── strength 재배치(canonical v3.7 — tier2.strength) ──────────────
def test_strength_rehomed_to_tier2():
    eng = {"verdict_center": "weak", "strength_pct": 30.0, "deuk_ryeong_raw": 5,
           "deuk_ji_raw": 20.0, "deuk_se_raw": -50.0, "boundary_hold": False}
    h = ah.assemble({"tier1_facts": {"chart": {}, "strength": eng},
                     "tier2_interpretation": {"yong_shen": {"element": "wood"}}})
    assert "strength" not in h["tier1_facts"]            # tier1에서 제거
    s = h["tier2_interpretation"]["strength"]
    assert s["verdict_code"] == "weak" and s["strength_pct"] == 30.0
    assert s["deuk_ryeong_pct"] == 5 and s["deuk_se_pct"] == -50.0
    assert s["boundary_hold"] is False and s["boundary"] is None
    assert ah.validate(h) == []


def test_assemble_does_not_mutate_input():
    build = {"tier1_facts": {"chart": {}, "strength": {"verdict_center": "weak"}},
             "tier2_interpretation": {"yong_shen": {"element": "wood"}}}
    ah.assemble(build)
    assert "strength" in build["tier1_facts"], "호출자 tier1_facts가 파괴됨"


def test_validate_rejects_strength_in_tier1():
    h = ah.assemble(_build(yong_shen={"element": "wood"}))
    h["tier1_facts"]["strength"] = {"x": 1}             # 재배치 위반 주입
    assert any("strength 잔존" in e for e in ah.validate(h))


# ── by_branch favorability(boundary_hold 명식 — §4-2) ─────────────
def test_by_branch_favorability_from_boundary():
    eng = {"verdict_center": "balanced", "strength_pct": 50.0, "boundary_hold": True,
           "candidates": ["quasi_weak", "quasi_strong"], "boundary_evidence": {"nearer": "weak"}}
    t2 = {"yong_shen": {"element": "wood"}, "strength": {"boundary": {
        "strong_branch": {"yong_shen": "fire", "gi_shin": "water"},
        "weak_branch": {"yong_shen": "water", "gi_shin": "fire"},
        "operative_branch": "weak_branch"}}}
    h = ah.assemble({"tier1_facts": {"chart": {}, "strength": eng}, "tier2_interpretation": t2})
    ef = h["derived_lookup"]["element_favorability"]
    assert ef["mode"] == "by_branch" and ef["single"] is None
    assert ef["by_branch"]["operative_branch"] == "weak_branch"
    assert ef["by_branch"]["strong_branch"]["fire"] == "favorable"
    assert ef["by_branch"]["weak_branch"]["water"] == "favorable"
    b = h["tier2_interpretation"]["strength"]["boundary"]
    assert b["candidates"] == ["quasi_weak", "quasi_strong"]      # 엔진 결정론 권위
    assert b["confidence_asymmetry"] == {"nearer": "weak"}        # boundary_evidence echo
    assert ah.validate(h) == []


def test_by_branch_conflict_is_per_branch_fail_loud():
    eng = {"boundary_hold": True, "candidates": ["a", "b"]}
    t2 = {"strength": {"boundary": {
        "strong_branch": {"yong_shen": "wood", "gi_shin": "wood"},   # strong 내부 용=기 충돌
        "weak_branch": {"yong_shen": "water"}, "operative_branch": "strong_branch"}}}
    with pytest.raises(ValueError):
        ah.assemble({"tier1_facts": {"chart": {}, "strength": eng}, "tier2_interpretation": t2})


def test_boundary_char_shape_fails_loud():
    """boundary_hold=true인데 strong_branch가 dict 아닌 글자(구식/오류 shape)면 single로
    조용히 격하하지 않고 fail-loud(boundary 명식을 single로 오표기 차단)."""
    eng = {"boundary_hold": True, "candidates": ["a", "b"]}
    t2 = {"yong_shen": {"element": "wood"},
          "strength": {"boundary": {"strong_branch": "卯", "weak_branch": "酉"}}}
    with pytest.raises(ValueError):
        ah.assemble({"tier1_facts": {"chart": {}, "strength": eng}, "tier2_interpretation": t2})


# ── 엔진 boundary_hold가 favorability 모드를 권위 결정(D1 — 자기모순 차단) ──
def test_mode_gated_on_engine_boundary_hold_false():
    """엔진 boundary_hold=false면 LLM이 boundary를 줘도 boundary 강제 None·mode=single."""
    eng = {"boundary_hold": False, "candidates": None}
    t2 = {"yong_shen": {"element": "wood"}, "strength": {"boundary": {
        "strong_branch": {"yong_shen": "fire"}, "weak_branch": {"yong_shen": "water"},
        "operative_branch": "weak_branch"}}}
    h = ah.assemble({"tier1_facts": {"chart": {}, "strength": eng}, "tier2_interpretation": t2})
    assert h["tier2_interpretation"]["strength"]["boundary"] is None
    assert h["derived_lookup"]["element_favorability"]["mode"] == "single"
    assert ah.validate(h) == []


def test_boundary_hold_true_without_branches_fails_loud():
    """엔진 boundary_hold=true인데 LLM이 강·약 가지 판단을 안 주면 fail-loud."""
    eng = {"boundary_hold": True, "candidates": ["quasi_weak", "quasi_strong"]}
    with pytest.raises(ValueError):
        ah.assemble({"tier1_facts": {"chart": {}, "strength": eng},
                     "tier2_interpretation": {"yong_shen": {"element": "wood"}}})


# ── 결정론 필드 엔진 권위(D2 — R2′ 누출 차단) ────────────────────
def test_llm_candidates_and_source_overridden():
    eng = {"boundary_hold": False, "candidates": None}
    t2 = {"yong_shen": {"element": "wood"},
          "strength": {"candidates": ["LLM_FABRICATED"], "source": "LLM"}}
    h = ah.assemble({"tier1_facts": {"chart": {}, "strength": eng}, "tier2_interpretation": t2})
    s = h["tier2_interpretation"]["strength"]
    assert "candidates" not in s                          # 비-boundary엔 candidates 없음
    assert s["source"] == "derived"                       # LLM source 무력화


# ── 손상 입력 fail-loud(D3 — raw traceback 차단) ──────────────────
def test_malformed_strength_fails_loud():
    with pytest.raises(ValueError):                       # tier1.strength가 dict 아님
        ah.assemble({"tier1_facts": {"chart": {}, "strength": "corrupt"},
                     "tier2_interpretation": {"yong_shen": {"element": "wood"}}})


# ── 미해석 오행 토큰 fail-loud(D4 — 조용한 손실 차단) ─────────────
def test_garbage_element_token_fails_loud():
    with pytest.raises(ValueError):
        ah.assemble(_build(yong_shen={"element": "plasma"}))
