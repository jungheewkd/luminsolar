"""골든 스냅샷 회귀 잠금 — 4모드 출력 동결(CHANGELOG '4모드 diff' 규율의 자동화).

엔진 산출은 입력에 대해 완전 결정론(현재시각·난수 미사용)이므로 바이트 안정적이다.
출력이 바뀌면(가산 필드 포함) 본 테스트가 실패한다 → 의도된 변경이면
`python tests/gen_golden.py`로 베이스라인을 명시 갱신하고 diff를 리뷰·커밋한다.
"""
from __future__ import annotations

import pytest

from tests.conftest import GOLDEN_DIR, read_text, norm
from tests.corpus import TIER1_CASES, JIEQI_CASES, case_json, jieqi_json


def _compare(label: str, live: str):
    path = GOLDEN_DIR / f"{label}.json"
    if not path.exists():
        pytest.fail(f"골든 부재: {path.name} — `python tests/gen_golden.py`로 베이스라인 생성 필요")
    assert norm(read_text(path)) == norm(live), (
        f"골든 회귀: {label}.json 가 현재 엔진 출력과 다름.\n"
        f"의도된 변경이면 `python tests/gen_golden.py`로 갱신 후 diff 리뷰."
    )


@pytest.mark.golden
@pytest.mark.parametrize("c", TIER1_CASES, ids=lambda c: c.label)
def test_golden_tier1(c):
    _compare(c.label, case_json(c))


@pytest.mark.golden
@pytest.mark.parametrize("c", JIEQI_CASES, ids=lambda c: c.label)
def test_golden_jieqi(c):
    _compare(c.label, jieqi_json(c))


@pytest.mark.golden
def test_determinism_stable():
    """같은 입력 두 번 → 바이트 동일 (세션간 드리프트 0 — 시스템 셀링포인트)."""
    for c in TIER1_CASES:
        assert case_json(c) == case_json(c), f"{c.label}: 동일 입력 재현 불일치"
