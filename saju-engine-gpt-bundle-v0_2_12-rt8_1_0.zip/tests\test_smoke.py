"""스모크 — 엔진 import + 핀 케이스 산출 + 4개 CLI 모드가 무사히 도는가."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from tests.conftest import ENGINE_ROOT, PIN
from tests.corpus import TIER1_CASES, JIEQI_CASES, build_case

PY = sys.executable
CLI_ENV = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}


def _run_cli(*args):
    return subprocess.run([PY, "run_emit.py", *args], cwd=str(ENGINE_ROOT),
                          env=CLI_ENV, capture_output=True, text=True, encoding="utf-8")


def test_engine_imports():
    import saju_engine  # noqa
    from tools.emit_tier1_standalone import build_tier1_dict, to_json_str  # noqa
    from tools.emit_jieqi import build_jieqi_dict  # noqa


@pytest.mark.parametrize("c", TIER1_CASES, ids=lambda c: c.label)
def test_tier1_case_builds(c):
    d = build_case(c)
    assert d["schema_version"] == PIN["schema_version"]
    assert d["meta"]["engine_version"] == PIN["engine_version"]
    assert d["meta"]["condition"] == ("A" if c.has_time else "B")


@pytest.mark.parametrize("c", JIEQI_CASES, ids=lambda c: c.label)
def test_jieqi_case_builds(c):
    from tools.emit_jieqi import build_jieqi_dict
    d = build_jieqi_dict(c.year)
    assert d["schema_version"] == PIN["jieqi_schema"]


@pytest.mark.parametrize("args,fence", [
    (["1990-05-15T08:30", "F"], "```tier1_facts"),
    (["1990-05-15T08:30", "F", "--no-time"], "```tier1_facts"),
    (["1990-05-15T08:30", "F", "--divination", "2026-06-14T14:00"], "```tier1_facts"),
    (["--jieqi", "2026"], "```jieqi_facts"),
])
def test_cli_four_modes(args, fence):
    """4개 emit 모드가 UTF-8 환경에서 exit 0 + 올바른 펜스로 시작한다."""
    r = _run_cli(*args)
    assert r.returncode == 0, f"stderr: {r.stderr[:400]}"
    assert r.stdout.lstrip().startswith(fence)
    assert "Traceback" not in r.stderr
