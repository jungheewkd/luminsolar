# saju-engine GPT 번들

사주 원국·대운·관계·강약·매화/일진을 결정론적으로 산출해 `tier1_facts`(인물 스코프)와
`jieqi_facts`(연 스코프) JSON 블록으로 방출하는 엔진. 프롬프트 런타임
(`core_kernel.md` · `ask_modules.md` · `reference_tables.md`)이 이 블록을 전사·해석한다.

## 설정 (3단계)
1. GPT 빌더에서 **Code Interpreter** 활성화
2. 본 zip을 Knowledge에 업로드 (프롬프트 3파일 `core_kernel.md`·`ask_modules.md`·`reference_tables.md`와 함께; 별도 절기 xlsx 불요)
3. 사용자가 생년월일을 입력하면 GPT가 zip을 풀어 `run_emit.py`를 실행해 블록을 산출한다
   (KERNEL [1′] R0′ 〔엔진 채널〕 — LLM 암산이 아니라 코드 실행)

## 실행
```
python3 run_emit.py <ISO출생> <F|M> [경도 또는 --region "지역명"] [--no-time] [--divination <ISO>]
python3 run_emit.py --jieqi <YYYY>
```
예시:
```
python3 run_emit.py 1990-05-15T08:30 F                                   # 표준 (조건 A)
python3 run_emit.py 1990-05-15T08:30 F --no-time                         # 시간 미상 (조건 B)
python3 run_emit.py 1990-05-15T08:30 F --region "부산"                   # 출생지명→경도(진태양시 경도보정)
python3 run_emit.py 1990-05-15T08:30 F --divination 2026-06-13T14:00     # ASK 13 일진·매화
python3 run_emit.py --jieqi 2026                                         # 연 단위 12절 절입·월간지 (인물 무관)
```

## 입력
- **출생**: ISO 8601 (`YYYY-MM-DDTHH:MM`). `--no-time`이면 시주·시간 의존 산출이 조건 B로 처리된다.
- **성별**: `F` | `M` (대운 방향).
- **경도**(선택): 도 단위, 124.0~132.0. 미입력 시 한반도 평균 보정. 범위 밖은 fail-loud(해외 출생 미지원).
- **출생지**(선택): `--region "지역명"` — 시·도 또는 주요 시·군·구. 엔진이 경도로 **결정론 변환**(LLM 추정 아님, 미수록 지명은 fail-loud). 숫자 경도와 동시 입력 시 거부. `solar_dt`는 지방평균태양시(경도보정+DST, 균시차 미적용). 광역 잔차 큰 경북·전남·강원·인천·경남·전북·충남·경기는 시·군·구 권장.

## 출력 schema (핸드셰이크 게이트)
- `tier1_facts` — schema **`tier1.v1.6`**
- `jieqi_facts` — schema **`jieqi.v1.0`**
- 릴리스 표시명(provenance·정보용): `meta.prompt_pin = saju-runtime-8.1.0`
- 빌드 id: `meta.engine_version = 0.2.12`

> **schema 버전이 핸드셰이크 게이트**다. `prompt_pin` 불일치는 정보 고지에 그치며 거동을 바꾸지 않는다(Core R6′ⓐ).

## 커버리지 / fail-loud
- 출생: 1951-01-06(소한) 이후 ~ 2035 수록 절기. jieqi: 1951~2035.
- 범위 밖 입력은 traceback 대신 1줄 한국어 안내로 종료한다(KERNEL ON_FAIL ⓔ) — 간지 추정·재시도 금지.

## 변경 이력
`docs/CHANGELOG.md` 참조.
