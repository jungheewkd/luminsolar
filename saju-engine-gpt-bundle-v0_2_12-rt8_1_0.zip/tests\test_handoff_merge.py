"""handoff_merge CI 게이트 (P3) — ASK 2~6 조각 deep-merge + assemble 통합.

핵심: 조각 결정론 병합(충돌 fail-loud)으로 tier2 재조립을 제거하고, P2가 남긴 BLIND SLOT
(branch_climate·flow.current_*)을 조각에서 흡수하며, day_master는 엔진 파생. 조각 부재 시
P2/legacy 폴백. round-trip(verify)·validate 유지.
직접 실행(pytest 미가용): PYTHONUTF8=1 PYTHONPATH=. py -m pytest tests/test_handoff_merge.py
"""
from __future__ import annotations

import pytest

from tools import assemble_handoff as ah
from tools import handoff_verify as hv
from tools.handoff_merge import merge_fragments
from tests.corpus import build_case, TIER1_CASES


def _ask_fragments():
    """ASK 2~6 stage_output 조각(STAGE CONTRACT output 경로 모사) — non-boundary 명식용."""
    return [
        {"tier1_facts": {"chart": {"branch_climate": {                       # ASK 2 (tier1 컨테이너)
            "year": {"temp": "neutral_t", "humid": "neutral_h"},
            "month": {"temp": "warm", "humid": "dry"},
            "day": {"temp": "neutral_t", "humid": "damp"},
            "hour": {"temp": "cool", "humid": "neutral_h"}}}},
         "tier2_interpretation": {"strength": {"root_notes": "통근 요약"}}},
        {"tier2_interpretation": {"energy_map": {                            # ASK 3
            "active_shins": ["jae"], "dormant_shins": [], "ten_gods": {}, "twelve_stages": {}}}},
        {"tier2_interpretation": {                                           # ASK 4
            "pattern": {"code": "jong_gyeok", "validity": "true"},
            "yong_shen": {"element": "wood", "ten_god": "in"},
            "hee_shen": {"element": "water", "ten_god": "bi_geop"},
            "gi_shin": {"element": "metal", "ten_god": "gwan"},
            "gu_shin": {"element": "earth", "ten_god": "jae"},
            "disease": ["weak_self"],
            "clarity": {"mode": "single", "single": {"grade": "pure", "sources": []}}}},
        {"tier2_interpretation": {"yong_mechanism": ["suppress"]}},          # ASK 5
        {"tier1_facts": {"flow": {                                           # ASK 6
            "current_daewoon": "庚子",
            "current_se_woon": {"year": 2026, "ganji": "丙午", "summary": "삼중 역동성 요약"}}}},
    ]


# ── merge_fragments 결정론·충돌 ────────────────────────────────────
def test_merge_reconstructs():
    parts = [{"tier2_interpretation": {"a": 1}},
             {"tier2_interpretation": {"b": {"c": 2}}},
             {"tier1_facts": {"x": 1}}]
    assert merge_fragments(parts) == {"tier2_interpretation": {"a": 1, "b": {"c": 2}}, "tier1_facts": {"x": 1}}


def test_merge_same_value_no_conflict():
    assert merge_fragments([{"x": {"y": 1}}, {"x": {"y": 1}}]) == {"x": {"y": 1}}


def test_merge_conflict_fail_loud():
    with pytest.raises(ValueError):
        merge_fragments([{"tier2_interpretation": {"pattern": {"code": "jong_gyeok"}}},
                         {"tier2_interpretation": {"pattern": {"code": "hwa_gyeok"}}}])


def test_merge_rejects_empty_and_nondict():
    with pytest.raises(ValueError):
        merge_fragments([])
    with pytest.raises(ValueError):
        merge_fragments([{"a": 1}, "notdict"])


def test_merge_non_destructive():
    f = [{"tier2_interpretation": {"x": {"y": 1}}}]
    merge_fragments(f)
    assert f[0] == {"tier2_interpretation": {"x": {"y": 1}}}   # 입력 비파괴


# ── assemble P3 경로: 조각 흡수 + 엔진 파생 + 폴백 ─────────────────
def test_assemble_fragments_path():
    raw = build_case(next(c for c in TIER1_CASES if c.label == "samhap_full"))   # boundary_hold=False
    h = ah.assemble({"engine_tier1": raw, "tier2_fragments": _ask_fragments()})
    # BLIND SLOT이 조각에서 채워짐
    assert h["tier1_facts"]["chart"]["branch_climate"] is not None
    assert h["tier1_facts"]["flow"]["current_daewoon"] == "庚子"
    assert h["tier1_facts"]["flow"]["current_se_woon"]["year"] == 2026
    # tier2는 조각 머지
    assert h["tier2_interpretation"]["pattern"]["code"] == "jong_gyeok"
    assert h["tier2_interpretation"]["yong_mechanism"] == ["suppress"]
    # day_master = 엔진 결정론 파생
    assert h["tier2_interpretation"]["day_master"]["stem"] == raw["chart"]["day"]["stem"]
    # strength = 엔진 권위(rehome)
    assert h["tier2_interpretation"]["strength"]["verdict_code"] == raw["strength"]["verdict_center"]
    # derived_lookup = 용희기구 결정론
    assert h["derived_lookup"]["element_favorability"]["single"]["wood"] == "favorable"
    # 구조 + tier1 엔진 대조 정합
    assert ah.validate(h) == []
    assert hv.verify_against_engine(h, raw) == []


def test_assemble_fragment_conflict_fails():
    raw = build_case(next(c for c in TIER1_CASES if c.label == "samhap_full"))
    bad = _ask_fragments() + [{"tier2_interpretation": {"pattern": {"code": "hwa_gyeok"}}}]
    with pytest.raises(ValueError):
        ah.assemble({"engine_tier1": raw, "tier2_fragments": bad})


def test_assemble_fallback_without_fragments():
    """조각 부재(verbose/단발) → legacy tier2 폴백(P2 경로) 정상."""
    raw = build_case(next(c for c in TIER1_CASES if c.label == "samhap_full"))
    h = ah.assemble({"engine_tier1": raw, "tier2_interpretation": {"yong_shen": {"element": "wood"}}})
    assert ah.validate(h) == []
    assert h["tier1_facts"]["chart"]["branch_climate"] is None   # 조각 없으니 BLIND SLOT 잔존(null)
