"""STAGE CONTRACT 헤더 ↔ module_manifest 정합 CI 게이트.

ask_modules.md 의 ```stage-contract``` 헤더를 SoT로 파싱해
  (1) 검증 위반 0 (output 충돌·의존순서·judgment_scope 실재),
  (2) 커밋된 module_manifest.json 과 무드리프트(헤더 수정 후 재생성 강제),
  (3) output 소유권 잠금 — disease=ask_4 / yong_mechanism=ask_5 / operative_branch=ask_6
      단일 소유(정합화 3건 회귀 차단)
를 단언한다. 프롬프트 .md 부재(번들-only 배포)면 graceful skip.

직접 실행(pytest 미가용 환경):  python tools/gen_manifest.py --check
"""
from __future__ import annotations

import pytest

from tools import gen_manifest as gm

pytestmark = pytest.mark.skipif(
    not gm.ASK_MODULES.exists(), reason="ask_modules.md 부재(번들-only 배포)"
)


def _contracts():
    return gm.parse_contracts(gm.ASK_MODULES.read_text(encoding="utf-8"))


def test_seven_stage_contracts_parsed():
    c = _contracts()
    assert set(c) == set(gm.BUILD_RANK), f"파싱된 스테이지 = {sorted(c)}"


def test_no_validation_violations():
    assert gm.validate(_contracts()) == []


def test_manifest_in_sync_with_headers():
    live = gm._dumps(gm.build_manifest(_contracts()))
    assert gm.MANIFEST.exists(), "module_manifest.json 미존재 — `python tools/gen_manifest.py` 실행 필요"
    committed = gm.MANIFEST.read_text(encoding="utf-8").replace("\r\n", "\n")
    assert committed == live, "헤더와 manifest 드리프트 — `python tools/gen_manifest.py` 재생성·커밋 필요"


@pytest.mark.parametrize("leaf, owner", [
    ("tier2_interpretation.disease", "ask_4"),
    ("tier2_interpretation.yong_mechanism", "ask_5"),
    ("tier2_interpretation.strength.boundary.operative_branch", "ask_6"),
])
def test_output_ownership_locked(leaf, owner):
    """정합화 3건(교차모듈 충돌 해소)이 빌더 단일 소유로 잠겨 있는지."""
    c = _contracts()
    producers = [cid for cid in gm.BUILDERS if cid in c and leaf in c[cid]["output"]]
    assert producers == [owner], f"{leaf} 산출 = {producers}, 기대 [{owner}]"
