"""문서·헤더 버전 정합성 잠금 (드리프트 회귀 게이트 — R2 하네스 확장).

배경: emit 산출값(schema_version·engine_version·prompt_pin)은 test_smoke/test_invariants가
이미 conftest PIN으로 잠근다. 그러나 *산출물이 아닌 사람이 쓰는 문서*의 버전 문자열
— 프롬프트 .md 헤더·핸드셰이크 게이트 RULE 문구·CHANGELOG 최상단 릴리스 행·BUNDLE_README·
emitter docstring — 은 어떤 테스트도 보지 않아 드리프트가 잠복했다.
  실사건: core_kernel.md 핸드셰이크 게이트 RULE이 schema를 `tier1.v1.4`로 들고 있어 emit의
  `tier1.v1.6`과 2버전(7.5.0·7.6.0 가산 범프) 어긋나 있었다. 본 모듈이 그 사각을 메운다.

설계 원칙: '중복 존재'가 아니라 '값 불일치'만 실패시킨다 — 지연적재/handoff 견고성을 위해
같은 규칙을 모듈에 의도적으로 재서술하는 것(강화적 재서술)은 허용하고, 버전 상수가 PIN과
갈라질 때만 잡는다. DRY를 강요하지 않고 정합성만 보장한다.
프롬프트 3파일은 번들 밖(루트 = _extract.parent)에 있으므로 부재 시 graceful skip
(프롬프트 미동봉 배포 번들 단독 실행 호환).
"""
from __future__ import annotations

import pytest

from tests.conftest import ENGINE_ROOT, PIN, read_text

# 프롬프트 3파일 위치 = 번들 루트의 상위(BUNDLE_README 설정 절차: zip + .md를 함께 업로드).
PROMPT_ROOT = ENGINE_ROOT.parent
PROMPT_FILES = ("core_kernel.md", "ask_modules.md", "reference_tables.md")

# PIN = 엔진 emit이 내는 값(단일 진실원). 문서 버전 문자열은 이와 동치여야 한다.
SCHEMA = PIN["schema_version"]      # tier1.v1.6
JIEQI = PIN["jieqi_schema"]         # jieqi.v1.0
PIN_STR = PIN["prompt_pin"]         # saju-runtime-8.1.0
ENGINE = PIN["engine_version"]      # 0.2.12

# 과거(드리프트) tier1 schema — 현행 프롬프트/README/emitter docstring엔 잔존하면 안 된다.
# (CHANGELOG '릴리스 이력' 행은 과거 버전을 정당하게 보유하므로 본 스캔의 대상이 아니다.)
STALE_TIER1 = ("tier1.v1.3", "tier1.v1.4", "tier1.v1.5")
# BUNDLE_README가 과거에 들고 있던 stale pin/engine(현행엔 없어야 함).
STALE_README = ("saju-runtime-7.3.0", "0.2.7")


def _existing_prompt_files():
    return [PROMPT_ROOT / n for n in PROMPT_FILES if (PROMPT_ROOT / n).exists()]


def test_prompt_md_headers_match_pin():
    """3개 프롬프트 .md 헤더가 현행 schema/jieqi/pin을 싣는다(번들 미동봉 시 skip)."""
    files = _existing_prompt_files()
    if not files:
        pytest.skip("프롬프트 .md가 번들 루트 상위에 없음(단독 배포 번들) — 헤더 정합 검사 생략")
    for p in files:
        head = "\n".join(read_text(p).splitlines()[:8])   # 헤더 블록(호환·릴리스 핀 줄)
        assert SCHEMA in head, f"{p.name} 헤더에 현행 {SCHEMA} 없음"
        assert JIEQI in head, f"{p.name} 헤더에 {JIEQI} 없음"
        assert PIN_STR in head, f"{p.name} 헤더에 {PIN_STR} 없음"


def test_core_kernel_handshake_gate_not_stale():
    """핸드셰이크 게이트 RULE이 현행 tier1 schema를 들고 과거값이 잔존하지 않는다.

    이 테스트가 있었다면 core_kernel.md:74의 tier1.v1.4 잔존을 즉시 잡았다.
    """
    p = PROMPT_ROOT / "core_kernel.md"
    if not p.exists():
        pytest.skip("core_kernel.md 부재 — 게이트 정합 검사 생략")
    body = read_text(p)
    assert SCHEMA in body, f"core_kernel.md에 현행 schema {SCHEMA} 없음"
    stale = [v for v in STALE_TIER1 if v in body]
    assert not stale, f"core_kernel.md에 과거 schema 잔존: {stale} (핸드셰이크 게이트 드리프트)"


def test_bundle_readme_matches_pin():
    """BUNDLE_README가 현행 schema/jieqi/pin/engine을 싣고 과거값이 없다."""
    body = read_text(ENGINE_ROOT / "BUNDLE_README.md")
    for v in (SCHEMA, JIEQI, PIN_STR, ENGINE):
        assert v in body, f"BUNDLE_README에 현행 {v} 없음"
    for v in (*STALE_TIER1, *STALE_README):
        assert v not in body, f"BUNDLE_README에 과거값 잔존: {v}"


def test_changelog_top_release_row_matches_pin():
    """CHANGELOG에 현행 pin·engine·schema를 한 줄에 함께 싣는 릴리스 행이 존재한다."""
    body = read_text(ENGINE_ROOT / "docs" / "CHANGELOG.md")
    has_row = any(PIN_STR in line and ENGINE in line and SCHEMA in line
                  for line in body.splitlines())
    assert has_row, f"CHANGELOG에 현행({PIN_STR}·{ENGINE}·{SCHEMA})을 함께 싣는 릴리스 행 없음"


def test_emitter_docstrings_not_stale_schema():
    """두 emitter 모듈 docstring이 과거 tier1 schema를 들고 있지 않다."""
    for rel in ("tools/emit_tier1_standalone.py", "tools/emit_jieqi.py"):
        head = "\n".join(read_text(ENGINE_ROOT / rel).splitlines()[:16])   # 모듈 docstring 범위
        stale = [v for v in STALE_TIER1 if v in head]
        assert not stale, f"{rel} docstring에 과거 schema 잔존: {stale}"
