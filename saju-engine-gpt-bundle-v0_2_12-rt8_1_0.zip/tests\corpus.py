"""R2 회귀 코퍼스 — 핀 고정 엣지케이스 명식 + 임의명식 표본 생성기.

⚠️ 본 코퍼스의 모든 tier1 케이스는 _scan_edges.py(23,904 명식 그리드 스캔)로
   '실제로 해당 코드 경로를 타는' 입력을 실측 발견해 고정한 것이다(추측 아님).
   각 case.note에 어느 결정론 분기를 커버하는지 기록한다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass(frozen=True)
class Tier1Case:
    label: str
    birth: str                 # ISO 8601
    has_time: bool
    gender: str                # M | F
    longitude: Optional[float] = None
    birth_place: Optional[str] = None  # §A6 지역 lookup — 숫자 경도 미입력 시 지명→경도
    divination: Optional[str] = None   # ISO — ASK12 일진·매화
    note: str = ""


@dataclass(frozen=True)
class JieqiCase:
    label: str
    year: int
    note: str = ""


# ── 핀 고정 tier1 케이스 (라벨 = 골든 파일명) ──────────────────────
TIER1_CASES: List[Tier1Case] = [
    Tier1Case("canonical_A", "1990-05-15T08:30", True, "F",
              note="BUNDLE_README 표준 예제(조건 A)"),
    Tier1Case("canonical_B", "1990-05-15T08:30", False, "F",
              note="조건 B(시간 미상) — 시주 None, 대운 ±1년 유예 경로"),
    Tier1Case("lichun_before", "2000-02-03T12:00", True, "M",
              note="입춘 경계 직전 → effective_year=1999(己卯)"),
    Tier1Case("lichun_after", "2000-02-05T12:00", True, "M",
              note="입춘 경계 직후 → effective_year=2000(庚辰). 1일 차로 년주 전환"),
    Tier1Case("qi_neither_weak", "1955-02-11T14:30", True, "M",
              note="qi_xing=neither(일간 고립) → verdict weak, pct 12.0"),
    Tier1Case("qi_only", "1952-04-21T08:30", True, "M",
              note="qi_xing=qi_only(투출 有·뿌리 無) → quasi_strong, boundary_hold"),
    Tier1Case("xing_only_a6", "1952-01-01T01:30", True, "M",
              note="★I2 핵심: qi_xing=xing_only → A6 balanced 승격 + 년지캡40 발동(year_adj 87.75→40)"),
    Tier1Case("qi_both_strong", "1952-02-11T08:30", True, "M",
              note="qi_xing=both → verdict strong, pct 65.5"),
    Tier1Case("samhap_full", "1952-07-01T23:30", True, "M",
              note="삼합 combine_3 'formed' 성립 + 충 동시(통관∥비등 혼재) → strong, pct 70.5"),
    Tier1Case("samhap_pure", "1952-08-11T23:30", True, "M",
              note="삼합 combine_3 'formed' + 동일명식 clash 無(순수 통관 게이트 — samhap_full의 삼합∥충 혼재와 분리) → balanced, pct 54.5"),
    Tier1Case("dst_window", "1955-06-15T08:30", True, "M",
              note="서머타임 구간 → dst_applied=True, boundary_dt −1h(07:30)"),
    Tier1Case("utc830_1954", "1954-06-15T08:30", True, "M",
              note="1954 UTC+8:30 표준시 → longitude_correction_min=0(1953은 −30)"),
    Tier1Case("with_longitude", "1986-11-18T05:20", True, "M", longitude=129.0,
              note="명시 경도(부산권) 진태양시 보정 경로"),
    Tier1Case("condB_samhap", "1952-07-01T23:30", False, "M",
              note="조건 B + 관계 풍부 — hour None에서 relations/strength/daewoon 전 경로 무사"),
    Tier1Case("divination", "1990-05-15T08:30", True, "F", divination="2026-06-14T14:00",
              note="ASK12 — divination 블록(일진·오서둔·daily_signals) + maehwa 괘 산출"),
    Tier1Case("region_ulleung", "1990-05-15T08:30", True, "M", birth_place="울릉도",
              note="★§A6 지역 lookup: 울릉도(130.9057)→경도보정 −16분(본토 동해안 −22~23보다 적게). birth_longitude 실효경도 전사"),
    Tier1Case("region_dokdo", "1990-05-15T08:30", True, "M", birth_place="독도",
              note="★§A6 지역 lookup: 독도(131.8692)→−13분(0.5 경계 ROUND_HALF_UP 정정값, −12 아님). 국토 최동단·132 상한 직전"),
]

# ── 핀 고정 jieqi 케이스 ──────────────────────────────────────────
JIEQI_CASES: List[JieqiCase] = [
    JieqiCase("jieqi_2026", 2026, note="표준 연도 — 12절 절입 + 월간지"),
    JieqiCase("jieqi_1951", 1951, note="커버리지 하한 엣지"),
    JieqiCase("jieqi_2035", 2035, note="커버리지 상한 엣지"),
]


# ── 빌더 (지연 import — corpus 임포트 자체는 엔진 불요) ───────────
def build_case(c: Tier1Case) -> dict:
    from tools.emit_tier1_standalone import build_tier1_dict
    return build_tier1_dict(
        datetime.fromisoformat(c.birth),
        has_time=c.has_time,
        gender=c.gender,
        longitude=c.longitude,
        birth_place=c.birth_place,
        divination_dt=datetime.fromisoformat(c.divination) if c.divination else None,
    )


def case_json(c: Tier1Case) -> str:
    from tools.emit_tier1_standalone import to_json_str
    return to_json_str(build_case(c))


def jieqi_json(c: JieqiCase) -> str:
    from tools.emit_jieqi import build_jieqi_dict, to_json_str
    return to_json_str(build_jieqi_dict(c.year))


# ── 임의명식 표본 (불변식 속성 테스트용 — 결정론 그리드) ──────────
def broad_sample(condition: str = "A"):
    """결정론적 명식 표본. condition 'A'(시간 有) / 'B'(시간 無)."""
    has_time = condition == "A"
    out = []
    for year in range(1955, 2031, 8):          # 1955,1963,...,2027 (10개)
        for month in (2, 5, 8, 11):
            for day in (3, 18):
                for t in ("09:40", "22:50"):
                    for g in ("M", "F"):
                        out.append((f"{year:04d}-{month:02d}-{day:02d}T{t}", has_time, g))
    return out                                  # 10*4*2*2*2 = 640 charts
