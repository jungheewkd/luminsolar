"""handoff_verify CI 게이트 — 봉인 handoff ↔ 엔진 raw tier1 no-new-values 대조(P1·접근 A).

정상 봉인 위반0 + 변이(오전사) 검출 + 지장간 역순 함정 회귀 + 투영 멱등.
직접 실행(pytest 미가용): PYTHONUTF8=1 PYTHONPATH=. py -m pytest tests/test_handoff_verify.py
"""
from __future__ import annotations

import copy

import pytest

from tools import assemble_handoff as ah
from tools import handoff_verify as hv
from tests.corpus import build_case, TIER1_CASES

# 대표 케이스: 조건 A/B · 삼합/충 · 경계보류 · 지역경도
_LABELS = ("canonical_A", "canonical_B", "samhap_full", "qi_only", "region_dokdo")
_CASES = {c.label: c for c in TIER1_CASES if c.label in _LABELS}


def _ref_handoff(raw: dict) -> dict:
    """raw에서 '정확히 전사된' handoff를 결정론 구성 — 검증 기준값(투영을 handoff 형상으로 환원)."""
    proj = hv.project_tier1_verifiable(raw)
    chart = dict(proj["chart"])
    rels = []
    for r in raw["relations"]:
        ch = "stem" if r["type"] in hv._STEM_RELATIONS else "branch"
        members = [{"pos": f"{p}_{ch}", "char": raw["chart"][p][ch]} for p in r["positions"]]
        rels.append({"type": r["type"], "status": r["status"], "members": members,
                     "result": r["element_transformed"]})
    chart["relations"] = rels
    t1 = {"chart": chart,
          "true_solar_time": {"longitude_adjust_min": proj["true_solar_time"]["longitude_adjust_min"]},
          "flow": {"direction": proj["flow"]["direction"],
                   "daewoon_table": proj["flow"]["daewoon_table"],
                   "flow_signals": proj["flow"]["flow_signals"]}}
    s = {k: v for k, v in proj["strength"].items() if not k.startswith("_")}
    if "_boundary" in proj["strength"]:
        s["boundary"] = {"candidates": proj["strength"]["_boundary"]["candidates"],
                         "confidence_asymmetry": proj["strength"]["_boundary"]["confidence_asymmetry"]}
    return {"schema": ah.SCHEMA, "tier1_facts": t1, "tier2_interpretation": {"strength": s}}


def _mutate(h, path, value):
    h = copy.deepcopy(h)
    node = h
    for k in path[:-1]:
        node = node[k]
    node[path[-1]] = value
    return h


# ── 정상 봉인 위반0 (전 대표 케이스) ──────────────────────────────
@pytest.mark.parametrize("label", _LABELS)
def test_clean_handoff_passes(label):
    raw = build_case(_CASES[label])
    h = _ref_handoff(raw)
    assert hv.verify_against_engine(h, raw) == []
    # 통합: 깨끗한 tier1이면 raw_t1 경로가 구조 검증 위에 추가 위반을 0건 얹는다
    assert ah.validate(h, raw_t1=raw) == ah.validate(h)


def test_validate_wires_raw_t1():
    """validate(h, raw_t1)가 오전사 시 verify 위반을 구조 검증 위에 추가하는지(배선 확인)."""
    raw = build_case(_CASES["canonical_A"])
    h = _ref_handoff(raw)
    bad = _mutate(h, ["tier1_facts", "chart", "pillars", "year"], "甲子")
    extra = set(ah.validate(bad, raw_t1=raw)) - set(ah.validate(bad))
    assert any("chart.pillars.year" in e for e in extra)


# ── 지장간 역순 함정: 엔진 [본기,중기,여기] → handoff {yeo,jung,bon} ──
def test_jijanggan_inversion_locked():
    raw = build_case(_CASES["canonical_A"])
    proj = hv.project_tier1_verifiable(raw)
    seen_distinct = False
    for n in ("year", "month", "day"):
        p = raw["chart"][n]
        if p is None:
            continue
        jjg = proj["chart"]["ji_jang_gan"][n]
        assert jjg["bon"] == p["hidden_stems"][0]      # 본기 = hidden[0]
        assert jjg["jung"] == p["hidden_stems"][1]     # 중기 = hidden[1]
        assert jjg["yeo"] == p["hidden_stems"][2]      # 여기 = hidden[2] (역순)
        if jjg["bon"] != jjg["yeo"]:
            seen_distinct = True
    assert seen_distinct, "본기≠여기인 기둥이 있어야 역순 함정이 의미를 가짐"


def test_mutation_jijanggan_swap_detected():
    """본기↔여기 뒤바꾼 오전사 — 값집합 동일이라 position-aware 대조 아니면 못 잡는다."""
    raw = build_case(_CASES["canonical_A"])
    h = _ref_handoff(raw)
    # 본기≠여기인 첫 기둥에서 swap
    target = None
    for n in ("year", "month", "day"):
        jjg = h["tier1_facts"]["chart"]["ji_jang_gan"][n]
        if jjg and jjg["bon"] != jjg["yeo"]:
            target = n
            break
    assert target is not None
    jjg = h["tier1_facts"]["chart"]["ji_jang_gan"][target]
    swapped = {"yeo": jjg["bon"], "jung": jjg["jung"], "bon": jjg["yeo"]}
    bad = _mutate(h, ["tier1_facts", "chart", "ji_jang_gan", target], swapped)
    assert any(f"ji_jang_gan.{target}" in e for e in hv.verify_against_engine(bad, raw))


# ── 변이 검출(오전사) ──────────────────────────────────────────────
def test_mutation_pillar_detected():
    raw = build_case(_CASES["canonical_A"])
    h = _ref_handoff(raw)
    bad = _mutate(h, ["tier1_facts", "chart", "pillars", "year"], "甲子")
    assert any("chart.pillars.year" in e for e in hv.verify_against_engine(bad, raw))


def test_mutation_five_elements_detected():
    raw = build_case(_CASES["canonical_A"])
    h = _ref_handoff(raw)
    bad = _mutate(h, ["tier1_facts", "chart", "five_elements", "month"], ["metal", "metal"])
    assert any("chart.five_elements.month" in e for e in hv.verify_against_engine(bad, raw))


def test_mutation_strength_pct_detected():
    raw = build_case(_CASES["samhap_full"])
    h = _ref_handoff(raw)
    bad = _mutate(h, ["tier2_interpretation", "strength", "strength_pct"], 99.9)
    assert any("strength.strength_pct" in e for e in hv.verify_against_engine(bad, raw))


def test_mutation_relation_char_detected():
    raw = build_case(_CASES["samhap_full"])
    h = _ref_handoff(raw)
    if not h["tier1_facts"]["chart"]["relations"]:
        pytest.skip("relations 없음")
    bad = copy.deepcopy(h)
    bad["tier1_facts"]["chart"]["relations"][0]["members"][0]["char"] = "戌"
    assert any("char" in e for e in hv.verify_against_engine(bad, raw))


def test_mutation_flow_signals_echo_detected():
    raw = build_case(_CASES["samhap_full"])
    h = _ref_handoff(raw)
    bad = copy.deepcopy(h)
    bad["tier1_facts"]["flow"]["flow_signals"]["daewoon"][0]["signal_count"] = 999
    assert any("flow_signals.daewoon[0].signal_count" in e for e in hv.verify_against_engine(bad, raw))


def test_missing_strength_detected():
    raw = build_case(_CASES["canonical_A"])
    h = _ref_handoff(raw)
    h["tier2_interpretation"]["strength"] = {}
    assert any("strength 누락" in e for e in hv.verify_against_engine(h, raw))


# ── 규약·멱등 ──────────────────────────────────────────────────────
def test_direction_renamed_to_handoff_vocab():
    for label in _LABELS:
        proj = hv.project_tier1_verifiable(build_case(_CASES[label]))
        assert proj["flow"]["direction"] in ("forward", "backward")


def test_projection_idempotent():
    raw = build_case(_CASES["canonical_A"])
    assert hv.project_tier1_verifiable(raw) == hv.project_tier1_verifiable(raw)


# ── boundary 라우팅 내부정합 (증분3 — handoff-only BLIND 검사) ──────────
def _boundary_handoff():
    """boundary_hold=true 봉인의 정상 골든 형상(SYNTHETIC_BOUNDARY captured tier2 기준).
    operative_branch=strong_branch · clarity.by_branch={strong,weak} — 정합."""
    from tests.tier2_boundary_corpus import SYNTHETIC_BOUNDARY
    t2 = copy.deepcopy(SYNTHETIC_BOUNDARY.captured_tier2)
    return {"tier2_interpretation": t2}


def test_boundary_consistency_clean_passes():
    """정상 boundary 골든(operative_branch∈{strong,weak}_branch · clarity.by_branch 키 정합)은 위반0."""
    h = _boundary_handoff()
    assert hv.validate_boundary_consistency(h) == []


def test_boundary_consistency_skips_when_absent():
    """boundary·clarity.by_branch 부재(boundary_hold=false 골든)는 검사 건너뜀 — 위반0(BLIND-safe)."""
    assert hv.validate_boundary_consistency({}) == []
    assert hv.validate_boundary_consistency(
        {"tier2_interpretation": {"strength": {"boundary": None},
                                  "clarity": {"by_branch": None}}}) == []


def test_boundary_operative_branch_illegal_value_detected():
    """멤버십 검사: operative_branch가 {strong_branch, weak_branch} 밖이면 검출."""
    h = _boundary_handoff()
    h["tier2_interpretation"]["strength"]["boundary"]["operative_branch"] = "middle_branch"
    assert any("operative_branch 미상 코드" in e
               for e in hv.validate_boundary_consistency(h))


def test_boundary_clarity_cross_key_mismatch_detected():
    """cross-key 검사: operative_branch=strong_branch인데 clarity.by_branch에 strong 키 부재 시 검출."""
    h = _boundary_handoff()
    h["tier2_interpretation"]["strength"]["boundary"]["operative_branch"] = "strong_branch"
    h["tier2_interpretation"]["clarity"]["by_branch"] = {"weak": {"grade": "mid"}}
    assert any("clarity.by_branch operative 가지 불일치" in e
               for e in hv.validate_boundary_consistency(h))
