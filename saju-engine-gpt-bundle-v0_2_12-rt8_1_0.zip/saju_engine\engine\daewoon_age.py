"""Step 5 — 대운 방향·기준절·시작나이 엔진 (§A7 / ASK1 §5-1·5-2).

§5-2의 DOY·MOD·borrow 경로는 LLM 혼합단위 산술 오류 방지 비계 — timedelta 뺄셈이 원천 대체한다
(borrow [3]은 timedelta가 본질적으로 내장: 1988-12-29 20:00 → 1989-01-05 17:46 = 6일 21:46, 정확히 6.9069일).
[5] 역산 검증도 동일 이유로 불요.

- 기준절(D-011): 순행 = strictly > 최초 節 / 역행 = ≤ 최후 節. 역행+정각 출생 → 0.0세 (G-009 잠금).
- 반올림(D-004/CONVENTIONS §7): Decimal ROUND_HALF_UP — A는 0.1, B는 정수+±1년.
- 산술 경로: 분 정밀 유리수 Decimal(분)/1440 — 오라클(float 경유)과 *의도적 별도 구현*(D-017 복식부기),
  0.1 자리에서 동치임을 골든이 보증.
- 대운 간지표(§5-3)는 월주 의존 → Step 7 소관. 본 모듈은 방향·기준절·나이까지.
- Condition B(D-023): clock=00:00 가정이 DST 구간이면 경계일이 1일 밀릴 수 있으나 ±1년 유예 표기가 흡수.
- 커버리지: 순행 상한 = 마지막 수록 節 — 이후 출생 순행은 LookupError fail-loud.
  (standalone emitter v0.2.1+: extended 로더 채택으로 상한 = 2035 대설 — D-049. 다음 절벽 = 2035.)
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal

from saju_engine.assets.solar_terms import SolarTerms
from saju_engine.constants import Q_DAEWOON, STEM_INDEX, sexagenary_from_index

Direction = Literal["forward", "reverse"]


def daewoon_direction(year_stem: str, gender: Literal["M", "F"]) -> Direction:
    """§5-1 표: (년간 음양 × 성별). 양간+남 / 음간+여 = 순행."""
    if gender not in ("M", "F"):
        raise ValueError(f"gender는 M/F: {gender!r}")
    yang = STEM_INDEX[year_stem] % 2 == 0
    return "forward" if (yang and gender == "M") or (not yang and gender == "F") else "reverse"


@dataclass(frozen=True)
class DaewoonAgeResult:
    direction: Direction
    reference_jieqi: str
    reference_jieqi_dt: datetime
    interval_days: Decimal            # 검산 echo (표시용 0.0001 quantize)
    start_age: float
    start_age_uncertainty_years: int  # A=0, B=1
    has_time: bool


def daewoon_age_for_birth(boundary_dt: datetime, *, gender: Literal["M", "F"],
                          year_stem: str, has_time: bool, st: SolarTerms) -> DaewoonAgeResult:
    direction = daewoon_direction(year_stem, gender)
    if direction == "forward":
        jie, jdt = st.next_jie(boundary_dt)   # strictly >
    else:
        jie, jdt = st.prev_jie(boundary_dt)   # ≤
    if has_time:
        minutes = abs(int(round((jdt - boundary_dt).total_seconds() / 60)))
        days = Decimal(minutes) / Decimal(1440)               # 분 정밀 유리수
        age = float((days / 3).quantize(Q_DAEWOON, rounding=ROUND_HALF_UP))
        unc = 0
    else:
        days = Decimal(abs((jdt.date() - boundary_dt.date()).days))
        age = float((days / 3).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        unc = 1
    return DaewoonAgeResult(direction=direction, reference_jieqi=jie, reference_jieqi_dt=jdt,
                            interval_days=days.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP),
                            start_age=age, start_age_uncertainty_years=unc, has_time=has_time)


def daewoon_ganji_table(month_pillar_index: int, direction: Direction,
                        start_age: float, n: int = 8) -> list:
    """§5-3 대운 간지: 월주에서 순행 +1 / 역행 −1 (60갑자). (age, ganji) 원시쌍 — start_year 채움은 Step 12.
    Step 7에서 해제(D-024): 월주 게이트 통과 후에만 산출 가능."""
    step = 1 if direction == "forward" else -1
    return [(round(start_age + 10 * k, 1),
             sexagenary_from_index((month_pillar_index + step * (k + 1)) % 60))
            for k in range(n)]
