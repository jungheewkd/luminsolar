"""saju_engine.constants — 인덱스 앵커 단일 정의처 (CONVENTIONS §8, S8 해소).

다른 모듈에서 천간/지지/60갑자 인덱스를 재정의하는 것을 금지한다.
이 파일의 값 변경 = CONVENTIONS 변경 = DECISIONS.md ADR 필수.
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal

# ── 천간·지지 (S8) ──────────────────────────────────────────────
STEMS = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"]          # index 0..9
BRANCHES = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"]  # index 0..11
STEM_INDEX = {s: i for i, s in enumerate(STEMS)}
BRANCH_INDEX = {b: i for i, b in enumerate(BRANCHES)}

# ── 60갑자 ──────────────────────────────────────────────────────
SEXAGENARY_YEAR_EPOCH = 1924  # 1924 = 甲子 = index 0  (Core §A1)


def sexagenary_from_index(n: int) -> str:
    """60갑자 인덱스(0=甲子) → 간지 문자열."""
    return STEMS[n % 10] + BRANCHES[n % 12]


def year_sexagenary_index(effective_year: int) -> int:
    """입춘 보정된 명리학적 연도 → 60갑자 인덱스. (경계 판정은 Step 4 소관 — 여기는 인덱스만)"""
    return (effective_year - SEXAGENARY_YEAR_EPOCH) % 60


# ── 일진 epoch (S8 / Core §A5) — JDN 산식은 큐레이션 전용, 런타임 미사용 ──
DAY_PILLAR_EPOCH = date(1900, 1, 31)   # = 甲辰
DAY_PILLAR_EPOCH_INDEX = 40

# 요일: Python date.weekday()가 월=0…일=6으로 Core §A5 규약과 동일 → 별도 앵커표 불요.
WEEKDAY_KO = "월화수목금토일"

# ── 시진 경계 (CONVENTIONS §6 — 반개구간, 정각=다음 시진) ────────
# (지지 index, 시작시, 끝시) — 子시는 [23,24)∪[0,1) 두 조각. 일진 귀속과 독립.
HOUR_BRANCH_INTERVALS = [
    (0, 23, 24), (0, 0, 1),                      # 子
    (1, 1, 3), (2, 3, 5), (3, 5, 7), (4, 7, 9),  # 丑寅卯辰
    (5, 9, 11), (6, 11, 13), (7, 13, 15),        # 巳午未
    (8, 15, 17), (9, 17, 19), (10, 19, 21), (11, 21, 23),  # 申酉戌亥
]

# ── 진태양시 (CONVENTIONS §2) ───────────────────────────────────
STANDARD_MERIDIAN_DEG = 135.0
KOREA_LONGITUDE_RANGE = (124.0, 132.0)  # D-025: 한반도(도서 포함) — 본 엔진의 DST·표준시 이력은 한국 전제, 밖은 fail-loud
DEFAULT_LONGITUDE_CORRECTION_MIN = -30  # 출생지 미입력 시 (한반도 평균)
# 경도보정 0분 구간 (법정시 UTC+8:30 — §A6 ②): (시작일, 종료일) 폐구간
UTC830_PERIODS = [
    (date(1908, 4, 1), date(1911, 12, 31)),
    (date(1954, 3, 21), date(1961, 8, 9)),
]
# 1954 예외 플래그 구간 (§A3 — xlsx UTC+9 수록 vs 법정시 +8:30)
FLAG_1954_WINDOW = (date(1954, 3, 21), date(1954, 12, 31))
FLAG_1954_TOLERANCE_MIN = 30

# ── 반올림 (CONVENTIONS §7) ─────────────────────────────────────
Q_DAEWOON = Decimal("0.1")
Q_STRENGTH = Decimal("0.1")

# ── Strength% 파라미터 (Step 10 사용 · Step 14 캘리브레이션 대상 — ASK2 §1-5) ──
STRENGTH_WEIGHTS = {"deuk_ryeong": Decimal("0.40"), "deuk_ji": Decimal("0.35"), "deuk_se": Decimal("0.25")}
STRENGTH_THRESHOLDS = {"strong": 65, "quasi_strong": 55, "balanced": 45, "quasi_weak": 35}  # §1-5 임계표
DEUK_RYEONG_RAW = {"旺": 50, "相": 35, "休": 15, "囚": 5, "死": 0}  # §1-1 (norm = ×2)
A7_NUMERIC_BAND = 5  # 보류 (a): 65·35 ±5 → [30,40]∪[60,70]

# ── 일 경계 규칙 (pydantic 불요 — 샌드박스 standalone 경로용, v7.2에서 이사) ──
import enum

class DayBoundaryRule(str, enum.Enum):
    midnight = "midnight"
    h23 = "23h"


# ── KO2CODE — D-029 변환 사전(정의 위치; *수행* 단일 지점은 emitter) ──
KO2CODE_TEN_GOD = {"비견": "bi_gyeon", "겁재": "geop_jae", "식신": "sik_sin", "상관": "sang_gwan",
                   "편재": "pyeon_jae", "정재": "jeong_jae", "편관": "pyeon_gwan", "정관": "jeong_gwan",
                   "편인": "pyeon_in", "정인": "jeong_in"}
KO2CODE_STAGE = {"장생": "jangsaeng", "목욕": "mokyok", "관대": "gwandae", "건록": "imgwan", "임관": "imgwan",
                 "제왕": "jewang", "쇠": "soe", "병": "byeong", "사": "sa", "묘": "myo", "절": "jeol",
                 "태": "tae", "양": "yang"}
# v1.2 echo 전용 (D-052): roots[].kind = handoff ten_god_group legend / roots[].slot = handoff ji_jang_gan 키 어휘
KO2CODE_GROUP = {"비겁": "bi_geop", "인성": "in", "식상": "sik_sang", "재성": "jae", "관성": "gwan"}
KO2CODE_SLOT = {"본기": "bon", "중기": "jung", "여기": "yeo"}
HANJA2ELEM = {"木": "wood", "火": "fire", "土": "earth", "金": "metal", "水": "water"}

# ── 오행 생극 사이클 (Step 9 합충 predicate · Step 10 Strength 공용 — 단일 정의) ──
FIVE_GENERATES = {"木": "火", "火": "土", "土": "金", "金": "水", "水": "木"}  # 生
FIVE_CONTROLS  = {"木": "土", "土": "水", "水": "火", "火": "金", "金": "木"}  # 克

# ── 매화역수 mod 규약 (Step 11 사용 — §⑨-2) ─────────────────────
MAEHWA_TRIGRAM_MOD = 8   # 나머지 0 → 8(坤)
MAEHWA_LINE_MOD = 6      # 나머지 0 → 6(上爻)
TRIGRAM_BY_XIANTIAN = {1: "乾", 2: "兌", 3: "離", 4: "震", 5: "巽", 6: "坎", 7: "艮", 8: "坤"}
