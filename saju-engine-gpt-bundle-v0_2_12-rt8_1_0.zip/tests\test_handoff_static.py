"""handoff_static CI 게이트 (P1 증분2) — 정적블록 canonical 대조 + legend 코드 폐쇄 + 드리프트.

핵심: handoff_static.py(파생 미러)가 ask_modules.md <ASK 7> 블록2(진본 SoT)와 정합(dual-SoT
드리프트 차단)하고, LLM 봉인본의 정적블록 절단·legend 코드 환각을 canonical로 검출하는지.
직접 실행(pytest 미가용): PYTHONUTF8=1 PYTHONPATH=. py -m pytest tests/test_handoff_static.py
"""
from __future__ import annotations

import pytest

from tools import handoff_static as hs
from tools import handoff_verify as hv
from tools import gen_handoff_static as gen
from tests.corpus import build_case, TIER1_CASES


def _full_static():
    """canonical 정적 블록을 그대로 실은 handoff 조각."""
    return {"legend": hs.LEGEND, "spec": hs.SPEC,
            "consumer_scope": hs.CONSUMER_SCOPE, "reasoning_scaffold": hs.REASONING_SCAFFOLD}


# ── 상수 sanity ────────────────────────────────────────────────────
def test_constants_sanity():
    assert hs.STATIC_VERSION == "saju.handoff.v3.8"
    assert len([k for k in hs.LEGEND if not k.startswith("_")]) == 27
    assert hs.LEGEND["ten_god"]["pyeon_gwan"]["alias"] == ["七殺"]
    assert "answerable_from_json" in hs.CONSUMER_SCOPE and "needs_recompute" in hs.CONSUMER_SCOPE
    assert isinstance(hs.REASONING_SCAFFOLD, list) and len(hs.REASONING_SCAFFOLD) == 7


# ── 드리프트(파생 미러 ↔ 진본 프롬프트) ────────────────────────────
def test_handoff_static_matches_prompt():
    """handoff_static 상수 == ask_modules.md 재추출 (번들 미동봉 시 graceful skip)."""
    if not gen.PROMPT_MD.exists():
        pytest.skip("ask_modules.md 부재(단독 배포 번들) — 드리프트 검사 생략")
    blocks = gen.extract_blocks(gen.PROMPT_MD.read_text(encoding="utf-8"))
    assert blocks["legend"] == hs.LEGEND
    assert blocks["spec"] == hs.SPEC
    assert blocks["consumer_scope"] == hs.CONSUMER_SCOPE
    assert blocks["reasoning_scaffold"] == hs.REASONING_SCAFFOLD


# ── 정적 블록 절단·오타·누락 검출 ──────────────────────────────────
def test_static_blocks_clean():
    assert hv.validate_static_blocks(_full_static()) == []


def test_static_blocks_truncated_detected():
    h = _full_static()
    h["legend"] = {k: v for k, v in hs.LEGEND.items() if k != "sin_sal"}   # legend 일부 절단
    assert any("legend canonical 불일치" in e for e in hv.validate_static_blocks(h))


def test_static_blocks_missing_detected():
    h = _full_static()
    del h["spec"]
    assert any("spec 누락" in e for e in hv.validate_static_blocks(h))


# ── legend 코드 폐쇄 ───────────────────────────────────────────────
def test_legend_codes_clean():
    h = {"tier2_interpretation": {
        "day_master": {"element": "wood"},
        "strength": {"verdict_code": "strong"},
        "pattern": {"code": "jong_gyeok", "validity": "true"},
        "disease": ["weak_self"],
        "yong_shen": {"element": "fire", "ten_god": "sik_sang", "authenticity": "true_god"},
        "yong_mechanism": ["suppress", "drain"]}}
    assert hv.validate_legend_codes(h) == []


def test_legend_code_typo_detected():
    h = {"tier2_interpretation": {"strength": {"verdict_code": "STRONG"}}}   # 대문자 오타
    assert any("strength.verdict_code" in e for e in hv.validate_legend_codes(h))


def test_ten_god_typo_detected():
    h = {"tier1_facts": {"chart": {"ten_gods": {"year": {"stem": "bi_gyeong"}}}}}  # bi_gyeon 오타
    assert any("ten_gods.year.stem" in e for e in hv.validate_legend_codes(h))


def test_day_master_literal_skipped():
    # day.stem="day_master"는 ten_god 아님 → skip. branch_main은 실제 ten_god 코드(pyeon_jae).
    h = {"tier1_facts": {"chart": {"ten_gods": {"day": {"stem": "day_master", "branch_main": "pyeon_jae"}}}}}
    assert hv.validate_legend_codes(h) == []


def test_absent_paths_skipped():
    assert hv.validate_legend_codes({}) == []      # 부재 path는 위반 0(완전성 검사 아님)


# ── 실제 엔진 케이스의 tier1 코드가 전부 legend 폐쇄(경로 정합 회귀) ──
#    lichun_before = 원진(wonjin) 보유 — legend에 wonjin이 있어야 통과(회귀 사각 폐쇄).
@pytest.mark.parametrize("label", ("canonical_A", "samhap_full", "qi_only", "lichun_before"))
def test_legend_codes_clean_on_engine_case(label):
    raw = build_case(next(c for c in TIER1_CASES if c.label == label))
    proj = hv.project_tier1_verifiable(raw)
    rels = []
    for r in raw["relations"]:
        ch = "stem" if r["type"] in hv._STEM_RELATIONS else "branch"
        rels.append({"type": r["type"], "status": r["status"],
                     "members": [{"pos": f"{p}_{ch}", "char": raw["chart"][p][ch]} for p in r["positions"]]})
    chart = dict(proj["chart"]); chart["relations"] = rels
    h = {"tier1_facts": {"chart": chart,
                         "flow": {"flow_signals": proj["flow"]["flow_signals"]}},
         "tier2_interpretation": {"strength": {"verdict_code": proj["strength"]["verdict_code"]}}}
    assert hv.validate_legend_codes(h) == []
