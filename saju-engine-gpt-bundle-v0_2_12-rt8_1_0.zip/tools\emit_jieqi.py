"""--jieqi YYYY 단독 모드 — 연 단위 12절 절입·월간지 emit (schema jieqi.v1.0).

목적: Core §A2(입춘 보정)·§A3(세운·월운 경계)의 런타임 절입 HH:MM SoT(절기 xlsx 은퇴).
  절입·연간·월간지는 전부 원국 경로와 동일 함수를 재사용한다(산식 복제 0 — 단일 정의 원칙 S8).
스코프: 인물 무관 연 스코프 — Step 0 분기 C(생년월일 미입력)에서도 실행 가능하므로 tier1_facts에
  싣지 않는다. 연 단위 불변 데이터 → 대화 채널 캐시 단위 = 연(세션 내 재사용 적법, Core §6-3-③).
출력: terms[0] = 전년 대설 선행 행(Core §9 '1월 경계 주의'의 결정론화; 1951은 커버리지 시작이라 생략).
  각 행 의미 = [dt, 다음 행 dt) 반개구간의 월. month_ganji = 절입 dt를 probe해 자기 행 귀속.
소비 규율: 본 블록은 §8·§9류 lookup 테이블의 코드화이며 검산 echo가 아니다 — R6′ⓔ(전사 전용) 비적용.
  {{TODAY}}↔lichun_dt 비교·분석월 귀속 판정은 §A2·§A3가 보존한 런타임 lookup이다(원국·대운의
  절기 대조 금지 R2″는 불변).
fail-loud: 커버리지(1951~2035) 밖 연도 → LookupError(Core §10 — 사용자 정확 절입 시각 확인 요청).
timebase: 절기 자산은 당시 표준시(비DST) — 1954-03-21~1961-08-10 절입은 UTC+8:30, 그 외 KST.
변경 이력: docs/CHANGELOG.md.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Optional

from saju_engine.assets.solar_terms import JIE_TO_MONTH_BRANCH, load_solar_terms_extended
from saju_engine.constants import sexagenary_from_index, year_sexagenary_index
from saju_engine.engine.month_hour_pillar import month_pillar_for_birth
from saju_engine.engine.year_pillar import effective_saju_year

JIE_ORDER = ["소한", "입춘", "경칩", "청명", "입하", "망종",
             "소서", "입추", "백로", "한로", "입동", "대설"]


def build_jieqi_dict(year: int) -> dict:
    st = load_solar_terms_extended()
    if not (st.min_year <= year <= st.max_year):
        raise LookupError(f"절기 커버리지({st.min_year}~{st.max_year}) 밖: {year}")

    rows = []
    try:                                    # 선행 행: 전년 대설 — 1/1~소한 구간 (1951은 생략)
        rows.append(st.prev_jie(datetime(year, 1, 1)))
    except LookupError:
        pass
    rows += [(name, st.term_dt(year, name)) for name in JIE_ORDER]

    terms = []
    for jie, dt in rows:
        eff, _ = effective_saju_year(dt, st)
        y_ganji = sexagenary_from_index(year_sexagenary_index(eff))
        mp = month_pillar_for_birth(dt, y_ganji[0], st)
        assert mp.ref_jie == jie and mp.ref_jie_dt == dt   # 자기 행 귀속 자기검산
        terms.append({"jie": jie, "dt": dt.isoformat(),
                      "month_branch": JIE_TO_MONTH_BRANCH[jie],
                      "month_ganji": mp.ganji,
                      "governing_year_ganji": y_ganji})

    try:
        next_lichun: Optional[str] = st.lichun(year + 1).isoformat()
    except LookupError:                     # 커버리지 끝(2035) — null
        next_lichun = None

    return {
        "schema_version": "jieqi.v1.0",
        "meta": {"engine_version": "0.2.12",
                 "jieqi_coverage": f"{st.min_year}~{st.max_year}",
                 "prompt_pin": "saju-runtime-8.1.0",  # 릴리스 표시명(provenance·정보용); 핸드셰이크 게이트 = schema
                 "timebase": "당시 한국 표준시(비DST) — 1954-03-21~1961-08-10 절입은 UTC+8:30, 그 외 KST(UTC+9)"},
        "year": year,
        "lichun_dt": st.lichun(year).isoformat(),
        "year_ganji_from_lichun": sexagenary_from_index(year_sexagenary_index(year)),
        "year_ganji_before_lichun": sexagenary_from_index(year_sexagenary_index(year - 1)),
        "next_lichun_dt": next_lichun,
        "interval_semantics": "각 행 = [dt, 다음 행 dt) 구간의 월. 선행 대설 행 = 1/1~소한 전(전년 12월 子月 — Core §9 '1월 경계 주의'의 결정론화).",
        "terms": terms,
    }


def to_json_str(d: dict) -> str:
    return json.dumps(d, ensure_ascii=False, indent=2)
