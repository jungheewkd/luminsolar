"""standalone tier1_facts emitter — GPT Code Interpreter 등 외부 패키지 불가 샌드박스용.

tier1.py와 출력 JSON 동등(테스트 보증). 의존: stdlib + korean_lunar_calendar(번들 동봉)만.
사용: python3 run_emit.py <ISO출생> <F|M> [경도] [--no-time] [--divination <ISO>]
출력: ```tier1_facts``` 블록 (schema tier1.v1.6).
변경 이력: docs/CHANGELOG.md.
"""
from __future__ import annotations
import json
from datetime import datetime
from typing import Optional

from saju_engine.assets.dst_table import get_dst_periods
from saju_engine.assets.region_longitude import resolve_region_longitude
from saju_engine.assets.solar_terms import load_solar_terms_extended
from saju_engine.constants import (
    HANJA2ELEM, KO2CODE_GROUP, KO2CODE_SLOT, KO2CODE_STAGE, KO2CODE_TEN_GOD,
    DayBoundaryRule, FLAG_1954_WINDOW, sexagenary_from_index, year_sexagenary_index,
)
from saju_engine.engine.daewoon_age import daewoon_age_for_birth, daewoon_ganji_table
from saju_engine.engine.day_pillar import day_pillar, day_pillar_index, kasi_cross_status
from saju_engine.engine.derived_facts import derive_chart_facts
from saju_engine.engine.maehwa import cast_maehwa
from saju_engine.engine.month_hour_pillar import four_pillars, hour_ganji_table
from saju_engine.engine.relations import relations_for_chart
from saju_engine.engine.daily import daily_signals_for_chart
from saju_engine.engine.flow import flow_signals_for_luck   # I8: 운×원국 합충 탐지
from saju_engine.engine.solar_time import nearest_jieqi_for_flag
from saju_engine.engine.strength import strength_for_chart
from saju_engine.timecontext import build_time_context
from tools.emit_helpers import start_year as _start_year  # 단일 정의 공유


def build_tier1_dict(clock_dt: datetime, *, has_time: bool, gender: str,
                     longitude: Optional[float] = None, birth_place: Optional[str] = None,
                     divination_dt: Optional[datetime] = None) -> dict:
    # 출생지명 → 경도 결정론 변환(§A6): 숫자 경도 미입력 시에만. 미수록 지명은 fail-loud(ValueError).
    # 변환 경도는 meta.birth_longitude에 그대로 반영 → 보정에 쓰인 '실효 경도'가 투명 전사된다.
    if birth_place is not None and longitude is None:
        longitude = resolve_region_longitude(birth_place)
    st = load_solar_terms_extended()   # D-049: base(1951~2026 핀) + ephemeris(2027~2035) — ≤2026 불변(D-047)
    in_1954 = FLAG_1954_WINDOW[0] <= clock_dt.date() <= FLAG_1954_WINDOW[1]
    tc = build_time_context(clock_dt, has_time=has_time, longitude=longitude,
                            dst_periods=get_dst_periods(),
                            nearest_jieqi_dt=nearest_jieqi_for_flag(clock_dt, st) if in_1954 else None)  # D-050
    fp = four_pillars(tc, st, day_boundary_rule=DayBoundaryRule.midnight)
    cf = derive_chart_facts(fp)
    rels = relations_for_chart(fp)
    sr = strength_for_chart(fp, rels)
    da = daewoon_age_for_birth(tc.boundary_dt, gender=gender, year_stem=fp.year.ganji[0],
                               has_time=has_time, st=st)
    table = daewoon_ganji_table(fp.month.index, da.direction, da.start_age, n=8)

    # I8: flow_signals — 운(대운)×원국 합충 *탐지*만 결정화(旺衰·해소·부호 미산출 → §2-0-2 LLM 위임)
    from dataclasses import asdict as _fa
    flow_block = {"daewoon": [{"ganji": g, "age": a, "start_year": _start_year(clock_dt, a),
                               "signal_count": len(_s), "signals": [_fa(x) for x in _s]}
                              for a, g in table for _s in (flow_signals_for_luck(fp, g),)],
                  "seyun": None}

    def pillar(gz, facts):
        if gz is None:
            return None
        return {"stem": gz[0], "branch": gz[1], "hidden_stems": list(facts.hidden),
                "ten_god_stem": KO2CODE_TEN_GOD[facts.ten_god_stem] if facts.ten_god_stem else None,
                "ten_god_branch": KO2CODE_TEN_GOD[facts.ten_god_branch],
                "twelve_stage": KO2CODE_STAGE[facts.twelve_stage]}

    iso = lambda d: d.isoformat() if d else None
    out = {
        "schema_version": "tier1.v1.6",
        "meta": {"birth_input": clock_dt.isoformat(), "gender": gender,
                 "condition": "A" if has_time else "B", "day_boundary_rule": "midnight",
                 "birth_place": birth_place, "birth_longitude": longitude,
                 "engine_version": "0.2.12", "jieqi_coverage": f"{st.min_year}~{st.max_year}",
                 "prompt_pin": "saju-runtime-8.1.0"},
        "time_context": {"clock_dt": iso(tc.clock_dt), "boundary_dt": iso(tc.boundary_dt),
                         "solar_dt": iso(tc.solar_dt), "dst_applied": tc.dst_applied,
                         "longitude_correction_min": tc.longitude_correction_min,
                         "flag_1954_window": tc.flag_1954_window, "dst_anomaly": tc.dst_anomaly},
        "chart": {"year": pillar(fp.year.ganji, cf.year), "month": pillar(fp.month.ganji, cf.month),
                  "day": pillar(fp.day.ganji, cf.day),
                  "hour": pillar(fp.hour.ganji if fp.hour else None, cf.hour)},
        "derivation": {"lichun_dt": iso(fp.year.lichun_dt), "effective_year": fp.year.effective_year,
                       "month_ref_jie": fp.month.ref_jie, "month_ref_jie_dt": iso(fp.month.ref_jie_dt),
                       "day_pillar_index": fp.day.index,
                       # D-054: 고정 "unchecked" → 검증창 산출 상태 (판정일 = 일주 귀속일)
                       "day_pillar_kasi_cross": kasi_cross_status(fp.day.effective_date)},
        "relations": [{"type": h.type, "status": h.status, "positions": list(h.positions),
                       "element_transformed": HANJA2ELEM[h.element_transformed] if h.element_transformed else None,
                       "coefficient_candidates": list(h.coefficient_candidates) if h.coefficient_candidates else None,
                       "basis": h.basis or None} for h in rels],
        "void_branches": list(cf.void),
        "daewoon": {"direction": da.direction, "reference_jieqi": da.reference_jieqi,
                    "reference_jieqi_dt": iso(da.reference_jieqi_dt),
                    "interval_days": float(da.interval_days),
                    "start_age": da.start_age,
                    "start_age_uncertainty_years": da.start_age_uncertainty_years,
                    "table": [{"age": a, "start_year": _start_year(clock_dt, a), "ganji": g}
                              for a, g in table]},
        "strength": {"deuk_ryeong_raw": sr.deuk_ryeong_raw, "deuk_ji_raw": sr.deuk_ji_raw,
                     "deuk_se_raw": float(sr.deuk_se_raw),
                     "roots": [{"position": r.position, "slot": KO2CODE_SLOT[r.slot], "stem": r.stem,
                                "kind": KO2CODE_GROUP[r.kind], "base": r.base, "adj": round(r.adj, 4)}
                               for r in sr.roots],
                     "khc_applied": {p: {"coefficient": v["coefficient"], "basis": v["basis"]}
                                     for p, v in sr.khc_applied.items()},
                     "strength_pct": sr.strength_pct,
                     "qi_xing": sr.qi_xing, "a6_applied": sr.a6_applied,
                     "verdict_center": sr.verdict_center, "boundary_hold": sr.boundary_hold,
                     "triggers": dict(sr.triggers),
                     "candidates": list(sr.candidates) if sr.candidates else None,
                     "boundary_evidence": dict(sr.boundary_evidence)},   # I7(D-067) — read-only echo
        "flow_signals": flow_block,
        "divination": None,
        "maehwa": None,
    }
    if divination_dt is not None:
        ddt = divination_dt.replace(second=0, microsecond=0)
        dg = day_pillar(ddt.date())            # 달력일 기준 일진 — 만세력 달력 사실 (1900~2050 전수 검증창)
        out["divination"] = {"dt": ddt.isoformat(),                       # 시각 앵커 echo (ASK 13 §3-3 패널 머리)
                             "day_ganji": dg,
                             "day_ganji_index": day_pillar_index(ddt.date()),
                             "day_ganji_kasi_cross": kasi_cross_status(ddt.date()),  # D-054 가산
                             "hour_ganji": hour_ganji_table(dg[0])}       # 오서둔 12시진 子→亥 (D-051)
        from dataclasses import asdict as _asdict   # D-057: daily_signals 가산
        _surv, _void, _dmeta = daily_signals_for_chart(fp, cf, divination_dt, st, rels)
        out["divination"]["daily_signals"] = [_asdict(s) for s in _surv]
        out["divination"]["daily_signals_voided"] = [_asdict(s) for s in _void]
        out["divination"]["daily_signals_meta"] = _dmeta
        try:                                   # I8: 세운(divination 명리 연도)×원국 flow
            _dy = divination_dt.year
            _lc = st.lichun(_dy)
            _eff = _dy if divination_dt >= _lc else _dy - 1
            _sg = sexagenary_from_index(year_sexagenary_index(_eff))
            _ss = flow_signals_for_luck(fp, _sg)
            out["flow_signals"]["seyun"] = {"ganji": _sg, "year": _eff,
                                            "signal_count": len(_ss), "signals": [_asdict(s) for s in _ss]}
        except LookupError:
            out["flow_signals"]["seyun"] = None   # 절기 커버리지 밖 연도
        m = cast_maehwa(divination_dt)
        out["maehwa"] = {"lunar_year_branch": m.lunar_year_branch, "lunar_month": m.lunar_month,
                         "lunar_day": m.lunar_day, "is_intercalation": m.is_intercalation,
                         "hour_number": m.hour_n,
                         "year_n": m.year_n, "sum_umd": m.sum_umd, "sum_umdh": m.sum_umdh,
                         "upper_n": m.upper_n, "lower_n": m.lower_n,
                         "upper_trigram": m.upper_trigram, "lower_trigram": m.lower_trigram,
                         "moving_line": m.moving_line, "ben_gua": m.ben.name, "ben_gua_no": m.ben.no,
                         "zhi_gua": m.zhi.name, "zhi_gua_no": m.zhi.no,
                         "ti_trigram": m.ti_trigram, "yong_trigram": m.yong_trigram,
                         "ti_element": HANJA2ELEM[m.ti_element], "ti_yong_verdict": m.verdict}
    return out


def to_json_str(d: dict) -> str:
    return json.dumps(d, ensure_ascii=False, indent=2)
