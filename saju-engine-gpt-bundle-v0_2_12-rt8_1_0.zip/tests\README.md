# saju-engine 회귀 테스트 하네스 (R2)

> 목적: 엔진 산출의 **결정론·재현성**을 자동 잠금한다. 이 하네스가 있어야
> 이후 개선(I2 A6 환수, I8 flow_signals, I7 비대칭 신뢰도 등)을 "조용한 회귀
> 없이" 진행할 수 있다 — 개선방향 검토 §5(R2 = 모든 후속 변경의 선결 부채)의 구현.

## 실행

엔진 루트(이 `tests/`의 상위, `run_emit.py`가 있는 폴더)에서:

```bash
pip install pytest            # Code Interpreter엔 이미 있음. 엔진 런타임은 stdlib+openpyxl
python -m pytest              # 전체
python -m pytest -m golden    # 골든 회귀만
python -m pytest -m invariant # 불변식만
python -m pytest -m finding   # 잠복 결함 추적만
```

> ⚠️ **인코딩**: `run_emit.py`는 D-068(F3)으로 출력 인코딩을 UTF-8로 강제하므로
> 비-UTF8 로케일에서도 `PYTHONUTF8` 불요. 단 `pytest` *자신*의 출력(실패 시 한자 assert 메시지)이
> cp949에서 깨질 수 있으므로, Windows에서 테스트를 돌릴 땐 `PYTHONUTF8=1`을 주는 것을 권장한다.

## 구성

| 파일 | 역할 |
|:---|:---|
| `corpus.py` | 핀 고정 엣지케이스 명식 14종 + jieqi 3종 + 임의명식 표본 생성기. **모든 케이스는 `discover_edges.py` 실측으로 발견**(추측 아님) |
| `_golden/*.json` | 17개 케이스의 4모드 출력 동결 스냅샷(회귀 베이스라인) |
| `gen_golden.py` | 골든 (재)생성기. `--check`로 diff만 확인 |
| `test_smoke.py` | 엔진 import + 핀 케이스 산출 + 4개 CLI 모드 무사 기동 |
| `test_invariants.py` | 640개 임의명식 × 조건 A·B의 구조 불변식(스키마·열거·범위·기둥 규약) |
| `test_golden.py` | 스냅샷 회귀 잠금 + 동일입력 재현성(세션간 드리프트 0) |
| `test_characterization.py` | "엔진이 지금 이렇게 동작한다"의 명문 박제(A6 승격·년지캡·입춘경계·DST·UTC+8:30) |
| `test_findings.py` | R2가 발견한 잠복 결함의 xfail 추적 |
| `discover_edges.py` | 코퍼스 확장용 발견 도구(테스트 아님) |

## 골든 회귀 워크플로우

엔진 산출은 입력에 대해 **완전 결정론**(현재시각·난수 미사용)이라 골든은 바이트 안정적이다.

1. 평소: `pytest -m golden` → 출력이 베이스라인과 동일하면 통과.
2. 의도적 변경(가산 필드 등) 후: 골든 테스트가 **빨개진다**(정상).
3. diff 검토: `python tests/gen_golden.py --check` 로 어떤 케이스가 변했는지 확인.
4. 승인: `python tests/gen_golden.py` 로 베이스라인 갱신 → diff를 커밋.

이것이 CHANGELOG의 "4모드 diff 회귀잠금" 규율을 자동화한 것이다.

## 핀 케이스가 커버하는 결정론 경로

`canonical_A/B`(표준·시간미상), `lichun_before/after`(입춘 경계 년주 전환),
`qi_neither/only/xing_only/both`(기형 4유형), `xing_only_a6`(**A6 balanced 승격 +
년지캡40**, I2 핵심), `qi_both_strong`/`samhap_full`(신강·삼합), `dst_window`(서머타임),
`utc830_1954`(UTC+8:30 표준시), `with_longitude`(명시 경도), `condB_samhap`(조건 B 관계),
`divination`(일진·daily_signals·매화), `jieqi_1951/2026/2035`(절기 커버리지 상하한).

## 발견된 잠복 결함

| ID | 결함 | 상태 |
|:---|:---|:---|
| **F1** | `solar_terms.py:15` 최상위 `import openpyxl` → "stdlib-only" 계약 위반(순수 stdlib 환경 import 실패) | ✅ **수정됨 (D-062, saju-runtime-7.4.0)** — `load_solar_terms()` 내부로 지연. `test_f1_solar_terms_stdlib_only` 잠금 |
| **F2** | `run_emit.py`가 `LookupError`만 포착 → 경도 범위밖·잘못된 성별의 `ValueError` traceback 누출(KERNEL ON_FAIL ⓔ 위반, Feedback 별첨 건) | ✅ **수정됨 (D-063, saju-runtime-7.4.0)** — 입력 guard + `except ValueError`. `test_f2_*` 잠금 |
| **F3** | 비-UTF8 Windows 로케일(cp949)에서 CLI가 출력의 `—`(em-dash, U+2014 — note/basis 필드) 인코딩 시 `UnicodeEncodeError` 크래시 | ✅ **수정됨 (D-068, saju-runtime-7.6.1)** — `run_emit.py` 진입부 `_force_utf8_io()`(stdout/stderr를 UTF-8로 reconfigure, CLI 진입 시에만). `test_f3_non_utf8_locale_no_crash`가 cp949 env로 잠금. `PYTHONUTF8` 불요 |

> F1·F2 수정으로 해당 xfail 마커는 제거되고 실제 통과 테스트로 전환됨. 향후 결함은
> "바라는 동작 단언 + xfail(strict)"로 추가하면 수정 시 자동으로 마커 제거가 강제된다.

## 특성화로 박제한 사실 (Phase C에서 의도적으로 바뀔 대상)

- **A6 `xing_only→balanced` 승격**: raw `quasi_weak`를 `balanced`로 '보수측 中和'(D-035).
  I2 구현 시 이 동작이 바뀌므로 `test_a6_xing_only_promotes_to_balanced`가 변경 마커가 된다.
- **`neither & strong` 분기는 죽은 코드**: `qi_xing=neither`가 구조적으로 낮은 pct를 강제
  (실측 30,650일 중 neither 최대 pct 43.9) → `apply_a6`의 종격검토 분기는 사실상 도달 불가.
  `test_neither_never_reaches_strong`가 이 가정을 잠근다.
