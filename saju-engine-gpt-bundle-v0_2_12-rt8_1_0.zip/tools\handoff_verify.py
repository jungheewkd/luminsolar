"""saju.handoff.v3.8 ↔ 엔진 raw tier1_facts no-new-values 검증 (P1·접근 A).

ASK 7이 LLM 수동 직렬화한 봉인 handoff의 load-bearing 필드(원국 사실·강약 canonical)를
엔진 build_tier1_dict() raw 출력과 값 대조해, 오전사(誤轉寫)를 **봉인 시점에 fail-loud로
검출**한다. 변환·생성은 하지 않는다(검출 전용) — LLM 저작 경로는 유지하되 그 결과를 결정론
대조로 잠근다. SILENT_BUILD Enabled/Disabled(verbose) 전 경로에서 동작(엔진 raw만 있으면 됨).

⛔ 검증 사각(BLIND SPOT — 엔진 raw에 부재하거나 산출이 아님. 본 모듈은 대조하지 않는다):
  - chart.branch_climate                         엔진 0건 — ASK 2 §⑧ 한난조습 정성 판정
  - flow.current_daewoon / current_se_woon       ASK 6 정성·분석연도 의존
  - true_solar_time.{applied,dst_adjust_min,standard_time_zone,note}   표현 규약(엔진 분 단위만 보유)
  - relations[].result/strength/usage_hint, 모든 tldr·usage_hint·operative_basis·root_notes 산문
  이들은 legend 폐쇄·정적블록 대조(P1 후속 — handoff_static)로만 방어한다.

검증 가능(no-new-values 대조): chart.pillars·five_elements·ten_gods·ji_jang_gan(역순)·gong_mang,
  relations(type·status·positions·member char), true_solar_time.longitude_adjust_min,
  flow.direction·daewoon_table(age·start_year·ganji + 운십성 derived 재도출)·flow_signals(엔진 echo),
  tier2_interpretation.strength canonical(verdict·pct·raw 3축·boundary_hold·candidates·비대칭).
"""
from __future__ import annotations

from collections import Counter

from tools.assemble_handoff import stem_branch_element, _STRENGTH_ECHO
from tools import handoff_static as _hs

# 엔진 daewoon.direction(forward/reverse) → handoff flow.direction(forward/backward) 재명명.
_DIRECTION = {"forward": "forward", "reverse": "backward"}
# branch 채널 관계(지지) vs stem 채널 관계(천간) — member pos 접미사·char 역참조용.
_STEM_RELATIONS = {"stem_combine"}


def _daewoon_ten_gods(day_stem, ganji):
    """대운 간지의 십성(일간 기준 derived lookup — echo 아님·결정론 표 조회) → (stem_ten_god, branch_ten_god) code.
    엔진 daewoon.table엔 미동봉이나 결정론 재도출 가능 — 생성기·검증기 공용(단일 스펙)."""
    from saju_engine.engine.derived_facts import ten_god
    from saju_engine.assets.lookup.hidden_stems import HIDDEN_STEMS
    from saju_engine.constants import KO2CODE_TEN_GOD
    st = KO2CODE_TEN_GOD[ten_god(day_stem, ganji[0])]
    bt = KO2CODE_TEN_GOD[ten_god(day_stem, HIDDEN_STEMS[ganji[1]][0])]   # 지지 본기 기준
    return st, bt


def _daewoon_table_proj(raw):
    """raw → handoff flow.daewoon_table (age·start_year·ganji + 결정론 운십성). 생성기·검증기 공용."""
    ds = raw["chart"]["day"]["stem"]
    out = []
    for e in raw["daewoon"]["table"]:
        st, bt = _daewoon_ten_gods(ds, e["ganji"])
        out.append({"age": e["age"], "start_year": e["start_year"], "ganji": e["ganji"],
                    "stem_ten_god": st, "branch_ten_god": bt})
    return out


# ── raw 기둥 → handoff 필드 결정론 투영 헬퍼 ─────────────────────────
def _pillar_ganji(p):
    return None if p is None else p["stem"] + p["branch"]


def _pillar_elems(p, sbe):
    return None if p is None else [sbe[p["stem"]], sbe[p["branch"]]]


def _pillar_ten_gods(name, p):
    if p is None:
        return None
    return {"stem": "day_master" if name == "day" else p["ten_god_stem"],
            "branch_main": p["ten_god_branch"]}


def _pillar_jjg(p):
    """엔진 hidden_stems = [본기, 중기, 여기](bon-first) → handoff {yeo, jung, bon}.
    ⚠️ 역순 매핑(yeo=hidden[2]·bon=hidden[0]) — 순서대로 넣으면 본기/여기가 조용히 뒤바뀐다."""
    if p is None:
        return None
    h = p["hidden_stems"]
    return {"yeo": h[2], "jung": h[1], "bon": h[0]}


def _strength_canonical(eng: dict) -> dict:
    """엔진 strength → tier2.strength canonical 필드(R2′ 엔진 권위)."""
    out = {ck: eng[ek] for ek, ck in _STRENGTH_ECHO.items() if ek in eng}
    if eng.get("boundary_hold"):
        out["_boundary"] = {"candidates": eng.get("candidates"),
                            "confidence_asymmetry": eng.get("boundary_evidence")}
    return out


def project_tier1_verifiable(raw: dict) -> dict:
    """엔진 raw tier1_facts → handoff가 가져야 할 '검증 가능' 필드의 결정론 투영.
    (BLIND SPOT 필드는 포함하지 않는다.) verify_against_engine의 기준값이며,
    P2에서 생성기(tier1 echo)로 승격될 매핑의 씨앗이다. 입력 비파괴."""
    sbe = stem_branch_element()
    chart = raw["chart"]
    names = ("year", "month", "day", "hour")
    return {
        "chart": {
            "pillars": {n: _pillar_ganji(chart[n]) for n in names},
            "five_elements": {n: _pillar_elems(chart[n], sbe) for n in names},
            "ten_gods": {n: _pillar_ten_gods(n, chart[n]) for n in names},
            "ji_jang_gan": {n: _pillar_jjg(chart[n]) for n in names},
            "gong_mang": list(raw["void_branches"]),
        },
        "relations": [{"type": r["type"], "status": r["status"],
                       "positions": list(r["positions"])} for r in raw["relations"]],
        "true_solar_time": {"longitude_adjust_min": raw["time_context"]["longitude_correction_min"]},
        "flow": {
            "direction": _DIRECTION.get(raw["daewoon"]["direction"], raw["daewoon"]["direction"]),
            "daewoon_table": _daewoon_table_proj(raw),   # age·start_year·ganji + 운십성(검증 대상)
            "flow_signals": raw["flow_signals"],
        },
        "strength": _strength_canonical(raw["strength"]),
    }


# ── 생성기 (P2 — 엔진 raw → handoff tier1_facts 결정론 생성, LLM 재타이핑 제거) ──
def _relations_for_handoff(raw: dict) -> list:
    """raw relations → handoff relations[{type,status,members[{pos,char}],result,...}].
    char는 chart 역참조(엔진 emit은 positions만). strength·usage_hint는 null(LLM/blind)."""
    chart = raw["chart"]
    out = []
    for r in raw["relations"]:
        ch = "stem" if r["type"] in _STEM_RELATIONS else "branch"
        members = [{"pos": f"{p}_{ch}", "char": chart[p][ch]} for p in r["positions"]]
        out.append({"type": r["type"], "status": r["status"], "members": members,
                    "result": r.get("element_transformed"), "strength": None, "usage_hint": None})
    return out


def _true_solar_time_for_handoff(tc: dict) -> dict:
    """raw time_context → handoff true_solar_time. longitude_adjust_min만 검증 대상(echo);
    applied·dst_adjust_min은 결정론 파생, standard_time_zone·note는 표현 hint(검증 사각·null)."""
    return {"applied": tc["solar_dt"] is not None,
            "dst_adjust_min": -60 if tc["dst_applied"] else 0,
            "longitude_adjust_min": tc["longitude_correction_min"],
            "standard_time_zone": None,
            "note": None}


def build_handoff_tier1(raw: dict) -> dict:
    """엔진 raw tier1_facts → handoff tier1_facts 결정론 생성(P2 — LLM의 tier1 재타이핑 제거).
    검증 가능 필드는 project_tier1_verifiable과 **동일 헬퍼**로 단일 스펙(그림자 스펙 이중화 해소):
    생성기 출력을 verify_against_engine에 넣으면 위반 0(round-trip 정합).

    ⛔ BLIND SLOT(엔진 미산출 — null로 두고 P3에서 tier2 조각으로 채움):
       chart.branch_climate(ASK 2 §⑧)·flow.current_daewoon/current_se_woon(ASK 6 정성·분석연도).
    daewoon_table 운십성·true_solar_time 표현필드는 derived lookup(echo 아님·'발명 ZERO' 표 조회)."""
    sbe = stem_branch_element()
    chart = raw["chart"]
    names = ("year", "month", "day", "hour")
    dw = raw["daewoon"]
    table = _daewoon_table_proj(raw)          # project와 동일 헬퍼(단일 스펙 — round-trip 운십성 정합)
    unc = dw.get("start_age_uncertainty_years") or 0
    return {
        "chart": {
            "pillars": {n: _pillar_ganji(chart[n]) for n in names},
            "five_elements": {n: _pillar_elems(chart[n], sbe) for n in names},
            "ten_gods": {n: _pillar_ten_gods(n, chart[n]) for n in names},
            "ji_jang_gan": {n: _pillar_jjg(chart[n]) for n in names},
            "relations": _relations_for_handoff(raw),
            "gong_mang": list(raw["void_branches"]),
            "branch_climate": None,          # ⛔ 엔진 미산출 — ASK 2 §⑧, P3 tier2 흡수
        },
        "true_solar_time": _true_solar_time_for_handoff(raw["time_context"]),
        "flow": {
            "direction": _DIRECTION.get(dw["direction"], dw["direction"]),
            "start_age": f"{dw['start_age']}" + (f" (±{unc}년)" if unc else ""),
            "daewoon_table": table,
            "flow_signals": raw["flow_signals"],
            "current_daewoon": None,         # ⛔ ASK 6 정성·분석연도 의존, P3
            "current_se_woon": None,
        },
    }


# ── 대조 (handoff 실제값 vs 투영 기준값) ────────────────────────────
def _verify_chart_blocks(chart, exp, errs):
    for block in ("pillars", "five_elements", "ten_gods", "ji_jang_gan"):
        want = exp["chart"][block]
        got = chart.get(block) or {}
        for n, wv in want.items():
            gv = got.get(n)
            if gv != wv:
                errs.append(f"tier1_facts.chart.{block}.{n} 재타이핑 불일치: 엔진={wv!r} handoff={gv!r}")
    exp_gm = exp["chart"]["gong_mang"]
    got_gm = list(chart.get("gong_mang") or [])
    if got_gm != exp_gm:
        errs.append(f"tier1_facts.chart.gong_mang 불일치: 엔진={exp_gm!r} handoff={got_gm!r}")


def _verify_relations(h_rels, raw, exp, errs):
    if h_rels is None:
        if exp["relations"]:
            errs.append(f"tier1_facts.chart.relations 누락: 엔진 {len(exp['relations'])}건 탐지")
        return
    chart = raw["chart"]
    h_sigs = []
    for i, r in enumerate(h_rels):
        pillars = []
        for m in (r.get("members") or []):
            pos = m.get("pos") or ""
            if "_" not in pos:
                continue
            pillar, channel = pos.rsplit("_", 1)
            pillars.append(pillar)
            cp = chart.get(pillar)
            if cp is not None and channel in ("stem", "branch"):
                exp_char = cp[channel]
                if m.get("char") not in (None, exp_char):
                    errs.append(f"relations[{i}].members(pos={pos}).char 불일치: "
                                f"엔진={exp_char!r} handoff={m.get('char')!r}")
        h_sigs.append((r.get("type"), r.get("status"), frozenset(pillars)))
    exp_sigs = Counter((rr["type"], rr["status"], frozenset(rr["positions"])) for rr in exp["relations"])
    if Counter(h_sigs) != exp_sigs:
        def _fmt(c):
            return sorted(f"{t}/{s}/{sorted(p)}" for (t, s, p), n in c.items() for _ in range(n))
        errs.append(f"relations 집합 불일치(type·status·positions): "
                    f"엔진={_fmt(exp_sigs)} handoff={_fmt(Counter(h_sigs))}")


def _verify_daewoon_table(got, exp, errs):
    if got is None:
        errs.append("flow.daewoon_table 누락(엔진 대운표 전사 필요)")
        return
    if len(got) != len(exp):
        errs.append(f"flow.daewoon_table 길이 불일치: 엔진={len(exp)} handoff={len(got)}")
        return
    for i, (g, e) in enumerate(zip(got, exp)):
        # 운십성(stem/branch_ten_god)도 대조 — 결정론 derived라 사각 폐쇄(BLIND 아님)
        for k in ("age", "start_year", "ganji", "stem_ten_god", "branch_ten_god"):
            if g.get(k) != e.get(k):
                errs.append(f"flow.daewoon_table[{i}].{k} 불일치: 엔진={e.get(k)!r} handoff={g.get(k)!r}")


def _verify_flow_signals(got, exp, errs):
    if got is None:
        errs.append("flow.flow_signals 누락(엔진 8대운 탐지 echo 필요)")
        return
    ged, exd = got.get("daewoon") or [], exp.get("daewoon") or []
    if len(ged) != len(exd):
        errs.append(f"flow_signals.daewoon 길이 불일치: 엔진={len(exd)} handoff={len(ged)}")
        return
    for i, (g, e) in enumerate(zip(ged, exd)):
        for k in ("ganji", "age", "start_year", "signal_count"):
            if g.get(k) != e.get(k):
                errs.append(f"flow_signals.daewoon[{i}].{k} 불일치: 엔진={e.get(k)!r} handoff={g.get(k)!r}")
        if (g.get("signals") or []) != (e.get("signals") or []):
            errs.append(f"flow_signals.daewoon[{i}].signals 불일치(엔진 탐지 원문 echo 위반)")
    if (got.get("seyun") or None) != (exp.get("seyun") or None):
        errs.append("flow_signals.seyun 불일치(엔진 echo 위반)")


def _verify_strength(handoff, exp_strength, errs):
    s = (handoff.get("tier2_interpretation") or {}).get("strength") or {}
    if not s:
        errs.append("tier2_interpretation.strength 누락(엔진 강약 canonical 전사 필요)")
        return
    for ck, wv in exp_strength.items():
        if ck.startswith("_"):
            continue
        if s.get(ck) != wv:
            errs.append(f"tier2_interpretation.strength.{ck} 불일치: 엔진={wv!r} handoff={s.get(ck)!r}")
    if "_boundary" in exp_strength:
        b = s.get("boundary") or {}
        eb = exp_strength["_boundary"]
        if b.get("candidates") != eb["candidates"]:
            errs.append(f"strength.boundary.candidates 불일치: 엔진={eb['candidates']!r} handoff={b.get('candidates')!r}")
        if eb["confidence_asymmetry"] is not None and b.get("confidence_asymmetry") != eb["confidence_asymmetry"]:
            errs.append("strength.boundary.confidence_asymmetry 불일치(엔진 boundary_evidence echo 위반)")


def verify_against_engine(handoff: dict, raw: dict) -> list:
    """봉인 handoff를 엔진 raw tier1_facts와 no-new-values 대조. 위반 문자열 리스트 반환(빈 = 정합).
    BLIND SPOT 필드(모듈 docstring)는 대조하지 않는다 — 정직한 부분 검증."""
    errs: list = []
    exp = project_tier1_verifiable(raw)
    t1 = handoff.get("tier1_facts") or {}
    chart = t1.get("chart") or {}
    _verify_chart_blocks(chart, exp, errs)
    _verify_relations(chart.get("relations"), raw, exp, errs)
    tst = t1.get("true_solar_time") or {}
    exp_lon = exp["true_solar_time"]["longitude_adjust_min"]
    if "longitude_adjust_min" in tst and tst["longitude_adjust_min"] != exp_lon:
        errs.append(f"true_solar_time.longitude_adjust_min 불일치: 엔진={exp_lon!r} handoff={tst['longitude_adjust_min']!r}")
    flow = t1.get("flow") or {}
    if flow.get("direction") is not None and flow["direction"] != exp["flow"]["direction"]:
        errs.append(f"flow.direction 불일치: 엔진={exp['flow']['direction']!r} handoff={flow['direction']!r}")
    _verify_daewoon_table(flow.get("daewoon_table"), exp["flow"]["daewoon_table"], errs)
    _verify_flow_signals(flow.get("flow_signals"), exp["flow"]["flow_signals"], errs)
    _verify_strength(handoff, exp["strength"], errs)
    return errs


# ── 정적 블록·legend 코드 canonical 대조 (P1 증분2 — 엔진 raw 불요) ──────────
def validate_static_blocks(handoff: dict) -> list:
    """봉인 handoff의 legend·spec·consumer_scope·reasoning_scaffold를 canonical(handoff_static)과
    대조 — LLM 복사 시 절단·오타·구버전을 검출. SoT=ask_modules.md, handoff_static=파생 미러."""
    errs: list = []
    for key, canon in (("legend", _hs.LEGEND), ("spec", _hs.SPEC),
                       ("consumer_scope", _hs.CONSUMER_SCOPE),
                       ("reasoning_scaffold", _hs.REASONING_SCAFFOLD)):
        got = handoff.get(key)
        if got is None:
            errs.append(f"{key} 누락 — 정적 블록(handoff_static 단일 SoT) 전사/주입 필요")
        elif got != canon:
            errs.append(f"{key} canonical 불일치(절단·오타·구버전 — handoff_static과 다름)")
    return errs


def _chk(errs, code, category, where, *, extra_cat=None, allow=()):
    """code가 canonical legend[category](또는 extra_cat·allow)에 폐쇄되는지. None/allow는 통과."""
    if code is None or code in allow:
        return
    pool = set(_hs.LEGEND.get(category) or ())
    if extra_cat:
        pool |= set(_hs.LEGEND.get(extra_cat) or ())
    if code not in pool:
        errs.append(f"{where}: legend 미해석 코드 {code!r} (기대 카테고리 {category}"
                    f"{'/' + extra_cat if extra_cat else ''})")


def validate_legend_codes(handoff: dict) -> list:
    """봉인 handoff의 범주 코드가 canonical legend enum에 폐쇄되는지 — 코드 오타·환각 검출.
    부재 path·None은 건너뛴다(완전성 검사가 아니라 '쓰여진 코드의 적법성'). day_master는 ten_god 아님."""
    errs: list = []
    t1 = handoff.get("tier1_facts") or {}
    chart = t1.get("chart") or {}
    names = ("year", "month", "day", "hour")

    for n in names:
        for el in (chart.get("five_elements") or {}).get(n) or []:
            _chk(errs, el, "five_element", f"chart.five_elements.{n}")
        tg = (chart.get("ten_gods") or {}).get(n)
        if isinstance(tg, dict):
            _chk(errs, tg.get("stem"), "ten_god", f"chart.ten_gods.{n}.stem", allow=("day_master",))
            _chk(errs, tg.get("branch_main"), "ten_god", f"chart.ten_gods.{n}.branch_main")
        bc = (chart.get("branch_climate") or {}).get(n)
        if isinstance(bc, dict):
            _chk(errs, bc.get("temp"), "temperature", f"chart.branch_climate.{n}.temp")
            _chk(errs, bc.get("humid"), "humidity", f"chart.branch_climate.{n}.humid")
    for i, r in enumerate(chart.get("relations") or []):
        _chk(errs, r.get("type"), "relation_type", f"relations[{i}].type")
        _chk(errs, r.get("status"), "relation_status", f"relations[{i}].status")

    fs = ((t1.get("flow") or {}).get("flow_signals") or {})
    for di, dw in enumerate(fs.get("daewoon") or []):
        for si, sig in enumerate(dw.get("signals") or []):
            w = f"flow_signals.daewoon[{di}].signals[{si}]"
            _chk(errs, sig.get("type"), "relation_type", f"{w}.type", extra_cat="flow_signal_type")
            _chk(errs, sig.get("status"), "flow_status", f"{w}.status")
            _chk(errs, sig.get("channel"), "flow_channel", f"{w}.channel")
            _chk(errs, sig.get("position_tier"), "position_tier", f"{w}.position_tier")

    t2 = handoff.get("tier2_interpretation") or {}
    _chk(errs, (t2.get("day_master") or {}).get("element"), "five_element", "day_master.element")
    _chk(errs, (t2.get("strength") or {}).get("verdict_code"), "strength_verdict", "strength.verdict_code")
    pat = t2.get("pattern") or {}
    _chk(errs, pat.get("code"), "pattern_type", "pattern.code")
    _chk(errs, pat.get("validity"), "validity", "pattern.validity")
    for d in t2.get("disease") or []:
        _chk(errs, d, "disease", "disease[]")
    for shen in ("yong_shen", "hee_shen", "gi_shin", "gu_shin"):
        sh = t2.get(shen) or {}
        _chk(errs, sh.get("element"), "five_element", f"{shen}.element")
        _chk(errs, sh.get("ten_god"), "ten_god_group", f"{shen}.ten_god")
    _chk(errs, (t2.get("yong_shen") or {}).get("authenticity"), "yong_authenticity", "yong_shen.authenticity")
    ym = t2.get("yong_mechanism")
    for m in ([ym] if isinstance(ym, str) else (ym or [])):
        _chk(errs, m, "yong_mechanism", "yong_mechanism")
    em = t2.get("energy_map") or {}
    for n in names:
        ts = (em.get("twelve_stages") or {}).get(f"{n}_branch") or {}
        _chk(errs, ts.get("stage"), "twelve_stage", f"energy_map.twelve_stages.{n}.stage")
        _chk(errs, ts.get("band"), "stage_band", f"energy_map.twelve_stages.{n}.band")
    for grp in ("active_shins", "dormant_shins"):
        for g in em.get(grp) or []:
            _chk(errs, g, "ten_god_group", f"energy_map.{grp}[]")
    for s in (t2.get("sin_sal") or {}).get("list") or []:
        _chk(errs, s.get("code"), "sin_sal", "sin_sal.list[].code")
    return errs


# ── boundary 내부정합 (P1 증분3 — 엔진 raw 불요·handoff-only BLIND 검사) ──────
_OPERATIVE_BRANCHES = ("strong_branch", "weak_branch")


def validate_boundary_consistency(handoff: dict) -> list:
    """봉인 handoff의 boundary 라우팅 내부정합 — 엔진 raw 없이 handoff 단독 검사.
    (i) 멤버십: tier2_interpretation.strength.boundary.operative_branch가 쓰여 있으면
        반드시 {strong_branch, weak_branch} 중 하나여야 한다(ASK 6 §1-0 가지 활성화 키).
    (ii) cross-key: clarity.by_branch(가지별 단일 — 키=strong/weak; ask_modules.md §clarity)가
        존재하고 operative_branch가 쓰여 있으면, operative가 가리키는 가지(operative_branch에서
        '_branch' 접미 제거 → strong/weak)가 clarity.by_branch의 키로 존재해야 한다
        (ASK 6 operative_branch ↔ ASK 4 clarity.by_branch 라우팅 일치 — 가지 어긋남 조용한 봉인 차단).
    두 검사 모두 해당 필드 부재면 건너뛴다(완전성 검사 아님 — '쓰여진 값의 정합성')."""
    errs: list = []
    t2 = handoff.get("tier2_interpretation") or {}
    boundary = ((t2.get("strength") or {}).get("boundary")) or {}
    op = boundary.get("operative_branch") if isinstance(boundary, dict) else None
    if op is not None and op not in _OPERATIVE_BRANCHES:
        errs.append(f"strength.boundary.operative_branch 미상 코드 {op!r} "
                    f"(기대 {list(_OPERATIVE_BRANCHES)})")
    clarity = t2.get("clarity") or {}
    cby = clarity.get("by_branch")
    if isinstance(cby, dict) and op in _OPERATIVE_BRANCHES:
        side = op[:-len("_branch")]      # strong_branch→strong / weak_branch→weak
        if side not in cby:
            errs.append(f"clarity.by_branch operative 가지 불일치: "
                        f"operative_branch={op!r}이나 clarity.by_branch 키={sorted(cby)} "
                        f"(operative side {side!r} 부재)")
    return errs


def engine_raw_from_meta(handoff: dict):
    """편의 — handoff.meta로 엔진 tier1 재산출(외부 오케스트레이터는 --raw 권장: meta 오전사 시
    raw도 오염되어 진짜 오류를 가릴 수 있다). 실패 시 None(--raw 유도)."""
    from datetime import datetime
    meta = handoff.get("meta") or {}
    bi = meta.get("birth_solar") or meta.get("birth_input")
    if not bi:
        return None
    try:
        from tools.emit_tier1_standalone import build_tier1_dict
        dt = datetime.fromisoformat(bi.replace(" ", "T"))
        lon = meta.get("birth_longitude")
        return build_tier1_dict(dt, has_time=(meta.get("condition") == "A"),
                                gender=meta.get("gender") or "M",
                                longitude=lon if isinstance(lon, (int, float)) else None)
    except (ValueError, TypeError, KeyError, LookupError) as e:
        print(f"[verify] meta 재산출 실패({type(e).__name__}: {e}) — --raw 사용 권장")
        return None
