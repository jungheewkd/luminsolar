"""Step 9 — 합충형파해 탐지 + 화기 predicate (References §④, tier1.5).

[경계 — D-030] 본 모듈은 *국소* predicate까지만 소유한다:
  탐지(동시 존재 이진 판정, §④-1 "최소 조건") · 삼합 등급(§④-3 100/80/50/30) · 화기 성립(§④-1·④-4)
  · 쟁합(D-031) · 반형/자형. §④-6의 파합·해소("충의 세력이 압도적이면")와 형파해 '잔여 색채' 적용은
  세력 정성 판단을 포함하므로 비결정 → 소비층(프롬프트 tier2 / Step 10 계수 선택) 소관.
  인접 요건 없음 — 근접성(일지>월지/시지>년지)은 강도 변수이지 성립 변수가 아니다(§④-6 #3).

[쟁합 — D-031] 같은 type의 합 hit들이 위치를 공유하면 전부 contended + 화기 억제(육합·천간합 공통).
[午未 — D-032] 합화 '土/火'는 표 순서(土→火)로 평가, 첫 충족 오행 채택(basis 명기).
[旺相/극제] 旺=월령 오행 동일, 相=월령이 生 / 극제=월령이 克 — constants 생극 사이클 단일 정의.
[S5] coefficient_candidates는 §④가 수치를 주는 곳만(삼합 등급·방국 0.8·암합 0.3~0.5).
  ASK2 §1-2-1-α 보정계수 인출과 중첩 시 최대 단일 계수 선택은 Step 10.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import combinations
from typing import Dict, List, Optional, Tuple

from saju_engine.assets.lookup.attributes import BRANCH_ATTR, STEM_ATTR
from saju_engine.assets.lookup.relations_tables import (
    AMHAP, BANGGUK, CHEONGANHAP, HAE, HYEONG, PA, SAMHAP, WONJIN, YUKCHUNG, YUKHAP,
)
from saju_engine.constants import BRANCHES, FIVE_CONTROLS, FIVE_GENERATES
from saju_engine.engine.month_hour_pillar import FourPillars

POS_ORDER = ("year", "month", "day", "hour")
WANGJI = {"子", "午", "卯", "酉"}
SELF_PUNISH = set(HYEONG["자형"])
CHEONGANHAP_N = {tuple(sorted(k)): v for k, v in CHEONGANHAP.items()}  # 키 정렬 정규화(간지순→유니코드순)
PAIR_TABLES = {  # (type code, pair set/dict)
    "combine_6": {tuple(sorted(k)): v for k, v in YUKHAP.items()},
    "clash": {tuple(sorted(p)) for p in YUKCHUNG},
    "break": {tuple(sorted(p)) for p in PA},
    "harm": {tuple(sorted(p)) for p in HAE},
    "wonjin": {tuple(sorted(p)) for p in WONJIN},
    "hidden_combine": {tuple(sorted(p)) for p in AMHAP},
}


@dataclass(frozen=True)
class RelationHit:
    type: str                                   # legend 코드 (+ 'wonjin','punishment')
    status: str                                 # formed / half / contended
    positions: Tuple[str, ...]
    members: Tuple[str, ...]                    # 관여 지지 or 천간
    element_transformed: Optional[str] = None   # 화기 성립 시 오행(한자)
    coefficient_candidates: Optional[Tuple[float, ...]] = None
    basis: str = ""


def _wang_sang(month_elem: str, target: str) -> bool:
    return month_elem == target or FIVE_GENERATES[month_elem] == target


def _present_stem_elems(stems: Dict[str, str]) -> set:
    return {STEM_ATTR[s]["element"] for s in stems.values() if s}


def detect_relations(stems: Dict[str, Optional[str]], branches: Dict[str, Optional[str]]) -> List[RelationHit]:
    """원국 4기둥(Condition B는 hour None) → §④ 전 유형 탐지. 입력은 pos→글자 dict."""
    bpos = [(p, b) for p in POS_ORDER for b in [branches.get(p)] if b]
    spos = [(p, s) for p in POS_ORDER for s in [stems.get(p)] if s]
    month_elem = BRANCH_ATTR[branches["month"]]["element"]
    stem_elems = _present_stem_elems({p: s for p, s in spos})
    hits: List[RelationHit] = []

    # ── 지지 쌍 6종 (육합·충·파·해·원진·암합) ──
    pair_hits_by_type: Dict[str, List[RelationHit]] = {}
    for (p1, b1), (p2, b2) in combinations(bpos, 2):
        key = tuple(sorted((b1, b2)))
        for t, table in PAIR_TABLES.items():
            if key not in table:
                continue
            elem, coef, basis = None, None, ""
            if t == "combine_6":
                raw = PAIR_TABLES["combine_6"][key]            # 합화 오행 문자열 (예: '土/火')
                cands = [c for c in raw if c in "木火土金水"]
                for c in cands:                                 # D-032: 표 순서 평가
                    if c in stem_elems or _wang_sang(month_elem, c):
                        elem = c
                        basis = f"화기 성립({c}: " + ("투출" if c in stem_elems else "월령 旺相") + ")"
                        break
                if elem is None:
                    basis = "합거(투출·월령 旺相 모두 미충족)"
                if len(cands) > 1:
                    basis += " · 午未 이원(土/火, 표순 평가)"
            elif t == "hidden_combine":
                coef = (0.3, 0.5)
                basis = "지장간 천간합 — 표면 합충 우선(§④-5)"
            elif t == "wonjin":
                basis = "신살 tier 보조(§④-2-bis-4)"
            elif t in ("break", "harm"):
                basis = "tier4 잔여 효과(§④-6) — 합·충 우선"
            h = RelationHit(type=t, status="formed", positions=(p1, p2), members=(b1, b2),
                            element_transformed=elem, coefficient_candidates=coef, basis=basis)
            pair_hits_by_type.setdefault(t, []).append(h)

    # 쟁합(D-031): 육합 위치 공유 → contended + 화기 억제
    for t in ("combine_6",):
        hs = pair_hits_by_type.get(t, [])
        shared = {p for a, b in combinations(hs, 2) for p in set(a.positions) & set(b.positions)}
        for i, h in enumerate(hs):
            if set(h.positions) & shared:
                hs[i] = RelationHit(type=h.type, status="contended", positions=h.positions,
                                    members=h.members, element_transformed=None,
                                    coefficient_candidates=h.coefficient_candidates,
                                    basis="쟁합 — 화기 억제(D-031)")
    for hs in pair_hits_by_type.values():
        hits.extend(hs)

    # ── 삼합·방국 (§④-3) ──
    present = {b for _, b in bpos}
    for elem, spec in SAMHAP.items():
        got = [pb for pb in bpos if pb[1] in spec["branches"]]
        distinct = {b for _, b in got}
        tu = any(STEM_ATTR[s]["element"] == elem for _, s in spos)
        if len(distinct) == 3:
            coef, grade = (1.0, "극강") if tu else (0.8, "강")
            hits.append(RelationHit("combine_3", "formed", tuple(p for p, _ in got),
                                    tuple(b for _, b in got), elem, (coef,),
                                    f"삼합 {elem}局 3자 — {grade}({'투출' if tu else '미투출'})"))
        elif len(distinct) == 2 and distinct & WANGJI:
            coef, grade = (0.5, "중") if tu else (0.3, "약")
            hits.append(RelationHit("combine_3", "half", tuple(p for p, _ in got),
                                    tuple(b for _, b in got), elem if tu else None, (coef,),
                                    f"반합(왕지 포함, v6.3) — {grade}({'투출' if tu else '미투출'})"))
        # 왕지 미포함 2자 = 불성립 0% — 미방출(존재/부재 이진)
    for elem, spec in BANGGUK.items():
        got = [pb for pb in bpos if pb[1] in spec["branches"]]
        if len({b for _, b in got}) == 3:
            hits.append(RelationHit("direction_group", "formed", tuple(p for p, _ in got),
                                    tuple(b for _, b in got), elem, (0.8,), "방국 3자(투출 불필요) — 강"))

    # ── 형 (§④-2-bis-1): 삼형 3자/반형 2자 · 상형 · 자형 ──
    for trio in HYEONG["삼형"]:
        got = [pb for pb in bpos if pb[1] in trio]
        d = {b for _, b in got}
        if len(d) == 3:
            hits.append(RelationHit("punishment", "formed", tuple(p for p, _ in got),
                                    tuple(b for _, b in got), basis="삼형 3자 완성"))
        elif len(d) == 2:
            hits.append(RelationHit("punishment", "half", tuple(p for p, _ in got),
                                    tuple(b for _, b in got), basis="반형(삼형 2자)"))
    for pair in HYEONG["상형"]:
        got = [pb for pb in bpos if pb[1] in pair]
        if len({b for _, b in got}) == 2:
            hits.append(RelationHit("punishment", "formed", tuple(p for p, _ in got),
                                    tuple(b for _, b in got), basis="상형(子卯)"))
    for b in SELF_PUNISH:
        got = [pb for pb in bpos if pb[1] == b]
        if len(got) >= 2:
            hits.append(RelationHit("punishment", "formed", tuple(p for p, _ in got),
                                    tuple(x for _, x in got), basis="자형(동일 지지 중첩)"))

    # ── 천간합 + 화기 3대 요건 (§④-4) ──
    stem_hits: List[RelationHit] = []
    for (p1, s1), (p2, s2) in combinations(spos, 2):
        key = tuple(sorted((s1, s2)))
        if key not in CHEONGANHAP_N:
            continue
        spec = CHEONGANHAP_N[key]
        elem = spec["element"]
        c1 = FIVE_CONTROLS[month_elem] != elem                       # 요건1: 월령 비극제
        c2 = any(s in spec["required_stems"] for _, s in spos)       # 요건2: 투출
        c3 = any(b in spec["root_branches"] for _, b in bpos)        # 요건3(보조): 통근
        ok = c1 and c2
        basis = (f"화기 {elem} 성립" if ok else f"합거(화기 불성립: "
                 + ("월령 극제" if not c1 else "미투출") + ")") + f" · 통근 {'O' if c3 else 'X'}(보조)" \
                + (" · 월령 旺相" if _wang_sang(month_elem, elem) else "")
        stem_hits.append(RelationHit("stem_combine", "formed", (p1, p2), (s1, s2),
                                     elem if ok else None, None, basis))
    shared = {p for a, b in combinations(stem_hits, 2) for p in set(a.positions) & set(b.positions)}
    for i, h in enumerate(stem_hits):
        if set(h.positions) & shared:
            stem_hits[i] = RelationHit(h.type, "contended", h.positions, h.members, None, None,
                                       "쟁합 — 화기 억제(D-031)")
    hits.extend(stem_hits)

    prio = {"combine_3": 0, "direction_group": 0, "combine_6": 1, "stem_combine": 1,
            "clash": 2, "punishment": 3, "break": 3, "harm": 3, "wonjin": 3, "hidden_combine": 4}
    hits.sort(key=lambda h: (prio[h.type], POS_ORDER.index(h.positions[0])))
    return hits


def relations_for_chart(fp: FourPillars) -> List[RelationHit]:
    stems = {"year": fp.year.ganji[0], "month": fp.month.ganji[0], "day": fp.day.ganji[0],
             "hour": fp.hour.ganji[0] if fp.hour else None}
    branches = {"year": fp.year.ganji[1], "month": fp.month.ganji[1], "day": fp.day.ganji[1],
                "hour": fp.hour.ganji[1] if fp.hour else None}
    return detect_relations(stems, branches)
