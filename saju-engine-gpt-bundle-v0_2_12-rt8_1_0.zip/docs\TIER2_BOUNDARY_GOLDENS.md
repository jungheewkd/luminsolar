# tier2 boundary goldens — 질적 코어 회귀망 (§4-1)

> ASK 재설계 §4-1. boundary 명식에서 **LLM tier2 판정**(격국·용신·운 길흉)을 잠그는
> 회귀망. tier1(결정론)은 `tests/_golden/*.json`이 이미 잠그므로, 본 망은 그 위에
> "어느 fixture가 어느 boundary 클래스의 tier2 회귀 대상인가" + "그 판정을 어떻게
> 1회성으로 캡처·동결하는가"를 담당한다.
>
> SoT 파일: `tests/tier2_boundary_corpus.py`(코퍼스·헬퍼) · `tests/gen_tier2_boundary.py`
> (생성기) · `tests/test_tier2_boundary.py`(회귀) · `tests/_golden_tier2/`(매니페스트).

---

## 1. 왜 필요한가

tier1(엔진)은 두 런타임(수동 풀컨텍스트 / 미래 API 최소컨텍스트)에서 **완전 일치** →
golden diff로 $0 검증된다. 그러나 **tier2**(강약 verdict·격국·용신·청탁/진가·운 길흉)는
LLM 판단이라 컨텍스트 구성에 민감하고, 특히 **경계(임계) 명식**에서 발산이 집중된다.
미구축 시 질적 코어 회귀는 무방비다. 본 망이 잠그는 4개 boundary 클래스:

| 클래스 | 의미 | tier1 원시 증거(결정론) | 대표 fixture |
|:--|:--|:--|:--|
| `boundary_hold` | 강약 임계 보류(candidates 양방향) | `strength.boundary_hold=true`·`candidates` | `qi_only` |
| `false_pattern` | 假格(validity 의문 — 가종/합화 진가) | 관계 `status=contended`(쟁합)·합이불화 | `with_longitude` |
| `mediation_gate` | 통관(중재) | `combine_3 formed` · `clash` 無 | `samhap_pure` |
| `near_equal_conflict` | 비등 합충(세력 비등) | `combine_3 formed` + `clash` | `samhap_full` |

> `false_pattern`(假格)은 가종(종격 진가)·합화 진가를 포괄하는 validity 의문 클래스다.
> `with_longitude`는 그중 **합화진가/쟁합 半**만 탐하며(7뿌리·quasi_weak로 종격 자체는
> 불성립), 종격(follow)은 별도 ASK4 위임 dead-branch(D-074)다 — 클래스명에 'follow'를
> 쓰지 않는 이유. legend `validity:假格`와 정합.

> 클래스↔fixture 매핑 근거는 `tests/_golden/*.json`의 `relations`·`boundary_hold`
> **실측**이다(추측 아님 — corpus 철학). 가종/가격·통관·비등 자체는 tier1 **필드명이
> 아니라** tier2 판단의 개념 라벨이며, tier1은 그 판단을 먹이는 *원시 증거*만 방출한다.

---

## 2. 2층 구조

### Layer-1 — 캡처-컨텍스트 매니페스트 (본 세션 완료 · 비차단 · $0 · CI)

각 케이스의 캡처 컨텍스트(= `assemble_slice(stage)` 슬라이스 + fixture tier1)를
**sha256 매니페스트**로 동결한다(`tests/_golden_tier2/<fixture>__<stage>.manifest.json`).
슬라이스는 4케이스 공통이라 풀 번들(~100KB)을 4×저장하지 않고 해시만 잠근다
(드리프트 탐지력 동일·바이트 수백). **슬라이스/엔진 드리프트 시 해시 변경 = 기존
캡처 무효화 신호**.

```
python tests/gen_tier2_boundary.py            # 매니페스트 생성/갱신
python tests/gen_tier2_boundary.py --check    # diff + 캡처 상태 요약
```

### Layer-2 — captured_tier2 → assembled 골든 (1회성 캡처 후)

`captured_tier2`(LLM ASK N stage_output)가 고정되면 `assemble_handoff` 병합은
결정론 → assembled 핸드오프를 골든으로 잠근다. **이것이 §4-1의 "유일한 1회성 API
비용"**(LLM tier2 출력을 한 번 캡처해 golden화).

> ✅ **strength 재배치 적용됨(KERNEL 개정 — assemble 측).** 과거 boundary_hold=true 명식
> 병합이 막혔던 `strength` top-key 충돌은 해소됐다. `assemble_handoff.rehome_strength`가
> 엔진 `tier1_facts.strength`(결정론 SoT)를 canonical 필드명(`verdict_center→verdict_code`·
> `deuk_*_raw→deuk_*_pct`)으로 `tier2_interpretation.strength`에 병합하고 tier1에서 제거한다
> (ASK 7-1 §2013 스키마 정합). 엔진 결정론 값(verdict·pct·boundary_hold·candidates·
> boundary_evidence=confidence_asymmetry)이 권위(R2′)이고, LLM의 `strength.boundary`
> (강·약 가지 yong/hee/gi/gu·operative_branch 판단)는 보존된다. boundary_hold=true 명식의
> `derived_lookup.element_favorability`는 **by_branch**(operative_branch + 강·약 가지별 맵)로
> 산출된다(§4-2). `test_boundary_strength_rehomed_no_collision`·
> `test_synthetic_boundary_by_branch_favorability`가 잠근다.
>
> **남은 게이트는 1회성 캡처뿐** — boundary/비-boundary 모두 `captured_tier2`만 채우면
> assembled 골든을 동결할 수 있다. `SYNTHETIC`(비-boundary·single)·`SYNTHETIC_BOUNDARY`
> (boundary·by_branch) self-test가 두 경로를 각각 기계 검증한다.
>
> ※ 미적용(LEAN 봉인 비목표): tier1의 그 외 canonical 재구조화(`time_context→true_solar_time`·
> `flow_signals→flow` 중첩·chart 재배치)는 ASK 7-1 수동 직렬화 소관. `--assemble`은 strength만
> 재배치한 LEAN 봉투를 낸다(legend·spec·consumer_scope 미재생산과 동일 원칙).

---

## 3. 1회성 캡처 절차

1. **캡처 프롬프트 생성** (대기 케이스 풀 번들 stdout):
   ```
   python tests/gen_tier2_boundary.py --capture-prompts
   ```
   각 번들 = `[A] STAGE 슬라이스(system)` + `[B] fixture tier1_facts` +
   `[C] inputs.prior(선행 tier2 — 체인에서 채움)` + `[D] 캡처 지시`.

2. **체인 캡처.** ASK 4는 `inputs.prior`로 ASK 2(강약 verdict)·ASK 3(energy_map)
   tier2를 읽는다. 충실 캡처는 ASK 2 → 3 → 4 순으로(같은 생성기·`capture_stage`만 교체)
   선행 tier2를 얻어 `[C]`에 붙여넣은 뒤 ASK 4를 캡처한다. 캡처 환경 = **프로덕션
   Custom GPT**(본 프롬프트 보유) — 수동 LEAN 모드는 과대평가 위험이 있으므로 경계
   케이스는 가급적 API/실제 GPT로.

3. **기록.** 받은 순수 JSON을 `TIER2_BOUNDARY_CASES`의 해당 케이스 `captured_tier2`에
   넣고 `provenance`(model·date·매니페스트 `bundle_sha256`)를 적는다.

4. **골든화.** Layer-2 generator로 assembled 골든 생성 후 diff 리뷰·커밋. boundary/
   비-boundary 모두 strength 재배치 적용으로 봉인 가능(§2 블로커 해소됨).

5. **재캡처 트리거.** 프롬프트/엔진 변경으로 Layer-1 매니페스트 해시가 바뀌면
   (`--check` CHANGED) 기존 캡처는 stale → 재캡처.

---

## 4. 회귀 잠금 철학 (gen_golden.py와 동일)

테스트는 매니페스트/골든을 **자동 재생성하지 않는다**. 의도된 변경 시 사람이
generator를 명시 실행해 갱신하고 diff를 리뷰·커밋한다. 실행은 pytest(메모리
`python-invocation` 격리 venv) 또는 `--check`(Layer-1만).
