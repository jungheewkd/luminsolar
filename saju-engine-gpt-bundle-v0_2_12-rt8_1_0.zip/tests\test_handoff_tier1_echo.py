"""handoff tier1 생성기 CI 게이트 (P2) — build_handoff_tier1: 엔진 raw → handoff tier1_facts.

핵심 불변식: **round-trip** — 생성기 출력을 verify_against_engine(증분1)에 넣으면 위반 0
(생성↔검증 단일 스펙 자동 증명 + no-new-values). + BLIND SLOT null · 운십성 derived ·
지장간 역순 · dual-path assemble(engine_tier1) · legacy 불변.
직접 실행(pytest 미가용): PYTHONUTF8=1 PYTHONPATH=. py -m pytest tests/test_handoff_tier1_echo.py
"""
from __future__ import annotations

import pytest

from tools import assemble_handoff as ah
from tools import handoff_verify as hv
from tests.corpus import build_case, TIER1_CASES

_LABELS = ("canonical_A", "canonical_B", "lichun_after", "samhap_full",
           "qi_only", "dst_window", "utc830_1954", "region_dokdo", "condB_samhap")
_CASES = {c.label: c for c in TIER1_CASES if c.label in _LABELS}


def _wrap(raw: dict) -> dict:
    """생성기 tier1 + 엔진 strength canonical을 handoff 형상으로 감싼다(verify 입력용)."""
    t1 = hv.build_handoff_tier1(raw)
    s = hv._strength_canonical(raw["strength"])
    strength = {k: v for k, v in s.items() if not k.startswith("_")}
    if "_boundary" in s:
        strength["boundary"] = {"candidates": s["_boundary"]["candidates"],
                                "confidence_asymmetry": s["_boundary"]["confidence_asymmetry"]}
    return {"schema": ah.SCHEMA, "tier1_facts": t1, "tier2_interpretation": {"strength": strength}}


# ── round-trip: 생성기 출력이 검증기를 통과(단일 스펙·no-new-values) ──
@pytest.mark.parametrize("label", _LABELS)
def test_generator_output_passes_verifier(label):
    raw = build_case(_CASES[label])
    assert hv.verify_against_engine(_wrap(raw), raw) == []


# ── BLIND SLOT은 null(엔진 미산출 — P3에서 채움) ──────────────────
def test_blind_slots_null():
    t1 = hv.build_handoff_tier1(build_case(_CASES["canonical_A"]))
    assert t1["chart"]["branch_climate"] is None
    assert t1["flow"]["current_daewoon"] is None
    assert t1["flow"]["current_se_woon"] is None


# ── 구조·불변 ──────────────────────────────────────────────────────
def test_day_master_and_five_elements():
    raw = build_case(_CASES["canonical_A"])
    t1 = hv.build_handoff_tier1(raw)
    assert t1["chart"]["ten_gods"]["day"]["stem"] == "day_master"
    for n in ("year", "month", "day"):
        fe = t1["chart"]["five_elements"][n]
        assert len(fe) == 2 and all(e in ah.ELEMENTS for e in fe)


def test_jijanggan_inversion_in_generator():
    raw = build_case(_CASES["canonical_A"])
    t1 = hv.build_handoff_tier1(raw)
    for n in ("year", "month", "day"):
        p = raw["chart"][n]
        assert t1["chart"]["ji_jang_gan"][n]["bon"] == p["hidden_stems"][0]
        assert t1["chart"]["ji_jang_gan"][n]["yeo"] == p["hidden_stems"][2]


def test_condition_b_hour_null():
    t1 = hv.build_handoff_tier1(build_case(_CASES["canonical_B"]))
    assert t1["chart"]["pillars"]["hour"] is None
    assert t1["chart"]["five_elements"]["hour"] is None
    assert t1["true_solar_time"]["applied"] is False     # 시간 미상 → 진태양시 미적용
    assert "±1년" in t1["flow"]["start_age"]               # 조건 B 유예


def test_relations_char_from_chart():
    raw = build_case(_CASES["samhap_full"])
    t1 = hv.build_handoff_tier1(raw)
    for r in t1["chart"]["relations"]:
        for m in r["members"]:
            pillar, channel = m["pos"].rsplit("_", 1)
            assert m["char"] == raw["chart"][pillar][channel]


def test_daewoon_ten_god_derived_and_valid():
    """운십성은 엔진 미동봉 → 일간×운간지 derived lookup. legend ten_god 코드로 폐쇄."""
    from tools import handoff_static as hs
    raw = build_case(_CASES["samhap_full"])
    t1 = hv.build_handoff_tier1(raw)
    for e in t1["flow"]["daewoon_table"]:
        assert e["stem_ten_god"] in hs.LEGEND["ten_god"]
        assert e["branch_ten_god"] in hs.LEGEND["ten_god"]


# ── dual-path assemble: engine_tier1 → 생성기 / legacy 불변 ─────────
def test_assemble_engine_tier1_path():
    raw = build_case(_CASES["samhap_full"])          # boundary_hold=False (minimal tier2로 충분)
    h = ah.assemble({"engine_tier1": raw, "tier2_interpretation": {"yong_shen": {"element": "wood"}}})
    yr = raw["chart"]["year"]
    assert h["tier1_facts"]["chart"]["pillars"]["year"] == yr["stem"] + yr["branch"]
    assert "strength" not in h["tier1_facts"]                                    # rehome 완료
    assert h["tier2_interpretation"]["strength"]["verdict_code"] == raw["strength"]["verdict_center"]
    assert hv.verify_against_engine(h, raw) == []                                # 생성 tier1 ↔ raw 정합


def test_assemble_legacy_path_unchanged():
    h = ah.assemble({"tier1_facts": {"chart": {}}, "tier2_interpretation": {"yong_shen": {"element": "wood"}}})
    assert ah.validate(h) == [] and h["schema"] == ah.SCHEMA


def test_generator_idempotent():
    raw = build_case(_CASES["samhap_full"])
    assert hv.build_handoff_tier1(raw) == hv.build_handoff_tier1(raw)
