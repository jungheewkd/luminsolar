"""tier2 boundary 골든 코퍼스 — 질적 코어(ASK 4 격국/용신·운 길흉) 회귀망의 토대 (§4-1).

boundary 명식에서 LLM tier2 판정을 잠그기 위한 골든의 fixture·클래스 매핑이다.
tier1(결정론) 기질은 corpus.TIER1_CASES 골든이 이미 잠근다 — 본 코퍼스는 그 위에
'어느 fixture가 어느 boundary 클래스의 tier2 회귀 대상인가'를 명시하고, 1회성 LLM
캡처를 위한 캡처 번들(slice + 입력 tier1)을 결정론으로 생성한다.

2층 구조:
  Layer-1 (본 세션 — 비차단·$0·CI): 캡처 번들(capture_prompt) 자체를 골든 동결.
      → assemble_slice(결정론) + fixture tier1(결정론)이므로 바이트 안정.
      → "LLM에게 무엇을 물을지"를 잠근다 — 프롬프트/엔진 드리프트 시 캡처 무효화 탐지.
  Layer-2 (1회성 캡처 후): captured_tier2 → assemble_handoff → assembled 핸드오프 골든.
      → captured_tier2가 고정되면 병합은 결정론 → assembled 골든으로 CI 잠금.

⚠️ Layer-2 게이팅 이슈(boundary_hold=true): ASK 4 tier2가 strength.boundary를 emit하는데,
   assemble_handoff가 canonical v3.7 strength 재배치(R2′ 에코 — tier1_facts.strength →
   tier2_interpretation.strength)를 미구현하여 tier1_facts.strength와 top-key 충돌한다
   (prior 세션이 보류한 'KERNEL 개정 1건'). → boundary_hold=true 명식 Layer-2는 그 개정 후.
   상세: docs/TIER2_BOUNDARY_GOLDENS.md.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import List, Optional

# ── boundary 클래스 (§4-1이 잠그려는 4종 질적 임계) ──────────────────
#   tier1은 '원시 증거'만 결정론 방출(boundary_hold·candidates·relation status=contended 등);
#   가종/가격·통관·비등의 *판정*은 tier2(LLM) 소관 → 그 판정을 잠그는 게 본 코퍼스 목적.
#   ※ false_pattern = 假格 umbrella(validity 의문) — 가종(종격 진가)·합화 진가(합이불화)
#     양쪽을 포괄한다. 종격(follow) 자체는 ASK4 위임 dead-branch(D-074)이므로 클래스명에
#     'follow'를 쓰지 않는다(legend validity:假格와 정합).
BOUNDARY_CLASSES = (
    "boundary_hold",        # 강약 임계 보류(candidates 양방향) — 용신 가지전환 가능
    "false_pattern",        # 假格(validity 의문) — 쟁합(status=contended)·합이불화 raw 증거
    "mediation_gate",       # 통관 — 삼합 formed·무충(순수 중재)
    "near_equal_conflict",  # 비등 합충 — 삼합∥충 등 세력 비등
)


@dataclass(frozen=True)
class Tier2BoundaryCase:
    fixture: str                              # corpus.TIER1_CASES 라벨 참조(결정론 기질)
    boundary_class: str                       # BOUNDARY_CLASSES 중 1
    capture_stage: str = "ask_4"              # 캡처 대상 모듈(격국·용신 코어가 기본)
    captured_tier2: Optional[dict] = None     # LLM ASK N tier2_interpretation(None=캡처 대기)
    provenance: str = ""                      # 캡처 시 model·date·slice/tier1 해시
    note: str = ""

    @property
    def label(self) -> str:
        return f"{self.fixture}__{self.capture_stage}"


# ── 핀 고정 boundary 케이스 (각 클래스 대표 fixture — corpus 골든 실측 기반) ──
#   클래스 매핑 근거는 _golden/*.json relations·boundary_hold 실측(추측 아님):
#     qi_only        : boundary_hold=true · quasi_strong (강약 임계 보류)
#     with_longitude : combine_6 contended ×3 (쟁합 — 합화 진가/가합 정성판단 raw 증거;
#                      이 fixture는 假格의 *합화진가* 半만 탐. 종격은 ASK4 dead-branch)
#     samhap_pure    : combine_3 formed · clash 無 (순수 통관 — samhap_full와 분리)
#     samhap_full    : combine_3 formed + clash (세력 비등 합충)
TIER2_BOUNDARY_CASES: List[Tier2BoundaryCase] = [
    Tier2BoundaryCase("qi_only", "boundary_hold",
                      note="boundary_hold=true·quasi_strong — 용신 의존 진술 가지전환 가능 baseline"),
    Tier2BoundaryCase("with_longitude", "false_pattern",
                      note="쟁합(combine_6 contended ×3) — 합화 진가/가합(false-combine) 정성판단 raw 증거. 假格 클래스의 합화진가 半"),
    Tier2BoundaryCase("samhap_pure", "mediation_gate",
                      note="삼합 combine_3 formed·무충 — 순수 통관(중재) 게이트"),
    Tier2BoundaryCase("samhap_full", "near_equal_conflict",
                      note="삼합 combine_3 formed + 충 동시 — 세력 비등 합충"),
]

# ── 하니스 self-test용 SYNTHETIC ───────────────────────────────────
#   ⚠️ 실제 명리 판정이 아니다 — Layer-2 파이프라인(captured→assemble→derived_lookup)의
#   기계 검증 전용 더미. boundary_hold=false fixture + strength 없는 tier2 →
#   assemble_handoff top-key 충돌 회피(=오늘 작동하는 비-boundary 경로만 검증).
SYNTHETIC = Tier2BoundaryCase(
    "samhap_pure", "mediation_gate",
    captured_tier2={
        "pattern": {"code": "SYNTH", "validity": "true"},
        "yong_shen": {"element": "wood", "ten_god": "jeong_gwan", "authenticity": "true"},
        "hee_shen": {"element": "water", "ten_god": "jeong_in"},
        "gi_shin": {"element": "metal", "ten_god": "pyeon_gwan"},
        "gu_shin": {"element": "earth", "ten_god": "jeong_jae", "conditional": None},
        "clarity": {"mode": "mid", "single": "中", "by_branch": None},
        "disease": None,
    },
    provenance="SYNTHETIC — 하니스 검증 전용(명리 판정 아님)",
    note="Layer-2 파이프라인(captured→assemble→derived_lookup) 기계검증",
)

# boundary_hold=true Layer-2 경로(strength 재배치 + by_branch favorability) 기계검증용 더미.
# canonical strong_branch/weak_branch = 가지별 용/희/기/구 dict(ASK 7 §2013 스키마).
SYNTHETIC_BOUNDARY = Tier2BoundaryCase(
    "qi_only", "boundary_hold",
    captured_tier2={
        "pattern": {"code": "jeong_gwan_gyeok", "validity": "true"},
        "yong_shen": {"element": "wood"}, "hee_shen": {"element": "water"},
        "gi_shin": {"element": "metal"}, "gu_shin": {"element": "earth"},
        "clarity": {"mode": "by_branch", "single": None,
                    "by_branch": {"strong": {"grade": "mid"}, "weak": {"grade": "mid"}}},
        "disease": None,
        "strength": {"boundary": {
            "strong_branch": {"yong_shen": "fire", "hee_shen": "wood",
                              "gi_shin": "water", "gu_shin": "metal", "authenticity": "true"},
            "weak_branch": {"yong_shen": "water", "hee_shen": "metal",
                            "gi_shin": "earth", "gu_shin": "fire", "authenticity": "true"},
            "common_anchor": "wood", "activation_key": "현대운 순오행",
            "operative_branch": "strong_branch", "operative_basis": "현 대운 비겁운→strong",
        }},
    },
    provenance="SYNTHETIC — 하니스 검증 전용(명리 판정 아님)",
    note="Layer-2 boundary 경로(strength 재배치 + by_branch favorability) 기계검증",
)


# ── 헬퍼 (지연 import — 코퍼스 임포트 자체는 엔진/슬라이서 불요) ──────
def _fixture_case(label: str):
    from tests.corpus import TIER1_CASES
    by = {c.label: c for c in TIER1_CASES}
    if label not in by:
        raise KeyError(f"tier2 boundary fixture '{label}'가 corpus.TIER1_CASES에 없음")
    return by[label]


def fixture_tier1(label: str) -> dict:
    """fixture 라벨 → 결정론 tier1_facts dict(corpus 빌더 재사용)."""
    from tests.corpus import build_case
    return build_case(_fixture_case(label))


def capture_prompt(case: Tier2BoundaryCase) -> str:
    """1회성 LLM 캡처 번들 = STAGE 슬라이스(system) + fixture tier1(입력) + 캡처 지시.

    inputs.prior(ASK 2·3 tier2)는 선행 캡처에서 채운다 — 절차는
    docs/TIER2_BOUNDARY_GOLDENS.md. 본 번들은 결정론(slice+tier1) → Layer-1 골든."""
    from tools.assemble_slice import assemble_slice
    c = _fixture_case(case.fixture)
    slice_txt = assemble_slice(case.capture_stage)
    t1 = fixture_tier1(case.fixture)
    return "\n".join([
        f"<!-- TIER2 CAPTURE BUNDLE · fixture={case.fixture} · stage={case.capture_stage}"
        f" · class={case.boundary_class} -->",
        f"<!-- 명식: {c.birth} · {c.gender} · {c.note} -->",
        "",
        "######## [A] STAGE 슬라이스 (system 프롬프트) ########",
        "",
        slice_txt,
        "",
        "######## [B] 입력 tier1_facts (이 명식의 결정론 사실) ########",
        "",
        "```json",
        json.dumps(t1, ensure_ascii=False, indent=2),
        "```",
        "",
        "######## [C] inputs.prior (선행 tier2 — 체인 캡처에서 채움) ########",
        "",
        "{{ASK 2·3 tier2_interpretation: 선행 단계 캡처 결과를 여기 붙여넣음}}",
        "",
        "######## [D] 캡처 지시 ########",
        "",
        f"위 [A] STAGE CONTRACT(id={case.capture_stage})의 `output` 경로 형태로 "
        "이 명식의 tier2_interpretation stage_output을 **순수 JSON으로만** 출력하라"
        "(산문·MENU 금지). 그 JSON을 tier2_boundary_corpus.TIER2_BOUNDARY_CASES의 "
        "해당 케이스 captured_tier2에 기록하고 provenance(model·date)를 적는다.",
        "",
    ])


def assembled(case: Tier2BoundaryCase) -> dict:
    """captured_tier2 + fixture tier1 → assemble_handoff v3.8 (Layer-2 — captured 필요)."""
    if case.captured_tier2 is None:
        raise ValueError(f"{case.label}: captured_tier2 미캡처 — 1회성 캡처 필요(Layer-2)")
    from tools.assemble_handoff import assemble
    return assemble({
        "tier1_facts": fixture_tier1(case.fixture),
        "tier2_interpretation": case.captured_tier2,
    })


def class_coverage() -> dict:
    """boundary 클래스 → 매핑된 fixture 라벨 목록(완전성 점검용)."""
    cov: dict = {k: [] for k in BOUNDARY_CLASSES}
    for c in TIER2_BOUNDARY_CASES:
        cov.setdefault(c.boundary_class, []).append(c.fixture)
    return cov
