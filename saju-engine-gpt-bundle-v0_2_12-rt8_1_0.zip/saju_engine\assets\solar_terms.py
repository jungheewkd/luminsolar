"""절기 xlsx 로더 + 질의 (Step 2 — 핀 검증·912행·12節).

- usecols 상당: A(datetime)·B(절기명)만 읽음 — 3열 함정 회피 (CORRECTIONS C-001).
- A열은 이미 datetime 셀 — 변환 산술 금지, 비교·필터만 (§A3).
- 시각 기준계: 당시 표준시(비DST) — boundary_dt와 직접 비교 가능 (§A3, CONVENTIONS §2).
"""
from __future__ import annotations

import bisect
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import List, Optional, Tuple

# D-062(F1): openpyxl는 xlsx 검증 경로 전용 → 모듈 최상위가 아니라 load_solar_terms() 안에서
# 지연 import 한다. 기본 emit 경로(xlsx_path=None)는 BASE_ROWS 스냅샷만 쓰므로 순수 stdlib로 동작
# (emit_tier1_standalone docstring의 'stdlib + korean_lunar_calendar만' 계약 준수).

# 12節 → 월지 (§A4: 입춘→寅 … 소한→丑)
JIE_TO_MONTH_BRANCH = {
    "입춘": "寅", "경칩": "卯", "청명": "辰", "입하": "巳", "망종": "午", "소서": "未",
    "입추": "申", "백로": "酉", "한로": "戌", "입동": "亥", "대설": "子", "소한": "丑",
}
JIE_NAMES = set(JIE_TO_MONTH_BRANCH)


class SolarTerms:
    def __init__(self, entries: List[Tuple[datetime, str]]):
        self.entries = sorted(entries)               # (절입 dt, 절기명) 오름차순
        self._dts = [e[0] for e in self.entries]
        self.min_year = self._dts[0].year
        self.max_year = self._dts[-1].year

    # ── 질의 ────────────────────────────────────────────────
    def term_dt(self, year: int, term: str) -> datetime:
        for dt, name in self.entries:
            if dt.year == year and name == term:
                return dt
        raise LookupError(f"절기 미수록: {year} {term} (커버리지 {self.min_year}~{self.max_year})")

    def lichun(self, year: int) -> datetime:
        return self.term_dt(year, "입춘")

    def prev_jie(self, dt: datetime) -> Tuple[str, datetime]:
        """dt를 소유하는 직전(≤, CONVENTIONS §4) 12節."""
        i = bisect.bisect_right(self._dts, dt) - 1
        if i < 0:
            raise LookupError(f"{dt} 이전 절기 미수록 (커버리지 시작 {self._dts[0]})")
        d = self.entries[i]
        return d[1], d[0]

    def next_jie(self, dt: datetime) -> Tuple[str, datetime]:
        """dt보다 strictly 이후(>) 최초 12節 (대운 순행 기준절 — D-011)."""
        i = bisect.bisect_right(self._dts, dt)
        if i >= len(self.entries):
            raise LookupError(f"{dt} 이후 절기 미수록 (커버리지 끝 {self._dts[-1]})")
        d = self.entries[i]
        return d[1], d[0]


@lru_cache(maxsize=1)
def load_solar_terms_extended():
    """xlsx(1951–2026 SoT) + ephemeris 스냅샷(2027–2035, D-047 확장 전용). D-022 솔기의 이행."""
    from datetime import datetime as _dt
    from saju_engine.assets.solar_terms_ext import EXT_ROWS
    base = load_solar_terms()
    entries = list(base.entries) + [(_dt.strptime(k, "%Y-%m-%d %H:%M"), j) for y, j, k in EXT_ROWS if y > 2026]
    return SolarTerms(entries)


def load_solar_terms(xlsx_path: Optional[str] = None, verify_pin: bool = True) -> SolarTerms:
    """기본 = base 스냅샷(stdlib만 — v7.2, D-048 확장). xlsx 경로 지정 시에만 핀 파싱(SoT 검증용)."""
    if xlsx_path is None:
        from saju_engine.assets.solar_terms_base import BASE_ROWS
        return SolarTerms([(datetime.strptime(d, "%Y-%m-%d %H:%M"), n) for d, n in BASE_ROWS])
    import openpyxl  # D-062(F1): xlsx 경로에서만 필요 — 지연 import
    p = Path(xlsx_path)
    wb = openpyxl.load_workbook(p, data_only=True, read_only=True)
    ws = wb["solar_terms_data"]
    entries = []
    for row in ws.iter_rows(values_only=True):
        dt, term = row[0], row[1]                    # C열(빈 열) 무시 — usecols=[0,1] 상당
        if isinstance(dt, datetime) and isinstance(term, str) and term in JIE_NAMES:
            entries.append((dt.replace(second=0, microsecond=0), term))
    wb.close()
    if not entries:
        raise ValueError("절기 데이터 0건 — 파일/시트 확인")
    return SolarTerms(entries)
