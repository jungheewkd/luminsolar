"""tier2 boundary 골든 회귀 — Layer-1 캡처-컨텍스트 잠금 + Layer-2 파이프라인 self-test (§4-1).

프롬프트 .md 부재(번들-only 배포) 시 슬라이서 의존 테스트는 skip. 코퍼스 무결성
테스트는 항상 실행. 실행은 saju-engine 표준대로 pytest(메모리 python-invocation의
격리 venv 레시피 참조) 또는 `tests/gen_tier2_boundary.py --check`(Layer-1 골든만).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
ENGINE_ROOT = HERE.parent
REPO_ROOT = ENGINE_ROOT.parent
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

from tests.conftest import read_text, norm                       # noqa: E402
from tests.corpus import TIER1_CASES                             # noqa: E402
from tests.tier2_boundary_corpus import (                        # noqa: E402
    TIER2_BOUNDARY_CASES, SYNTHETIC, SYNTHETIC_BOUNDARY, BOUNDARY_CLASSES,
    capture_prompt, fixture_tier1, assembled, class_coverage,
)
from tests import gen_tier2_boundary as gen                      # noqa: E402
from tools.assemble_slice import prompts_present                 # noqa: E402

# 가드 = 의존 슬라이서와 동일 기준(3파일) — 부분 배포 raw FileNotFoundError 차단.
_PROMPTS = prompts_present()
_skip_no_prompts = pytest.mark.skipif(not _PROMPTS, reason="프롬프트 .md 부재(번들-only)")
_TIER1_LABELS = {c.label for c in TIER1_CASES}


# ── 코퍼스 무결성 (슬라이서 불요 — 항상 실행) ─────────────────────
def test_corpus_fixtures_reference_real_tier1():
    for c in TIER2_BOUNDARY_CASES:
        assert c.fixture in _TIER1_LABELS, f"{c.label}: fixture '{c.fixture}'가 TIER1_CASES에 없음"


def test_corpus_classes_valid_and_covered():
    for c in TIER2_BOUNDARY_CASES:
        assert c.boundary_class in BOUNDARY_CLASSES, f"{c.label}: 미지정 boundary_class"
    cov = class_coverage()
    missing = [k for k in BOUNDARY_CLASSES if not cov.get(k)]
    assert not missing, f"미커버 boundary 클래스: {missing}"


def test_corpus_labels_unique():
    labels = [c.label for c in TIER2_BOUNDARY_CASES]
    assert len(labels) == len(set(labels)), f"중복 라벨: {labels}"


def test_prompts_guard_requires_all_three_slice_files(monkeypatch):
    """프롬프트-부재 가드 = 슬라이서 3파일 의존과 동일 기준(단일 SoT). 어느 하나라도
    부재면 False여야 부분 배포에서 raw FileNotFoundError 대신 graceful skip한다."""
    import tools.assemble_slice as sl

    class _Absent:
        @staticmethod
        def exists():
            return False

    for missing in ("CORE", "ASK", "REF"):
        monkeypatch.setattr(sl, missing, _Absent())
        assert sl.prompts_present() is False, f"{missing} 부재인데 prompts_present()=True"
        monkeypatch.undo()


def test_awaiting_cases_raise_on_assemble():
    """captured_tier2=None 케이스의 assembled()는 명확히 실패(조용한 빈 골든 방지)."""
    for c in TIER2_BOUNDARY_CASES:
        if c.captured_tier2 is None:
            with pytest.raises(ValueError):
                assembled(c)


# ── Layer-1 캡처-컨텍스트 매니페스트 골든 ─────────────────────────
@_skip_no_prompts
@pytest.mark.parametrize("c", TIER2_BOUNDARY_CASES, ids=lambda c: c.label)
def test_layer1_manifest_golden(c):
    path = gen.GOLDEN_DIR / f"{c.label}.manifest.json"
    if not path.exists():
        pytest.fail(f"매니페스트 부재: {path.name} — `python tests/gen_tier2_boundary.py` 필요")
    assert norm(read_text(path)) == norm(gen._manifest(c)), (
        f"Layer-1 회귀: {c.label} 캡처 컨텍스트가 매니페스트와 다름(슬라이스/엔진 드리프트). "
        f"의도적이면 gen_tier2_boundary.py로 갱신 후 기존 캡처 재검증."
    )


@_skip_no_prompts
@pytest.mark.parametrize("c", TIER2_BOUNDARY_CASES, ids=lambda c: c.label)
def test_capture_prompt_assembles(c):
    bundle = capture_prompt(c)
    assert "STAGE 슬라이스" in bundle and "tier1_facts" in bundle
    assert f"id={c.capture_stage}" in bundle


# ── Layer-2 assembled 골든(captured 케이스만 — 현재 0건, 캡처 시 자동 커버) ──
_CAPTURED = [c for c in TIER2_BOUNDARY_CASES if c.captured_tier2 is not None]


@_skip_no_prompts
@pytest.mark.parametrize("c", _CAPTURED, ids=lambda c: c.label)
def test_layer2_assembled_golden(c):
    import json
    path = gen.GOLDEN_DIR / f"{c.label}.assembled.json"
    if not path.exists():
        pytest.fail(f"assembled 골든 부재: {path.name} — `python tests/gen_tier2_boundary.py` 필요")
    live = json.dumps(assembled(c), ensure_ascii=False, indent=2)
    assert norm(read_text(path)) == norm(live), f"Layer-2 회귀: {c.label} assembled 핸드오프 변동"


# ── Layer-2 파이프라인 self-test (SYNTHETIC — 명리 판정 아님) ──────
@_skip_no_prompts
def test_synthetic_layer2_roundtrip():
    """captured_tier2(더미) + 실제 tier1 → assemble_handoff 결정론 병합·검증 통과.

    boundary_hold=false fixture + strength 없는 tier2 → top-key 충돌 회피
    (=오늘 작동하는 비-boundary Layer-2 경로의 기계 검증)."""
    from tools.assemble_handoff import validate, SCHEMA
    h = assembled(SYNTHETIC)
    assert h["schema"] == SCHEMA
    assert validate(h) == []
    ef = h["derived_lookup"]["element_favorability"]["single"]
    assert ef == {"wood": "favorable", "water": "favorable",
                  "metal": "unfavorable", "earth": "unfavorable", "fire": "neutral"}


# ── Layer-2 boundary 경로 (strength 재배치 해소 — KERNEL 개정 후 활성) ──
@_skip_no_prompts
def test_boundary_strength_rehomed_no_collision():
    """boundary_hold=true 명식 + ASK4 strength.boundary tier2 → strength가 tier2로
    재배치되어 top-key 충돌 없이 봉인된다(보류됐던 KERNEL 개정 = strength 재배치 적용).
    엔진 결정론 값(verdict_code·strength_pct·boundary_hold·candidates)이 권위(R2′)."""
    from tools.assemble_handoff import assemble, validate
    boundary_case = next(c for c in TIER2_BOUNDARY_CASES if c.boundary_class == "boundary_hold")
    t1 = fixture_tier1(boundary_case.fixture)
    assert t1["strength"]["boundary_hold"] is True, "전제: boundary_hold=true fixture"
    h = assembled(SYNTHETIC_BOUNDARY)
    assert "strength" not in h["tier1_facts"], "strength가 tier1에 잔존 — 재배치 미적용"
    assert "strength" in h["tier2_interpretation"], "strength가 tier2로 재배치되어야"
    assert not (set(h["tier1_facts"]) & set(h["tier2_interpretation"])), "top-key 충돌 잔존"
    s = h["tier2_interpretation"]["strength"]
    assert s["boundary_hold"] is True and s["verdict_code"] == t1["strength"]["verdict_center"]
    assert s["boundary"]["candidates"] == t1["strength"]["candidates"], "candidates 엔진 권위 아님"
    assert validate(h) == []


@_skip_no_prompts
def test_synthetic_boundary_by_branch_favorability():
    """boundary_hold=true Layer-2: derived_lookup.element_favorability가 by_branch
    (operative_branch + 강·약 가지별 5오행 맵)로 산출됨(§4-2)."""
    from tools.assemble_handoff import validate
    h = assembled(SYNTHETIC_BOUNDARY)
    ef = h["derived_lookup"]["element_favorability"]
    assert ef["mode"] == "by_branch" and ef["single"] is None
    by = ef["by_branch"]
    assert by["operative_branch"] == "strong_branch"
    # strong: yong=fire·hee=wood → fav / gi=water·gu=metal → unfav / earth=neutral
    assert by["strong_branch"] == {"wood": "favorable", "fire": "favorable", "earth": "neutral",
                                   "metal": "unfavorable", "water": "unfavorable"}
    # weak: yong=water·hee=metal → fav / gi=earth·gu=fire → unfav / wood=neutral
    assert by["weak_branch"] == {"wood": "neutral", "fire": "unfavorable", "earth": "unfavorable",
                                 "metal": "favorable", "water": "favorable"}
    assert validate(h) == []
