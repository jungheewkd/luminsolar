"""emitter 공유 헬퍼 — D-041 start_year 단일 정의(tier1.py·standalone 양쪽 사용)."""
from datetime import datetime, timedelta


def start_year(clock_dt: datetime, age: float) -> int:
    return (clock_dt + timedelta(days=age * 365.2425)).year
