"""Step 6 — TimeContext 보조: 1954 플래그용 최근접 절입 (§A3).

[통합 기록 D-027] 본 모듈은 한때 시지 2종을 중복 보유했다 — 컨텍스트 압축 경계에서
원장(D-026: 시지는 engine/hour_branch.py 단일 모듈)을 미열람한 채 재작성된 결과.
세션 의식(DECISIONS 선낭독)이 지켜졌다면 발생하지 않았을 A6 실사례. 시지는 hour_branch가 정본.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from saju_engine.assets.solar_terms import SolarTerms


def nearest_jieqi_for_flag(clock_dt: datetime, st: SolarTerms) -> Optional[datetime]:
    """1954 플래그(§A3) 판정용 최근접 절입. 동률은 prev(≤) — 오라클과 동일 규약."""
    _, d1 = st.prev_jie(clock_dt)
    _, d2 = st.next_jie(clock_dt)
    return d1 if abs((clock_dt - d1).total_seconds()) <= abs((d2 - clock_dt).total_seconds()) else d2
