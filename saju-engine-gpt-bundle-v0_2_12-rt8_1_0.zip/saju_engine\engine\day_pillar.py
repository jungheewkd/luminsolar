"""Step 3 — 일주 엔진 (§A1·A5, CONVENTIONS §5·§8).

경로: epoch 산술 단일 경로 (1900-01-31 = 甲辰 = index 40 — constants가 SoT).
- JDN 산식(§A5)은 큐레이션 전용 — 런타임 미사용 (CONVENTIONS §8).
- KASI 3중 게이트(G1~G3)의 런타임 역할 종료: 결정 산술이 LLM 암산을 대체했고, 외부 교차는
  전수 검증(KLC·KASI 데이터 기반, tools/verify_day_pillar_full.py)으로 이행. 검증창 1900-01-01~2050-12-31.
- S4 시그니처 강제: 본 모듈은 solar_dt/boundary_dt를 받지 않는다 — 일주는 벽시계 *날짜*만의 함수.
- 오라클 독립(D-017): tools/make_golden.py와 코드 공유 없음(공유는 constants 앵커뿐).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Union

from saju_engine.constants import DAY_PILLAR_EPOCH, DAY_PILLAR_EPOCH_INDEX, sexagenary_from_index
from saju_engine.constants import DayBoundaryRule


# --- D-054: 일주 전수 검증창 표명 (corrigendum — 구 하드코딩 "unchecked" 대체) ------------------
# 출처: tools/verify_day_pillar_full.py (KLC·KASI 데이터 전수 대조). 본 상수는 그 빌드 타임 검증
# *결과의 동봉 표명*이다 — 창·토큰 변경은 해당 도구 재실행(PASS) 없이 금지(릴리스 체크리스트 §V).
# 소비 계약: tier1_facts.derivation.day_pillar_kasi_cross / divination.day_ganji_kasi_cross는
# KERNEL [1′] R3′의 "전사 대상"이며, 어떤 소비자도 값에 분기하지 않는다(전사 전용).
DAY_PILLAR_VERIFIED_WINDOW = (date(1900, 1, 1), date(2050, 12, 31))
DAY_PILLAR_VERIFIED_TOKEN = "verified_full_1900_2050"
DAY_PILLAR_OUT_OF_WINDOW_TOKEN = "out_of_verified_window"


def kasi_cross_status(d: date) -> str:
    """날짜 → 일주 검증창 상태 토큰. 고정 상수가 아닌 레코드별 판정(자기서술형)."""
    lo, hi = DAY_PILLAR_VERIFIED_WINDOW
    return DAY_PILLAR_VERIFIED_TOKEN if lo <= d <= hi else DAY_PILLAR_OUT_OF_WINDOW_TOKEN
# -----------------------------------------------------------------------------------------------


def day_pillar_index(d: date) -> int:
    """양력 날짜 → 60갑자 인덱스(甲子=0)."""
    return ((d - DAY_PILLAR_EPOCH).days + DAY_PILLAR_EPOCH_INDEX) % 60


def day_pillar(d: date) -> str:
    """양력 날짜 → 일진 간지 2자."""
    return sexagenary_from_index(day_pillar_index(d))


def effective_day_date(clock_dt: datetime, rule: Union[str, DayBoundaryRule] = DayBoundaryRule.midnight) -> date:
    """일주 귀속 날짜. 기본 자정 경계(§A8) — 23h 옵션 시 23:00 이후는 익일 (사용자 고지 의무)."""
    rule = DayBoundaryRule(rule)
    if rule is DayBoundaryRule.h23 and clock_dt.hour == 23:
        return clock_dt.date() + timedelta(days=1)
    return clock_dt.date()


@dataclass(frozen=True)
class DayPillarResult:
    ganji: str
    index: int
    effective_date: date
    rule: DayBoundaryRule


def day_pillar_for_birth(clock_dt: datetime,
                         rule: Union[str, DayBoundaryRule] = DayBoundaryRule.midnight) -> DayPillarResult:
    """출생 벽시계 → 일주. solar_dt 인자 자체가 없음 = S4 불변식의 구조적 강제."""
    rule = DayBoundaryRule(rule)
    eff = effective_day_date(clock_dt, rule)
    idx = day_pillar_index(eff)
    return DayPillarResult(ganji=sexagenary_from_index(idx), index=idx, effective_date=eff, rule=rule)
