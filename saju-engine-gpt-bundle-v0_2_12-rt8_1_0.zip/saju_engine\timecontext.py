"""saju_engine.timecontext — 시각 3종 파이프라인 (CONVENTIONS §2, S1·S4 해소).

파생 사슬 고정: clock_dt → boundary_dt(−1h if DST) → solar_dt(+경도보정).
각 소비 함수는 자신이 받을 필드가 시그니처로 강제된다:
  - 일주 날짜 결정 · 매화 時數  → clock_dt
  - 년주·월주 절입 판정 · 대운 기준절 → boundary_dt
  - 시주 시지(natal)            → solar_dt

※ solar_dt = 지방평균태양시(LMT): 경도보정 + DST만 반영하고 균시차(equation of time)는
  미적용이다(=평균태양시). 라벨 "진태양시"는 관용 표기일 뿐, 엄밀한 시태양시(apparent solar
  time)는 LMT + 균시차(연중 ±~15.5분)다. 균시차 옵트인 보정은 별도 필드(apparent_solar_dt,
  기본 OFF)로 분리한다 — solar_dt 자체는 균시차를 더하지 않는다(만세력 관행·골든 호환 보존).

DST 정확 시행일표는 Step 2 자산(assets/dst_table.py)이 SoT다.
구축 전에는 DST 가능 연도(1948~1988) 입력 시 fail-loud 한다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional, Sequence, Tuple

from .constants import (
    DEFAULT_LONGITUDE_CORRECTION_MIN,
    KOREA_LONGITUDE_RANGE,
    FLAG_1954_TOLERANCE_MIN,
    FLAG_1954_WINDOW,
    STANDARD_MERIDIAN_DEG,
    UTC830_PERIODS,
)

DstPeriod = Tuple[datetime, datetime]  # [시작, 끝) 반개구간 — Step 2에서 데이터 확정


@dataclass(frozen=True)
class TimeContext:
    clock_dt: datetime                 # 벽시계 (일주 날짜·매화 時數 전용)
    boundary_dt: datetime              # 절입 경계 비교 전용
    solar_dt: Optional[datetime]       # 시지 전용 지방평균태양시(LMT: 경도보정+DST, 균시차 미적용). Condition B → None
    dst_applied: bool
    longitude_correction_min: Optional[int]
    flag_1954_window: bool = False     # §A3 예외 — 사용자 정밀 확인 요청 대상
    dst_anomaly: Optional[str] = None  # 'skipped'(존재 불가 기록) / 'ambiguous'(2회 발생) — Step 6


def _in_any_period(d: date, periods: Sequence[Tuple[date, date]]) -> bool:
    return any(a <= d <= b for a, b in periods)


def longitude_correction_minutes(birth_d: date, longitude: Optional[float]) -> int:
    """경도보정(분, 정수 ROUND_HALF_UP). UTC+8:30 법정시 구간은 0분 (§A6 ② — 이중 보정 금지)."""
    if longitude is not None and not (KOREA_LONGITUDE_RANGE[0] <= longitude <= KOREA_LONGITUDE_RANGE[1]):
        raise ValueError(
            f"경도 {longitude}는 한국 범위 {KOREA_LONGITUDE_RANGE} 밖 — 본 엔진의 DST·표준시·기본보정은 한국 전제 (해외 출생 미지원, D-025)")
    if _in_any_period(birth_d, UTC830_PERIODS):
        return 0
    if longitude is None:
        return DEFAULT_LONGITUDE_CORRECTION_MIN
    raw = Decimal(str((longitude - STANDARD_MERIDIAN_DEG) * 4))
    return int(raw.quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def build_time_context(
    clock_dt: datetime,
    *,
    has_time: bool,
    longitude: Optional[float] = None,
    dst_periods: Sequence[DstPeriod],
    nearest_jieqi_dt: Optional[datetime] = None,
) -> TimeContext:
    """출생 입력 1건 → TimeContext. (Condition B는 has_time=False — 시각 필드는 자정 가정으로 보유하되 solar_dt=None.)

    dst_periods는 명시 주입(기본값 없음): Step 2 자산 미구축 상태에서의 silent 오용 차단.
    nearest_jieqi_dt: 1954 플래그 판정용 인접 절입 시각(선택 — Step 4 이후 결선).
    """
    clock_dt = clock_dt.replace(second=0, microsecond=0)

    dst = any(a <= clock_dt < b for a, b in dst_periods)
    boundary_dt = clock_dt - timedelta(hours=1) if dst else clock_dt

    if has_time:
        corr = longitude_correction_minutes(clock_dt.date(), longitude)
        solar_dt: Optional[datetime] = boundary_dt + timedelta(minutes=corr)
    else:
        corr, solar_dt = None, None

    anomaly = None
    for a_, b_ in dst_periods:
        if a_ - timedelta(hours=1) <= clock_dt < a_:
            anomaly = "skipped"; break
        if b_ - timedelta(hours=1) <= clock_dt < b_:
            anomaly = "ambiguous"; break

    flag_1954 = False
    a, b = FLAG_1954_WINDOW
    if a <= clock_dt.date() <= b and nearest_jieqi_dt is not None:
        flag_1954 = abs((boundary_dt - nearest_jieqi_dt).total_seconds()) <= FLAG_1954_TOLERANCE_MIN * 60

    return TimeContext(
        clock_dt=clock_dt,
        boundary_dt=boundary_dt,
        solar_dt=solar_dt,
        dst_applied=dst,
        longitude_correction_min=corr,
        flag_1954_window=flag_1954,
        dst_anomaly=anomaly,
    )
