# CHANGELOG — saju-engine 번들

> 배포 SPEC은 각 파일 본문에, 변경 이력·결정 근거는 본 파일에 둔다(prompt_refactor_plan v7.2 §0 — SPEC/PROVENANCE 분리).
> BUNDLE_README·emit_*.py docstring에서 외부화한 엔진 이력의 단일 보관처.

## 릴리스 핀 매핑 (트리플 → 릴리스 표시명)

v7.2 정비에서 `prompt_pin`을 **릴리스 표시명 단일 문자열**로 강등하고 엔진 버전 결합(`+engine…`)을 제거했다.
핸드셰이크 게이트는 **schema 버전**(`tier1.*`·`jieqi.*`·`saju.handoff.*` — 현행값은 아래 표 최상단 릴리스 행)이며, `prompt_pin`은 provenance·정보용이다.
`meta.engine_version`이 빌드 id를 별도로 운반한다.

| 릴리스 표시명 | 구 트리플 핀(폐기) | engine_version | schema |
|:---|:---|:---|:---|
| `saju-runtime-8.1.0` | (D-077 ASK7 SPOF — 결정론 handoff 어셈블러(P2 tier1 echo·P3 tier2 머지·P4 완전봉인+narrative 격리)·검증 게이트(P1 엔진대조·정적블록·legend 폐쇄)·원진(wonjin) legend 추가 — 신규 툴+프롬프트, **emit 거동 0**) | `0.2.12` | `tier1.v1.6` · `jieqi.v1.0` |
| `saju-runtime-8.0.0` | (D-076 ASK 모듈 리넘버 — 직렬화 7-1→7·보고서 7→8·이후 +1; 상태기계 N≥8·표 재배치·D4 호환가드 — 프롬프트+툴체인, 엔진 거동 0) | `0.2.12` | `tier1.v1.6` · `jieqi.v1.0` |
| `saju-runtime-7.9.0` | (D-075 §A6 지역 lookup — 출생지명→경도 결정론 변환·`--region` · `solar_dt`=지방평균태양시 라벨 정정 · 균시차 별도 보류) | `0.2.12` | `tier1.v1.6` · `jieqi.v1.0` |
| `saju-runtime-7.8.0` | (D-072 handoff.v3.7 — flow_signals 직렬화·legend 확충·relation_resolution_rule · D-073 ASK 2·3·4 체계성 정련 · D-074 종격 dead-branch 명문화 — 프롬프트+엔진주석·거동 0) | `0.2.11` | `tier1.v1.6` · `jieqi.v1.0` |
| `saju-runtime-7.7.0` | (F2 P0′ 호출 프로파일 · F4 DATA-ONFAIL anchor · 문서정합 corrigendum — 프롬프트-only) | `0.2.11` | `tier1.v1.6` · `jieqi.v1.0` |
| `saju-runtime-7.6.1` | (F3 — run_emit UTF-8 강제: 비-UTF8 로케일 stdout 크래시 차단) | `0.2.11` | `tier1.v1.6` · `jieqi.v1.0` |
| `saju-runtime-7.6.0` | (I7 — boundary_evidence: 경계 비대칭 신뢰도 노출) | `0.2.10` | `tier1.v1.6` · `jieqi.v1.0` |
| `saju-runtime-7.5.0` | (I8 — flow_signals: 운×원국 합충 탐지 결정론화) | `0.2.9` | `tier1.v1.5` · `jieqi.v1.0` |
| `saju-runtime-7.4.0` | (엔진 F1·F2 fail-loud/hygiene + 프롬프트 I4·I5 + R2 회귀 하네스) | `0.2.8` | `tier1.v1.4` · `jieqi.v1.0` |
| `saju-runtime-7.3.0` | (프롬프트-only — Refs/Modules: 신살 §⑩ 21종+십이신살) | `0.2.7` | `tier1.v1.4` · `jieqi.v1.0` |
| `saju-runtime-7.2.0` | (프롬프트-only 정련 — Modules: 원류·천극지충) | `0.2.7` | `tier1.v1.4` · `jieqi.v1.0` |
| `saju-runtime-7.1.0` | `core6.12/modules6.12/refs6.8` (tier1) | `0.2.7` | `tier1.v1.4` · `jieqi.v1.0` |
| `saju-runtime-7.0.0` | `core6.11/modules6.11/refs6.7` (tier1) · `core6.10/modules6.10/refs6.6` (jieqi, stale) | `0.2.6` | `tier1.v1.3` · `jieqi.v1.0` |

---

## 엔진 (engine_bundle)

### handoff.v3.8 (post-8.1.0 가산) — engine 0.2.12·prompt_pin 불변 (개운·건강 직렬화 + ASK 5→8 이관)
> **가산 범프 handoff.v3.7 → v3.8 (상위호환)**: ASK 5 §3-2(건강)·§4(개운)을 ASK 8 §6(현실 실행 가이드)로 이관하고,
> 결정론 lookup SoT를 `reference_tables.md` **§⑪**(개운·건강 오행 상관표)로 단일화. 하류(ASK 9·13)가 색·방위·시진·장부를
> 재산출하던 환각 표면(D3)을 handoff `derived_lookup.remedy_map`/`health_map`(오행 보편표 — 명식 무관 상수·새 판단 0)
> 직렬화로 차단. **emit(tier1/jieqi) 거동·`engine_version`(0.2.12)·`prompt_pin` 불변** — schema 가산이라 핸드셰이크
> 게이트만 `handoff.v3.8`. ASK 7 생산 버전 v3.8, 소비측(ASK 12 §3-0-1) 버전 관용에 v3.8 추가(v3.7 가산 상위호환: 기존 필드 불변).
- **assemble_handoff.py:** `remedy_map()`/`health_map()` 결정론 임베드(ref §⑪) + `validate` 5오행 폐쇄 검사. `SCHEMA` v3.8.
- **handoff_static.py** `STATIC_VERSION` v3.8(`gen_handoff_static` 재생성·드리프트 0 — 정적블록 내용 불변). `handoff_verify`·`run_emit --assemble` 주석 v3.8.
- **_golden_handoff** 3케이스 재생성(schema v3.8 + remedy/health 5오행·roundtrip 일치). `module_manifest`(ask_7.output 12) 재생성.
- **소비 와이어링:** ASK 9(물상 톤 — `remedy_map` 색·방위·소재)·ASK 13(시간대 가이드 `remedy_map` 시진 / 🧘 건강 `health_map` 장부).

### saju-runtime-8.1.0 — engine 0.2.12 유지 (D-077 ASK7 직렬화 SPOF 제거 — 결정론 handoff 어셈블러·검증)
> minor 범프(8.0.0→8.1.0): ASK 7이 handoff JSON 전체를 LLM 수동 직렬화하던 SPOF(오전사가 무증상으로
> SoT에 굳음)를 결정론 파이프라인으로 제거. **emit(tier1/jieqi) 거동·schema 3종 불변**(`tier1.v1.6`·
> `jieqi.v1.0`·`handoff.v3.7`)이라 `engine_version` 0.2.12 유지·핸드셰이크 게이트 무파급. golden 23 diff =
> `prompt_pin` 1값(8.0.0→8.1.0). 신규 툴은 emit 경로와 독립(opt-in: `--assemble engine_tier1/tier2_fragments`·`--verify`).
- **P1 검출 게이트:** `tools/handoff_verify.py` `verify_against_engine`(봉인 handoff ↔ 엔진 raw no-new-values 대조,
  지장간 역순·relations char·daewoon 운십성 derived 포함)·`validate_static_blocks`/`validate_legend_codes`(canonical 폐쇄).
  `tools/handoff_static.py`(legend/spec/consumer_scope/reasoning_scaffold canonical 미러)·`gen_handoff_static.py`(추출·--check 드리프트).
  `assemble_handoff.validate(h, raw_t1)` 통합 + `run_emit.py --assemble --verify`.
- **P2 tier1 echo:** `build_handoff_tier1`(엔진 raw → handoff tier1 결정론 생성, 검증기와 단일 스펙). dual-path `assemble(engine_tier1=…)`.
- **P3 tier2 머지:** `tools/handoff_merge.py` `merge_fragments`(ASK 2~6 조각 deep-merge·충돌 fail-loud). BLIND SLOT(branch_climate·current_*) 흡수·day_master 엔진 파생·조각 부재 시 폴백.
- **P4 완전 봉인:** `assemble`가 완전 handoff(정적블록 임베드+tier1+tier2+derived_lookup) 산출, narrative(tldr·usage_hint·methodology·limits)만 LLM 입력 격리. `gen_golden_handoff.py`+`tests/_golden_handoff/`.
- **수정:** 원진(wonjin) relation_type legend 누락 추가(엔진 emit·conftest 10종·§④-2-bis 정합; 원진 보유 ~40% 명식 거짓양성 거부 해소)·daewoon 운십성 검증 사각 폐쇄·yong_shen 부재 all-neutral fail-loud·프롬프트 정직성(코드불가 환경 결정론 검증 부재 명시).
- **회귀:** gen_golden 20(pin diff)·gen_manifest 7 위반0·gen_handoff_static/handoff 드리프트0·신규 스위트 67/67·기존 assemble 무영향. schema 3종 불변.

### saju-runtime-8.0.0 — engine 0.2.12 유지 (D-076 ASK 모듈 리넘버 — 직렬화 7-1→7·보고서 7→8·이후 +1)
> 빌드 범프 아님: 엔진 산출 로직·emit schema 불변(`tier1.v1.6`·`jieqi.v1.0`·`handoff.v3.7`)이라 `engine_version`은 `0.2.12` 유지. **major 범프(7.9.0→8.0.0)는 모듈 번호 체계가 바뀌는 사용자-가시 breaking change** 신호다(prompt_pin은 provenance — 핸드셰이크 게이트=schema 불변). 유효입력 4모드 emit diff = `prompt_pin` 1값(golden 20 라인 diff로 잠금).
- **D-076 (ASK 모듈 리넘버):** 직렬화(구 ASK 7-1)를 **신 ASK 7**로, 종합 보고서(구 ASK 7)를 **신 ASK 8**로 승격하고 이후 모듈(구 8~12 = 물상·기간·자유·궁합·오늘)을 **신 9~13**으로 +1. 의도 = "직렬화-우선 → 신8 보고서 및 신9~13이 handoff JSON 소비"를 번호 체계에 반영.
  - **ⓐ 상태기계(core §6):** CLOSING 결정트리에 `N==7`(직렬화 봉인) 케이스 신설 · MENU 임계 `N≥7→N≥8` · 강제봉인 가드 `N≥8`(봉인 N=7<8이라 무한봉인 없음) · next-step `N<8` · 구 내부 `N=20`→`N=7` 정규화. 종결성 재증명(전 N×게이트·무루프·무갭).
  - **ⓑ 표 재배치:** 파이프라인표·MENU_TEMPLATE에서 직렬화(신7) 행을 보고서(신8) **위로** reorder.
  - **ⓒ 3 프롬프트 + route:** core/ask/reference_tables 모듈번호·범위·소비모듈 라벨·consumer_scope route(월운 9→10·궁합 11→12)·§6-3·§7·REDIRECT MAP 전체 정합.
  - **ⓓ D4 호환가드:** `7-1` 입력 alias→신7 + 봉인 후 MENU 최초 1회 번호체계 오리엔테이션(구 번호 암기 사용자 오라우팅 방지).
  - **ⓔ toolchain:** `gen_manifest`(BUILD_RANK·build_order `ask_7_1→ask_7`)·`assemble_slice`·`test_assemble_slice` 정합 → `module_manifest.json` 재생성. 엔진 docstring(maehwa·month_hour·emit·assemble_handoff) ASK 번호 주석 동기(거동 0).
- **회귀:** gen_golden 20 일치(prompt_pin만 diff) · gen_manifest 위반0·드리프트0 · assemble_slice 7/7 · --assemble handoff.v3.7 위반0 · gen_tier2 변경0(캡처 4 known-pending). CRLF 보존(3 .md·골든·매니페스트). schema 3종 불변.

### saju-runtime-7.9.0 — engine 0.2.12 (D-075 §A6 지역 lookup — 출생지명→경도 결정론 변환 + `solar_dt` 지방평균태양시 라벨 정정)
> 빌드 범프: 신규 입력 경로(출생지명→경도)로 엔진 산출 로직 가산 → `engine_version` 0.2.11→0.2.12. emit schema 불변(`tier1.v1.6`·`jieqi.v1.0` — `birth_place`/`birth_longitude`는 기존 필드, 신규 출력 필드 0). `prompt_pin` 7.8.0→7.9.0.
- **D-075 (§A6 지역 lookup — 출생지명→경도 결정론 변환):** 출생지'명'을 경도로 바꾸는 결정론 lookup 부재(미완성 §A6 — 프롬프트는 "출생지가 있으면 경도 인자로 전달"하나 LLM 암산 금지 R2″라 채울 수 없던 격차)를 닫는다. ⓐ 신규 자산 `saju_engine/assets/region_longitude.py` — `KO_REGION_LONGITUDE`(광역 17 + 잔차 큰 8개 도/특별시 시·군·구 표본, **대표경도만** 저장)·`KO_REGION_ALIAS`·`HIGH_RESIDUAL_PROVINCES`·`resolve_region_longitude()`(미수록 fail-loud). 보정분 사전저장 금지 — `ROUND_HALF_UP((경도−135)×4)` 단일 반올림 지점은 `timecontext.longitude_correction_minutes` 불변(경계 이중 반올림 차단). ⓑ `run_emit.py` `--region "지역명"`(숫자 경도와 상호배타·동시 입력 fail-loud), `emit_tier1_standalone`가 `birth_place`+경도 미입력 시 resolve→경도(meta.`birth_longitude`에 실효경도 투명 전사). ⓒ **`solar_dt` 라벨 정정** — "진태양시"는 관용 표기이고 실제는 지방평균태양시(경도보정+DST, **균시차 미적용**)임을 `timecontext.py`·§A6·BUNDLE_README에 명시(값·골든 불변). 균시차(EoT) 보정은 별도 옵트인 필드(`apparent_solar_dt`, schema v1.7)로 분리 보류 — 본 릴리스 미포함.
- **데이터:** 독도 = 131.8692 → **−13분**(ROUND_HALF_UP 0.5 경계). 직교성 검증: UTC+8:30 법정시 구간은 보정 0(지역 무시 — 이중보정 금지), DST −1h와 합성, Condition B는 `solar_dt` None.
- **회귀:** 골든 20개(기존 18 + `region_dokdo`/`region_ulleung` 신규). 기존 18개는 region 미사용이라 **산출값 불변** — 본 릴리스 라인 diff = `engine_version`(0.2.11→0.2.12)·`prompt_pin`(7.8.0→7.9.0) 2값뿐. `gen_golden --check` 20 일치 · `gen_manifest --check` 위반 0·드리프트 없음 · `test_doc_version_coherence` 정합(3 .md 헤더·`BUNDLE_README`·CHANGELOG 최상단 행·emitter docstring) 정적 검증. ※ pytest 미가용 환경 — 결정론적 정적 검증 + 일반경로 명식 320·region 전 키 32 무오류로 잠금.
- **프롬프트:** `core_kernel`(엔진 호출 스펙 `--region` 가산·§A6 소비 주석·입력 안내)·`ask_modules` §3-3 일관화 — 산문 전용(stage-contract 펜스·헤더 불촉 → manifest/coherence 무영향).

### saju-runtime-7.8.0 — engine 0.2.11 유지 (D-072 handoff.v3.7 — 운 변동 변수 직렬화 + JSON 자립성 · D-073 ASK 2·3·4 체계성 정련 · D-074 종격 dead-branch 명문화 — 프롬프트+엔진주석, 거동·emit·골든 0)
> 빌드 범프 아님: 엔진 산출 로직·emit schema 불변(`tier1.v1.6`·`jieqi.v1.0`)이므로 `engine_version`은 `0.2.11` 유지. 본 릴리스는 **프롬프트 handoff schema 가산 범프(`handoff.v3.6 → v3.7`)** + 두 emitter·conftest `prompt_pin` 동기(7.7.0 → 7.8.0)다. 엔진 emit(tier1/jieqi)은 무변경 — **4모드 출력 diff = `prompt_pin` 1값**(tests/_golden 17개 라인 diff로 증명·잠금, 기존 필드·값 0변경).
- **D-072 (handoff.v3.7 — flow_signals 직렬화 + 운-평가 자립 인프라):** ASK 7-1 Handoff JSON이 엔진 산출 `tier1.flow_signals`(운×원국 합충 *탐지*, I8)를 직렬화하지 않고 `daewoon_table`을 naive 본기 십성으로만 축약하던 격차를 닫는다(갭=재계산 아닌 **전사 누락** → R2′상 추가 연산 0). ⓐ `tier1_facts.flow.flow_signals` 신설 — 8대운 **무부호 echo**(부호·旺衰·세력·해소 미부착 → §2-0-2 LLM 정성 SoT 비침범; FlowSignal 10필드 그대로). ⓑ legend 확충 `flow_status`(formed/half/hua/no_hua)·`flow_channel`·`position_tier`(★旺衰 아님)·`flow_signal_type`(stem_exposed; 나머지 type은 `relation_type` 재사용). ⓒ `spec.relation_resolution_rule`(會局>합/충 위계, 1차 세력비교=엔진 산출값 한정, 세력 비등→needs_recompute) + `reasoning_scaffold` 운-평가 6단계 + `consumer_scope` 운-해소 경계(`current_daewoon_luck_relations`/`luck_relation_resolution_when_contested`). ⓓ Block1 #7에 합충 변질(`transformed_element`) 평가 절차 + 블록3 검증 체크리스트 3항. 소비측 ASK 11 Mode P 버전 관용에 v3.7 가산(v3.6 상위호환). **무부호 전사 가드**가 운×원국 부호·세력 판정의 SoT 이원화를 차단(flow.py:6-12 철학 상속).
- **버전 동기:** 프롬프트 3파일 헤더·`core_kernel` 핸드셰이크 게이트(R0′)·legend/어휘 참조·`saju.handoff.*` 직렬화 고지·`BUNDLE_README`의 `handoff.v3.6 → v3.7` 일괄 범프(필드 도입-출처 `v3.x —` provenance 마커·`v3.6+` 기능 임계·tolerance 목록은 보존). emit schema(`tier1.v1.6`·`jieqi.v1.0`)·`engine_version`(`0.2.11`)은 불변.
- **회귀:** 골든 17개 라인 diff = `prompt_pin`(7.7.0→7.8.0) 1값뿐(git diff로 증명 — 비-pin diff 0, 엔진 emit 무영향). `test_doc_version_coherence` 정합 조건(3 .md 헤더 `tier1.v1.6`·`jieqi.v1.0`·`prompt_pin` / CHANGELOG 최상단 릴리스 행 / `BUNDLE_README` / emitter docstring stale 부재) 정적 검증. ※ `pytest` 최종 게이트는 Python 가용 빌드 환경에서 실행 권장(본 릴리스는 Python 미가용 환경에서 작성 — 골든·정합은 결정론적·정적 검증으로 잠금).
- **D-073 (프롬프트-only 정련 — ASK 2·3·4 체계성 보강, 4건):** SAMC-12 방법론(60인 실존 명조 역설계) 대비 ASK 1~6 파이프라인 체계성 검토에서 도출된 저비용·고정합 정련을 `ask_modules.md`에 반영. 엔진 산출·emit schema·골든 무영향(`tier1.v1.6`·`jieqi.v1.0`·`handoff.v3.7` 불변) — 신규 *출력 라벨/주석* 추가일 뿐 기존 판정 로직 불변.
  ⓐ **(ASK 2 §1) 형파해 강약 무반영 명문화** — 엔진 `khc_applied` 계수원이 육합·육충뿐(형·파·해=0, 삼합·방국은 구성 확인만)임을 §④-6 위계(형파해 = tier-4 보조·잔여 색채) 반영의 **의도된 설계**로 명시(침묵된 누락 오인 차단). 단 일지(日支)·통근 글자에 걸린 형·자형(自刑)의 뿌리 실효 의문은 §2-3 조습 효력 주석과 동형의 **점수 미반영 정성 주석**(`[형 효력 주석]`)으로 표기하고 §1-5 A7(e) 보류·ASK 4 §2-3으로 이관(Strength% raw 소급 변경 금지 — R2″·R6′ⓔ).
  ⓑ **(ASK 3 §4-2) '용신 후보 방향성' → '병증 방향성' 리네이밍 + 격리 가드** — 구조진단 단계(ASK 3)가 용신 오행을 선제 단정해 ASK 4를 앵커링하던 KERNEL [2] 미세 침범을 차단. 용신·희기신 오행 확정은 ASK 4 §4-1 전속, 본 단계는 병증의 *방향성*만 산출(특수격·극단조후 성립 시 무효).
  ⓒ **(ASK 4 §2-3) 확정 명식의 합충 괴리 라벨** — `boundary_hold=false` 경계 밖(ASK 2 `확정`)에서도 Step 1 합충 최종 성립이 강약 verdict를 반대 방향으로 명확히 이동시키면 `[합충 후 실효 강약: {실효} (raw={strength_pct}와 괴리 — {근거})]` 라벨을 의무화(SAMC §8 #4(c) '2패스 수렴' 보강의 최소형). raw 재계산·`verdict_center` 변경 금지 — 엔진 합충 사전반영 후 강약 동결(발산 방지)은 유지하되, 정량(raw)·정성(합충 성립) 괴리가 침묵하지 않게 라벨만 부착.
  ⓓ **(ASK 4 §4-1 계층2) 조후 우선순위 SoT 게이트** — ASK 2 §3 `[1차 우선순위]`는 잠정값, 최종 판정 권한은 ASK 4 계층2. 두 판정 충돌 시 `[조후 우선순위 보정: …]` 1줄 고지(1차값 무비판 승계 금지).
- **회귀(D-073):** `ask_modules.md` 단독 변경 — `core_kernel.md`·`reference_tables.md`·engine·`tests/_golden` 불변. `prompt_pin`·schema 불변이므로 `test_doc_version_coherence` 정합 무영향, 엔진 4모드 emit diff 0. 신규 라벨(`[형 효력 주석]`·`[합충 후 실효 강약]`·`[조후 우선순위 보정]`)은 조건부 출력이라 기존 골든·정상 경로 회귀 없음.
- **D-074 (종격 dead-branch 명문화 — 종격·형파해 이론 검증 후속, 거동 0):** 종격·형파해 두 쟁점을 고전(자평진전·적천수천미·삼명통회·궁통보감) + 적대 검증으로 심층 확인 → **두 처리 모두 정통** 판정. ⓐ 형파해 강약 무반영(D-073 ⓐ) = 任注 "刑之義無所取…總以論其生克"·沈본문(刑沖=격 成敗, 破害 불포함)으로 **변경 불요**. ⓑ 종격 역전·계산-후-역전·ASK4 위임 골격 = 적천수 "弱之極不可益"으로 정당. **유일 실측 발견**: `strength.py apply_a6`의 `neither∧strong` 종격검토 분기는 棄命 종격의 정통 트리거(極弱 low pct ∧ 無根 ∧ 無生扶)와 **부호가 반대로 오배선**돼 어느 종격에도 정합하지 않음(`test_neither_never_reaches_strong`이 '도달 불가' 박제). 엔진 재배선·`jonggyeok_review` emit 직렬화는 ROI상 보류(진종<5%·假從 다수·적천수 골든 회귀 대비 효용 미달, 거동 영향 0) → `apply_a6` + `test_characterization.py` 도크스트링에 '도달 불가·棄命 부호반대·의도적 미사용·종격 확정=ASK4 위임' 마커만 부착.
- **회귀(D-074):** `strength.py`·`test_characterization.py` **주석/도크스트링 단독** — 산출 로직·emit schema·`tests/_golden` 0변경. `prompt_pin`·`engine_version`(0.2.11)·schema 불변(`test_doc_version_coherence` 무영향). pytest 67 passed 유지.

### saju-runtime-7.7.0 — engine 0.2.11 유지 (F2 P0′ 호출 프로파일 · F4 DATA-ONFAIL anchor + 문서정합 corrigendum)
> 빌드 범프 아님: 엔진 산출 로직·schema 불변(`tier1.v1.6`·`jieqi.v1.0`·`handoff.v3.6`)이므로 `engine_version`은 `0.2.11` 유지. 본 릴리스는 프롬프트(core_kernel·ask_modules) 정련 + 문서 버전 정합 corrigendum + 두 emitter·conftest `prompt_pin` 동기(7.6.1 → 7.7.0)다. **4모드 출력 diff = `prompt_pin` 1값**(tests/_golden 17개 라인 diff로 증명·잠금 — 기존 필드·값 0변경).
- **D-069 (문서 버전 정합 corrigendum + 회귀 게이트):** 핸드셰이크 게이트 대조 RULE(`core_kernel.md`)이 schema를 `tier1.v1.4`로 들고 있어 헤더·엔진 emit(`tier1.v1.6`)과 2버전(7.5.0·7.6.0 가산 범프) 어긋난 드리프트를 정정. 부수로 `BUNDLE_README.md`(prompt_pin·engine·schema 3중 stale: 7.3.0·0.2.7·v1.4)·`emit_tier1_standalone.py` docstring(v1.3)·CHANGELOG 본문 예시값을 정리. **재발 차단:** `tests/test_doc_version_coherence.py` 신설 — '산출물이 아닌 문서'의 버전 문자열(.md 헤더·게이트 RULE·CHANGELOG 최상단 행·BUNDLE_README·emitter docstring)이 conftest `PIN`과 정합하는지 단언(중복 허용·값 불일치만 실패 — DRY 강요 아님; 프롬프트 .md 미동봉 배포 번들에선 graceful skip). 게이트 실증: `:74`에 v1.4 재주입 시 테스트가 즉시 적발.
- **D-070 (F2 — P0′를 R0′ 호출 프로파일로 정리):** `ask_modules.md` MODULE CONTRACT #4를 'R0′ 본체(ⓐⓑⓒⓓ) 재서술'에서 '**R0′(KERNEL [1′]) 단일 SoT를 모듈별 인자로 호출하는 프로파일**'로 재정의 — `subject`(self/counterpart)·`mode`(birth/divination)·`divination_at` 시그니처 명시(ASK 1=self·birth / ASK 11=counterpart·birth / ASK 12=self·divination). 채널 본체·우선순위 SoT는 R0′ 단일이며, 엔진 채널 호출형(run_emit.py 명령)만 자기완결로 보존(지연적재 robustness). 거동 무변경.
- **D-071 (F4 — ON_FAIL에 named anchor `DATA-ONFAIL` + `{subject}` 슬롯):** `core_kernel.md` ON_FAIL 본문이 라벨 없는 평문이라 ASK 11·12가 부르던 'ON_FAIL 친화 안내'의 지시 대상이 암묵적이던 약결합을 해소 — `DATA-ONFAIL` 명칭 + `{subject}`(본인/상대방/당일) 치환 슬롯 부여(안내 문구 유일 SoT = Core §1′). 하류 콜사이트(ASK 11 §3-2·ASK 12 §DELTA)는 `DATA-ONFAIL(subject=…)`로 명시 호출하되 '간지 추정 절대 금지'·'LLM 암산 폴백 절대 금지' 안전 1줄은 모듈에 보존(safety-critical redundancy). 거동 무변경.
- **회귀:** 전 4모드 골든 17개 라인 diff = `prompt_pin`(7.6.1→7.7.0) 1값뿐(gen_golden 재생성 + 비-pin diff 0 검증). `test_doc_version_coherence` 5건 + 기존 62건 통과. core_kernel·ask_modules 프롬프트 변경은 엔진 emit 무영향(4모드 산출 diff 무관).

### saju-runtime-7.6.1 — engine 0.2.11 (F3 — run_emit UTF-8 강제: stdout 이식성)
> 산출 로직·schema 불변(`tier1.v1.6`·`jieqi.v1.0`·`handoff.v3.6`). 본 릴리스는 `run_emit.py` CLI 래퍼 변경 + 두 emitter `prompt_pin` 동기뿐 — **유효입력 4모드 출력 diff = `engine_version`·`prompt_pin` 2메타값**(build_*_dict 산출 무변경, 골든 라인 diff로 증명·잠금).
- **D-068 (F3 — 비-UTF8 로케일 stdout 크래시 차단):** `run_emit.py`에 `_force_utf8_io()` 신설 — CLI 진입(`__main__`) 시 `sys.stdout`·`sys.stderr`를 `reconfigure(encoding="utf-8")`. 비-UTF8 로케일(Windows cp949 등)에서 출력의 `—`(em-dash, U+2014 — note/basis 필드의 cp949 미수록 문자)를 인코딩하다 `UnicodeEncodeError`로 `--divination`·`--jieqi`·표준 모드가 크래시하던 것을 차단(`PYTHONUTF8` 환경변수 불요). Code Interpreter(Linux/UTF-8)에선 no-op이므로 배포 런타임 거동 불변. import 경로는 stdout 변형 없음(CLI 한정).
- **회귀:** `test_f3_non_utf8_locale_no_crash` — `PYTHONIOENCODING=cp949`(PYTHONUTF8 제거) env로 3모드(`--jieqi`·`--divination`·표준)가 exit 0 + 펜스 시작 + `UnicodeEncodeError` 부재를 잠금(em-dash가 cp949 미수록이라 수정 전엔 크래시하던 케이스). 종전 xfail 추적 F3 → 양성 회귀 테스트로 승격.

### saju-runtime-7.6.0 — engine 0.2.10 (I7 — boundary_evidence: 경계 비대칭 신뢰도)
> schema 가산 범프(`tier1.v1.5 → v1.6`): `strength.boundary_evidence` 신설. **≤v1.5 필드·값 불변**(회귀 잠금 — 골든 라인 diff = 3메타 + candidates 닫는 `]`→`],` 콤마(형제 키 추가) + `boundary_evidence` 블록 가산뿐, 기존 *값* 0변경). `jieqi.v1.0`·`handoff.v3.6` 불변.
- **D-067 (I7 — 경계 비대칭 신뢰도):** `strength.py` `StrengthResult`에 `boundary_evidence` dict 가산 — `compute_strength_core`가 **이미 계산한** 값의 **read-only echo**(신규 산술·판단 0): `{raw_pct, raw_verdict(A6 이전), a6_shift_levels(A6 이동 칸수), dist_to_strong=pct−65, dist_to_weak=pct−35, nearer_boundary, in_p, bi_p, resource_ratio(인성/비겁), ratio_to_d_gate, ratio_to_dfuzzy_gate, d_fuzzy_residual}`. 목적: 강·약 가지를 **대칭 병기**하던 boundary가 "raw 증거가 실제로 어느 가지에 더 가까운지"를 노출(예: pct 29.4가 A6로 balanced 운용되나 `dist_to_weak≈0`·`a6_shift=+1` → 弱쪽 비대칭 = Feedback #1 군겁쟁재 케이스의 취약성).
  - **소비측(프롬프트):** Core §7 CORE_PROFILE `boundary` 객체 + ASK 7-1 handoff에 `confidence_asymmetry` 정규 필드 추가(boundary_evidence 전사). ⛔ **가드** — ⓐ **operative_branch 라우팅 비-무효화**(강/약 가지 *선택*은 activation_key=현재 대운이 결정, 비대칭은 정적 증거 신호일 뿐 — 충돌 시 operative_branch 우선) ⓑ **verdict 불변**(verdict_center·boundary_hold·triggers(d) 안 뒤집음, d=2.5 하드 게이트 불변, R2″·R6′ 연장) ⓒ **고부담 노출 의무**(채무·투자·건강 + boundary_hold=true → 비대칭 필수 노출). 사용자향은 operative_branch 단일 렌더, 비대칭은 검산·1줄 병기(양다리 hedge 금지).
  - **회귀:** tests 가산 — 불변식(640명식 × A·B에서 echo 항등식 잠금: `raw_pct==strength_pct`·`dist_to_weak==pct−35`·`a6_shift 정합·d_fuzzy_residual echo` → '새 판단 0' 증명) + 특성화(xing_only_a6의 raw=quasi_weak·a6_shift=+1·nearer=weak 비대칭 노출 + 순수 echo 검증). 4모드 diff: 전 tier1 모드에 boundary_evidence 가산 / --jieqi 무관.

### saju-runtime-7.5.0 — engine 0.2.9 (I8 — flow_signals: 운×원국 합충 탐지 결정론화)
> schema 가산 범프(`tier1.v1.4 → v1.5`): `flow_signals` 신설. **≤v1.4 필드·타입·코드 불변**(회귀 잠금 — tests/_golden 17개 라인 diff = `schema_version`·`engine_version`·`prompt_pin` 3메타 + `flow_signals` 블록 가산뿐, 기존 필드 0변경 증명). `jieqi.v1.0`·`handoff.v3.6` 불변.
- **D-066 (I8 — flow_signals):** 신규 `saju_engine/engine/flow.py` — 운(대운·세운) 간지 × 원국의 합·충·형·파·해·암합·삼합/방국(會局)·천간합/透出 **탐지(이진 성립 + status + 화기 투출 + 근접성 tier)**를 결정론 산출. `daily.py`(외부 간지×원국) 패턴의 동형 확장 — relations_tables lookup 재사용, detect_relations 비재사용(운 1글자쌍 스코프).
  - **경계(검토 I8 guardrail 반영):** ① **旺衰·STAGE2 작용형(去/發/動)·강도 미산출** — 대운 '사령월'은 구간 추상이라 운 글자 旺衰가 ill-defined(#2·#6) → 세력·발동은 §2-0-2 LLM. ② **STAGE1 해소(會局 흡수·탐합망충·파합·충중봉합) 비실행** — 그 resolution은 ask_modules §2-0-2가 소유(운×원국 SoT) → 엔진 이원화 방지(#3). 엔진은 *탐지 사실*만, 프롬프트가 우세를 가린다. ③ **부호(吉/凶) 미산출** — target_element만(daily.py:5 동일). ④ **원진·천간극 비탐지** — 신살 tier(ASK6 §2-8)·§① 프롬프트(daily.py와 동일 일관).
  - **방출:** `flow_signals.daewoon[]`(8 대운 전체·상시·인물 결정론) + `flow_signals.seyun`(`--divination` 명리 연도, 입춘 보정). 각 entry = `{ganji, age, start_year, signal_count, signals[]}`, signal = `{channel, type, luck_char, target_position, target_char, target_element, transformed_element, status, position_tier, note}`.
  - **소비측 동시 개정(#4):** KERNEL [1′] R4′ + ASK 6 §2-0 워크시트 개정 — 대운·세운 합충 *탐지*를 `flow_signals` 전사로 대체(LLM 수기 typed 스캔 폐기 = 환각 표면 차단), R2′ 검산 정합으로 승격. 세력·해소·부호는 §2-0-1·§2-4·§2-0-2 LLM 정성 유지. flow 미수록(월운·기타 분석연도 세운·천간극·원진)만 수기 §④ lookup 폴백.
  - **회귀:** tests 가산 — 불변식(640명식 × A·B에서 flow_signals 구조·열거·범위 검증) + 특성화(寅午 반합火국·午午 자형·丙辛 不化 교차검증 + 세운 divination 한정 + 원진/천간충 미탐지). 4모드 diff: 표준/--no-time = 메타 3값 + flow_signals.daewoon 가산(seyun=null) / --divination = 위 + seyun 가산 / --jieqi 무관.

### saju-runtime-7.4.0 — engine 0.2.8 (F1·F2 fail-loud/hygiene + R2 하네스 + R1 프롬프트 I4·I5)
> engine 범프(0.2.7→0.2.8): F2가 `run_emit` tier1 fail 경로 거동을 바꾼다(D-056과 동일 change-class). **유효입력 4모드 출력 diff = `engine_version`·`prompt_pin` 2값뿐**(tests/_golden 17개 라인 diff로 증명·잠금). schema(`tier1.v1.4`·`jieqi.v1.0`·`handoff.v3.6`) 불변 — 핸드셰이크 게이트 무영향.
- **D-062 (F1 — solar_terms.py stdlib-only 계약 복구):** `saju_engine/assets/solar_terms.py` 최상위 `import openpyxl`를 `load_solar_terms()` 내부(xlsx 검증 경로 전용)로 지연. 기본 emit(`xlsx_path=None`)은 BASE_ROWS 스냅샷만 쓰므로 산출 무변경 + 순수 stdlib import 가능(emit_tier1_standalone docstring의 'stdlib + korean_lunar_calendar만' 계약 준수). Code Interpreter엔 openpyxl이 상주해 잠복하던 결함.
- **D-063 (F2 — run_emit tier1 입력검증 fail-loud):** tier1 분기가 `LookupError`만 포착해 경도 범위밖(`timecontext.longitude_correction_minutes`)·잘못된 성별(`daewoon_age.daewoon_direction`)의 `ValueError`가 traceback째 누출되던 것을, 입력 파싱 guard(생일·경도·divination) + `except ValueError`로 1줄 한국어 안내 종료(KERNEL ON_FAIL ⓔ). `--jieqi`(이미 `(LookupError, ValueError, IndexError)` 처리)와 동일 패턴. `solar_terms.py:84` 빌드무결성 `ValueError`는 xlsx 경로 전용이라 본 흐름(`xlsx_path=None`) 미도달 — loud 유지.
- **R2 회귀 하네스 신설:** `tests/`(pytest — 골든17·불변식640명식·특성화·발견추적, `gen_golden.py`·`discover_edges.py`·README). 본 릴리스부터 4모드 diff가 `tests/_golden`로 자동 잠금된다. _발견_: F1·F2(본 릴리스 수정), F3(비-UTF8 Windows stdout 크래시 — README Known portability).
- **R1 프롬프트(I4·I5 — 결정론/LLM자율성 균형, 엔진 산출 무관):**
  - **D-064 (I4 — 합충 우세: 고정 위계 → default + 명식별 LLM 판단):** `core_kernel.md` KERNEL[4] + `reference_tables.md` §④-6 + `ask_modules.md` §2-0-2에 〔I4〕 프레이밍 추가 — "삼합>육합>육충+근접성"은 **동시 발생 시 기본값(default)**이며, 세력 비등·역전 경계의 우세 resolution(운×원국)은 엔진 공급 무부호 사실(존재·삼합 등급·근접성) 위에서 **LLM이 명식별 정성 판정**(single verdict — 양다리 hedge 금지). 가드: 원국 내부 해소는 엔진 `relations[]` 결정론 소유(불변), LLM 정성은 운×원국 §2-0-2 한정. default 순서는 회귀 앵커로 잔존(삭제 0). 엔진/스키마 무변경.
  - **D-065 (I5 — 청탁·진가: 산술합산 오해 차단 + 행동 귀결 강제):** `ask_modules.md` §5-2에 〔I5〕 2건 — ① 탁源·淸源 체크리스트는 **산술 합산이 아니라 holistic 정성 우세 비교**(gestalt 경계면 5단계 승급으로 불확실성 노출, 입력 사실 ⓐ~ⓔ는 §2-4·§5-1·`relations[]` 결정론 전사·재계산 0) ② `[청탁]` 출력에 **등급의 행동 귀결 1줄 강제**(회피 답변 차단, 假神/濁은 운-민감 baseline 명시). §⑦-00-G의 '비인용 해석 보조' 선언 유지 — 엔진 미침범. 엔진/스키마 무변경.

### saju-runtime-7.3.0 — engine 0.2.7 유지 (신살 §⑩ 추가)
> 빌드 범프 아님: 엔진 산출 로직 불변이므로 `engine_version`은 `0.2.7` 유지. 본 릴리스는 프롬프트(reference_tables §⑩ 신설 + core_kernel REDIRECT + ASK 10 게이트) + 두 emitter `prompt_pin` 동기(saju-runtime-7.2.0 → 7.3.0)다.
- **D-061 (신살 §⑩ 통합):** reference_tables.md §⑩ 신설 — 21종(천을·공망·도화·역마·양인·화개·괴강·백호·원진·건록·귀문·장성·천덕월덕·문창·고신과숙·홍염·겁살·천라지망·현침·금여·암록) + 십이신살 12종 매트릭스. DET(anchor·lookup) = §④류 tier2 lookup / INTERP(용신·기신 극성) = 2차 보정. ⛔ 공망만 엔진 `void_branches` 전사. 관계신살(원진·귀문·고신과숙) 경향성 가드.
- **소비**: core_kernel REDIRECT MAP §⑩ 행 + ASK 10 `[신살 참조 레이어]` 게이트(트리거: 사용자 명시 OR 고민 직결 — 남용 차단) + ASK 6 §2-8 cross-ref. handoff `relations_sin_sal_nuance`(기존) 활용 — 직렬화 슬롯 불요.
- **산출 로직·schema 무변경**: `tier1.v1.4`·`jieqi.v1.0`·`handoff.v3.6` 불변. needs_curation(천을 庚·양인 음인설·괴강 6설·홍염 乙·천라지망·현침)은 채택값 고정 + 큐레이션 트랙. 4모드 출력 diff = `prompt_pin` 1값(7.2.0 → 7.3.0).

### saju-runtime-7.2.0 — engine 0.2.7 유지 (프롬프트 정련: 원류·천극지충)
> 빌드 범프 아님: 엔진 산출 로직 불변이므로 `engine_version`은 `0.2.7` 유지. 본 릴리스는 프롬프트(ask_modules.md) 정련 + 두 emitter `prompt_pin` 동기(saju-runtime-7.1.0 → 7.2.0)다.
- **D-059 (원류 源流 추적):** ASK 2 §2-4에 원두(司令)→유향(§① 상생)→종착/정체 진단 + §4 `[원류]` 태그 + ASK 4 §5-2 원류 정합 overlay(源頭 喜→順流 보호 / 忌→引化 용신) + 탁源 ⓐ 위치 구체화. 전부 부착형(재계산 0·검산 echo 비대상).
- **D-060 (천극지충·천합지합 복합):** ASK 6 §2-0 천간 쌍 dispatch에 §① 천간극 추가 + §2-0-3 신설(POST-SCAN JOIN: 同 운기둥×원국기둥 〔천극+지충〕→천극지충 / 〔천합+지합〕→双合, 길흉은 `[원류]`·용신 대조, 혼합 valence는 §2-0-2 라우팅) + §2-5 입력 + §4 `[운 복합작용]` 태그.
- **산출 로직·schema 무변경**: `tier1.v1.4`·`jieqi.v1.0`·`handoff.v3.6` 불변(핸드셰이크 게이트 무영향). 4모드(표준/--no-time/--divination/--jieqi) 출력 diff = `prompt_pin` 1값(saju-runtime-7.1.0 → 7.2.0). 회귀 잠금.

### v0.2.7 (D-057 — divination.daily_signals 가산; §⑨-3-bis v2 엔진 이관; Core 6.12/Modules 6.12/Refs 6.8 동기)
- `divination` 블록에 `daily_signals[]`·`daily_signals_voided[]`·`daily_signals_meta` 3필드 가산(신규 `engine/daily.py`). 일진×원국 작용 탐지 + STAGE 1 상호해소(會局·탐합망충·합처봉충·충중봉합) + STAGE 2 작용형(去/發/動/擦/透)·旺衰·강도까지 엔진 산출. 부호(吉/凶/중립)는 용신 의존(tier2) → 미산출, target_element만 방출(프롬프트 element_favorability lookup). relations_tables lookup 재사용(detect_relations 전체 재사용 금지 — 일진 1글자 스코프).
- 旺衰: 대상=12운성 band(STAGE_GROUP) 환산, 일진=점단월 사령 旺相休囚死. 점단월 절기 커버리지 밖이면 iljin_wangshui=null·작용형 clash_even 강등(divination 전체 fail 안 함 — day_ganji·maehwa는 절기 무관 유지).
- schema tier1.v1.3 → **tier1.v1.4**(가산 전용). ≤v1.3 필드·타입·코드체계 불변(회귀 잠금). prompt_pin saju-runtime-7.0.0 → 7.1.0.
- 회귀 잠금(4모드 diff): 표준/--no-time = schema_version·engine_version·prompt_pin 메타 3값만(divination=null 불변); --divination = 위 3값 + daily_signals 3필드 가산; --jieqi 무관(jieqi.v1.0 불변).
- 검증: 삼합 반합/완성·방국·육합(化)·암합·형파해·천간합/透出 탐지, S1~S4 해소(會局은 S3 비대상 — 견고), 旺者沖衰/衰者沖旺/動 충 분류, 조건 B(시주 None) divination, JSON 유효성 PASS.
- 알려진 단순화(문서화): ① 會局 왕지 피충 시 약화는 §④ 위임 ② combine_6 화기 판정은 투출만(월령 화기 §④-4 위임) ③ 원진은 신살 tier(ASK6 §2-8)라 비대상 ④ S2 예외(旺 대상 충 弱발동)는 기신 판정을 프롬프트로 위임 — tier1/tier2 경계의 의도된 잔여.

### saju-runtime-7.0.0 정합 — engine 0.2.6 유지 (v7.2: EU-05 · EU-06)
> 빌드 범프 아님: 산출 로직 불변이므로 `engine_version`은 `0.2.6` 유지. 본 정비는 런타임 릴리스 `saju-runtime-7.0.0` 정합 + 번들 정비다(Phase 9 — engine_version 0.2.6 별도 기록).
- **EU-05 (Phase 2 — 핀·버전 정합):** `prompt_pin`을 릴리스 표시명 `saju-runtime-7.0.0`로 정합(엔진 버전 결합 제거).
  jieqi emitter의 stale `engine_version 0.2.5 → 0.2.6` · 핀 `core6.10/modules6.10/refs6.6` 제거. 두 emitter `prompt_pin`·`engine_version` 일치.
  `schema_version`(tier1.v1.3·jieqi.v1.0) 불변(I3). **산출 로직 무변경** — 표준/--no-time/--divination/--jieqi 4모드 출력 diff = 메타값(`prompt_pin`·`engine_version`)뿐, fail-loud 경로 불변.
- **EU-06 (Phase 3 — 번들 정비):** `BUNDLE_README.md`·`emit_*.py` 모듈 docstring의 v0.2.x changelog·`D-0XX` 잔존을 본 파일로 외부화 —
  README는 목적·설치/실행·입력·출력 schema·커버리지·fail-loud·예시만, emit docstring은 실행 설명 + load-bearing 설계/소비 계약만 잔존(emit_jieqi의 S8·소비 규율·R2″ 불변 주석 보존).
  code-hygiene 1건: `constants.py`의 `KOREA_LONGITUDE_RANGE` 중복 정의(동일 값 재할당) 1줄 삭제 — 거동 동일(timecontext.py 단일 소비, 4모드 출력 diff 0).
  코드 로직·schema·fail-loud 분기·`kasi_cross` 토큰 의미 불변.

### v0.2.6 (D-056 — tier1 경로 fail-loud 친화화; Core 6.11/Modules 6.11/Refs 6.7 동기)
- `run_emit.py` tier1 분기를 try/except(LookupError)로 감싸 `--jieqi`와 동일한 1줄 한국어 fail 메시지로 종료(traceback 노출 제거 — KERNEL ON_FAIL ⓔ 소비 전제, Core §10 신설 행과 결속).
- `prompt_pin core6.10/... → core6.11/modules6.11/refs6.7`. 산출 로직·schema(tier1.v1.3·jieqi.v1.0) 불변 — 회귀 잠금: 4조합 출력 diff = engine_version·prompt_pin 2값 + 실패 경로 메시지 형식.

### v0.2.5 (D-055 — 런타임 절기 SoT 단일화; Core 6.10/Modules 6.10/Refs 6.6 동기)
- `--jieqi YYYY` 단독 모드 신설(`tools/emit_jieqi.py` — 인물 무관 연 스코프, schema **jieqi.v1.0** 신규 패밀리·가산). 절기·연간·월간지 전부 원국 경로 함수 재사용(산식 복제 0 — S8). 절기 xlsx 은퇴 전제: Core §A2/§A3/§9·ASK 9 ③의 xlsx 경로를 본 emit으로 대체.
- tier1_facts 산출·schema tier1.v1.3 불변(변경 = engine_version 1값). 검증: 프롬프트 표 8개 연도 월간지 96셀 + HH:MM 7셀 전수 일치, 1952~2035 60갑자 사슬 무단절, 1951/2035 엣지·1950/2036 fail-loud PASS.
- 발견: 03 확장표 2030 망종 셀 23:44 vs ext 자산 23:45(1분 차) — 운영자 결정으로 프롬프트 표 HH:MM 셀 전면 철거(Refs 6.6·Core §9), 절입 HH:MM 유일 SoT = jieqi_facts.

### v0.2.4 (D-054 — kasi_cross 표명 정정 corrigendum; Core 6.9/Modules 6.9 동기)
- `derivation.day_pillar_kasi_cross` 고정값 `"unchecked"` → 검증창 산출 상태(`"verified_full_1900_2050"` | `"out_of_verified_window"`, 판정일 = 일주 귀속일 effective_date). KERNEL [1′] R3′ "빌드 타임 완료·동봉" 서술과 정합. 토큰 SoT = `engine/day_pillar.py`.
- `divination.day_ganji_kasi_cross` 가산(당일 날짜 자체의 검증창 판정 — ASK 12 [STEP 2] echo 정합).
- schema tier1.v1.2 → **tier1.v1.3**. ≤v1.2 필드·타입·코드체계 불변(값 변경은 ① 1필드, 전사 전용). 회귀 잠금 정밀화: 잠금 대상 = 필드 존재·타입·열거 코드체계. 상태(status) 성격 필드 값은 corrigendum 경로로 정정(schema 마이너 범프 + changelog 1줄 + grep 분기 소비자 부재 확인 의무).

### v0.2.3 (D-053 — R0′ 채널 표기 정합; Core 6.8/Modules 6.8 동기)
- 산출 로직·schema tier1.v1.2 불변 — 변경 = engine_version·prompt_pin 2값. 'R0′ ③채널' 표기 → '엔진 채널'(서수 참조 폐지). ≤v1.1 필드·값 불변(회귀 잠금).

### v0.2.2 (D-052 — 검산 echo 폐쇄; Core 6.7/Modules 6.7 동기)
- schema tier1.v1.1 → **tier1.v1.2** 가산 전용: `daewoon.interval_days` · `strength.roots[]`(position·slot·stem·kind·base·adj)/`khc_applied`{coefficient·basis} · maehwa 검산수(year_n·sum_umd·sum_umdh·upper_n·lower_n) + is_intercalation · ti/yong_trigram 동봉.
- ≤v1.1 필드·값 불변(회귀 잠금).

### v0.2.1 (P0)
- 절기 커버리지 1951~2035(extended 로더) · 1954 플래그 가드 · divination 블록(당일 일진·오서둔 12시진 — ASK 12용) 신설. schema tier1.v1.0 → **tier1.v1.1** 가산 전용(meta.jieqi_coverage + divination 블록). `__pycache__` 미동봉.
