"""end-to-end handoff 골든 생성기 (P4 — 완전 결정론 assemble 회귀 잠금).

고정 입력(엔진 raw[corpus] + 고정 ASK 2~6 조각 + 고정 narrative)으로 assemble() 전체
산출을 동결한다 → 결정론 어셈블러 로직(생성·머지·임베드·narrative 격리) 회귀 차단.
정적 블록(legend/spec/consumer_scope/reasoning_scaffold)은 handoff_static 드리프트가
별도로 잠그므로 골든에선 스트립(경량 + handoff_static 변경과 디커플링).

  재생성:  PYTHONUTF8=1 PYTHONPATH=. py tools/gen_golden_handoff.py
  드리프트: PYTHONUTF8=1 PYTHONPATH=. py tools/gen_golden_handoff.py --check  (재생성 0·exit1 if drift)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parent.parent
GOLDEN_DIR = ENGINE_ROOT / "tests" / "_golden_handoff"
GOLDEN_CASES = ("samhap_full", "condB_samhap", "lichun_after")   # 조건 A/B · 강/약 · 입춘 엣지
_STATIC_KEYS = ("legend", "spec", "consumer_scope", "reasoning_scaffold")

# 고정 ASK 2~6 stage_output 조각(STAGE CONTRACT output 경로 모사 — non-boundary 명식용).
FIXED_FRAGMENTS = [
    {"tier1_facts": {"chart": {"branch_climate": {
        "year": {"temp": "neutral_t", "humid": "neutral_h"},
        "month": {"temp": "warm", "humid": "dry"},
        "day": {"temp": "neutral_t", "humid": "damp"},
        "hour": {"temp": "cool", "humid": "neutral_h"}}}},
     "tier2_interpretation": {"strength": {"root_notes": "통근 요약"}}},
    {"tier2_interpretation": {"energy_map": {
        "active_shins": ["jae"], "dormant_shins": ["in"], "ten_gods": {},
        "twelve_stages": {}, "role_notes": "역할 요약"}}},
    {"tier2_interpretation": {
        "pattern": {"code": "jong_gyeok", "validity": "true"},
        "yong_shen": {"element": "wood", "ten_god": "in"},
        "hee_shen": {"element": "water", "ten_god": "bi_geop"},
        "gi_shin": {"element": "metal", "ten_god": "gwan"},
        "gu_shin": {"element": "earth", "ten_god": "jae"},
        "disease": ["weak_self"],
        "clarity": {"mode": "single", "single": {"grade": "pure", "sources": []}}}},
    {"tier2_interpretation": {"yong_mechanism": ["suppress"]}},
    {"tier1_facts": {"flow": {
        "current_daewoon": "庚子",
        "current_se_woon": {"year": 2026, "ganji": "丙午", "summary": "삼중 역동성"}}}},
]
FIXED_NARRATIVE = {
    "tldr": "원국 강약·격국·용신·현재 흐름 요약(2~3문장).",
    "methodology": {"school": "자평명리(子平命理)", "ruleset": "Core Kernel",
                    "ruleset_version": None, "scope_note": "tier2_interpretation은 본 ruleset 하에서만 유효."},
    "limits": None,
    "usage_hints": {"yong_shen": "목 보강 운에 길", "gi_shin": "금 운 주의"},
}


def build_golden_handoff(label: str) -> dict:
    from tools.assemble_handoff import assemble
    from tests.corpus import build_case, TIER1_CASES
    raw = build_case(next(c for c in TIER1_CASES if c.label == label))
    return assemble({"engine_tier1": raw, "tier2_fragments": FIXED_FRAGMENTS, "narrative": FIXED_NARRATIVE})


def strip_static(h: dict) -> dict:
    """정적 블록은 handoff_static이 잠그므로 골든에서 None으로 스트립(경량·디커플링)."""
    return {k: (None if k in _STATIC_KEYS else v) for k, v in h.items()}


def _norm(s: str) -> str:
    return s.replace("\r\n", "\n").strip()


def main(argv) -> int:
    check = "--check" in argv
    drift = []
    if not check:
        GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    for label in GOLDEN_CASES:
        text = json.dumps(strip_static(build_golden_handoff(label)), ensure_ascii=False, indent=2)
        path = GOLDEN_DIR / f"{label}.json"
        if check:
            cur = path.read_text(encoding="utf-8") if path.exists() else ""
            if _norm(cur) != _norm(text):
                drift.append(label)
        else:
            path.write_text(text, encoding="utf-8", newline="\r\n")
    if check:
        if drift:
            print(f"[gen_golden_handoff --check] 드리프트 {len(drift)}건: {drift} — 재생성 필요")
            return 1
        print(f"[gen_golden_handoff --check] {len(GOLDEN_CASES)}케이스 정합 (드리프트 0)")
        return 0
    print(f"[gen_golden_handoff] {len(GOLDEN_CASES)}케이스 재생성 → {GOLDEN_DIR.name}/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
