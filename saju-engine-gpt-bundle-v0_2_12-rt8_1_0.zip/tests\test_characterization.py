"""특성화(characterization) — '엔진이 지금 이렇게 동작한다'를 명문 박제.

개선방향 검토와 직결: 여기 핀된 동작들(특히 A6 승격)은 Phase C(I2)에서
*의도적으로* 바뀔 대상이다. 변경 시 본 테스트가 빨개지는 것이 곧
"해석 결정을 건드렸다"는 변경 마커가 된다(조용한 드리프트 차단).
"""
from __future__ import annotations

from datetime import datetime

import pytest

from tests.corpus import Tier1Case, build_case, TIER1_CASES
from tools.emit_tier1_standalone import build_tier1_dict
from saju_engine.engine.strength import verdict_at

CASE = {c.label: c for c in TIER1_CASES}


def test_a6_xing_only_promotes_to_balanced():
    """★I2 핀: xing_only(不透通根) 명식의 raw verdict는 quasi_weak인데
    A6 매트릭스가 balanced로 '보수측 中和' 승격한다(D-035).
    Phase C에서 이 승격을 a6_suggestion 사실필드로 분리하면 본 테스트를 갱신한다."""
    d = build_case(CASE["xing_only_a6"])
    s = d["strength"]
    assert s["qi_xing"] == "xing_only"
    raw = verdict_at(s["strength_pct"])           # A6 적용 전 raw 판정
    assert raw in ("weak", "quasi_weak"), f"raw={raw} (pct={s['strength_pct']})"
    assert s["a6_applied"] is True
    assert s["verdict_center"] == "balanced"      # ← 승격 결과(현행)
    assert s["boundary_hold"] is True


def test_year_branch_cap_40_engaged():
    """년지 뿌리 adj 합이 40 초과여도 deuk_ji 기여는 40에서 캡(C-005 해석 고정)."""
    d = build_case(CASE["xing_only_a6"])
    year_adj = sum(r["adj"] for r in d["strength"]["roots"] if r["position"] == "year")
    assert year_adj > 40.0, f"년지캡 경로 미발동(year_adj={year_adj})"


def test_neither_never_reaches_strong():
    """qi_xing=neither는 구조적으로 낮은 pct를 강제 → strong/quasi_strong 도달 불가.
    즉 apply_a6의 'neither & strong → balanced+jonggyeok_review' 분기는 사실상 죽은 코드.
    (실측: 30,650일 중 neither 최대 pct 43.9). 향후 엔진 변경이 이를 깨면 알림.
    [D-074 마커] 본 분기는 棄命 종격(極弱 트리거)과 부호가 반대로 오배선된 '의도적 미사용' 분기다.
    재배선이 아니라 '도달 불가'를 박제하는 것이 본 테스트의 목적(종격 확정=ASK4 위임). 이론 근거:
    적천수 '弱之極不可益'·자평진전 '身無氣日主無根' → 종격 트리거 = 極弱∧無根∧無生扶."""
    neither = 0
    offenders = []
    dt, end = datetime(1955, 1, 5, 9, 30), datetime(2030, 1, 1)
    from datetime import timedelta
    step = timedelta(days=5)
    while dt < end:
        d = build_tier1_dict(dt, has_time=True, gender="M")
        s = d["strength"]
        if s["qi_xing"] == "neither":
            neither += 1
            if s["verdict_center"] in ("strong", "quasi_strong"):
                offenders.append((dt.isoformat(), s["strength_pct"], s["verdict_center"]))
        dt += step
    assert neither > 0, "표본에 neither 명식이 없음 — 테스트가 공허(그리드 재검토)"
    assert not offenders, f"neither가 strong 도달(죽은코드 가정 깨짐): {offenders[:5]}"


def test_lichun_boundary_flips_year_pillar():
    """입춘 1일 전후로 명리학적 년주가 전환된다."""
    before = build_case(CASE["lichun_before"])
    after = build_case(CASE["lichun_after"])
    assert before["derivation"]["effective_year"] == 1999
    assert after["derivation"]["effective_year"] == 2000
    assert before["chart"]["year"]["stem"] + before["chart"]["year"]["branch"] == "己卯"
    assert after["chart"]["year"]["stem"] + after["chart"]["year"]["branch"] == "庚辰"


def test_dst_window_shifts_boundary_back_one_hour():
    """서머타임 구간 출생은 boundary_dt가 −1h 보정된다(08:30 → 07:30)."""
    d = build_case(CASE["dst_window"])
    tc = d["time_context"]
    assert tc["dst_applied"] is True
    assert tc["boundary_dt"].endswith("07:30:00")


def test_utc830_1954_zero_longitude_correction():
    """1954 UTC+8:30 표준시 구간은 경도보정 0분(인접 1953은 −30)."""
    d = build_case(CASE["utc830_1954"])
    assert d["time_context"]["longitude_correction_min"] == 0
    d53 = build_tier1_dict(datetime.fromisoformat("1953-06-15T08:30"), has_time=True, gender="M")
    assert d53["time_context"]["longitude_correction_min"] == -30


def test_condition_b_has_no_hour_pillar():
    d = build_case(CASE["canonical_B"])
    assert d["meta"]["condition"] == "B"
    assert d["chart"]["hour"] is None
    assert d["time_context"]["solar_dt"] is None


def test_flow_signals_daewoon_detects_known_relations():
    """★I8: canonical 원국(庚午 辛巳 庚辰 庚辰)의 대운 戊寅에서 寅午 반합火국·寅巳해·반형 탐지."""
    d = build_case(CASE["canonical_A"])
    dw = {e["ganji"]: e for e in d["flow_signals"]["daewoon"]}
    assert "戊寅" in dw, f"대운 목록: {list(dw)}"
    types = {(s["type"], s["target_char"]) for s in dw["戊寅"]["signals"]}
    assert ("combine_3", "午") in types      # 寅午 반합 火국
    assert ("harm", "巳") in types           # 寅巳 해
    assert ("punishment", "巳") in types     # 寅巳 반형(寅巳申 삼형 2자)
    samhap = next(s for s in dw["戊寅"]["signals"] if s["type"] == "combine_3")
    assert samhap["status"] == "half"               # 왕지 午 포함 2지 = 반합
    assert samhap["transformed_element"] is None     # 미투출(원국 천간에 丙丁 없음)
    assert samhap["position_tier"] == "T2"           # 적중 자리 = 년지


def test_flow_signals_seyun_only_in_divination():
    """★I8: 세운 flow는 --divination에서만, 그 명리 연도로 산출(午午 자형·丙辛합 不化)."""
    assert build_case(CASE["canonical_A"])["flow_signals"]["seyun"] is None
    sy = build_case(CASE["divination"])["flow_signals"]["seyun"]   # --divination 2026-06-14
    assert sy is not None and sy["ganji"] == "丙午" and sy["year"] == 2026
    types = {(s["type"], s["target_char"]) for s in sy["signals"]}
    assert ("punishment", "午") in types     # 午午 자형
    sc = next(s for s in sy["signals"] if s["type"] == "stem_combine")
    assert sc["status"] == "no_hua"          # 丙辛합水, 원국 壬癸 미투출 → 合而不化


def test_boundary_evidence_exposes_a6_asymmetry():
    """★I7: A6 승격 명식(xing_only_a6)은 balanced로 운용되나 boundary_evidence가
    raw=quasi_weak·a6_shift=+1·nearer=weak로 弱쪽 비대칭을 노출한다(Feedback #1 대응)."""
    s = build_case(CASE["xing_only_a6"])["strength"]
    be = s["boundary_evidence"]
    assert s["verdict_center"] == "balanced"      # 운용은 balanced
    assert be["raw_verdict"] == "quasi_weak"      # raw는 더 약함
    assert be["a6_shift_levels"] == 1             # A6가 +1 승격
    assert be["nearer_boundary"] == "weak"        # 弱 경계에 더 가까움
    assert be["dist_to_weak"] == 0.0 and be["dist_to_strong"] == -30.0


def test_boundary_evidence_is_pure_echo():
    """I7 read-only: boundary_evidence는 strength_pct·triggers의 재표현이지 새 판단이 아니다."""
    for label in ("canonical_A", "qi_both_strong", "qi_neither_weak"):
        s = build_case(CASE[label])["strength"]
        be = s["boundary_evidence"]
        assert be["raw_pct"] == s["strength_pct"]
        assert be["dist_to_weak"] == round(s["strength_pct"] - 35.0, 1)
        assert be["d_fuzzy_residual"] == s["triggers"]["d_fuzzy_residual"]


def test_flow_signals_excludes_wonjin_and_stem_clash():
    """I8 일관성: flow는 daily.py와 동일하게 원진·천간충을 탐지하지 않는다
    (원진=신살 tier ASK6 §2-8, 천간극=§① 프롬프트 — 둘 다 엔진 비대상)."""
    d = build_case(CASE["canonical_A"])
    all_types = {s["type"] for e in d["flow_signals"]["daewoon"] for s in e["signals"]}
    assert "wonjin" not in all_types
    assert all_types <= {"combine_6", "clash", "break", "harm", "hidden_combine",
                         "combine_3", "direction_group", "punishment", "stem_combine", "stem_exposed"}
