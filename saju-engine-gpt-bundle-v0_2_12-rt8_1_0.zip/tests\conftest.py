"""R2 회귀 하네스 — 공유 설정·헬퍼·상수 (saju-engine 번들 동봉).

설계 원칙(개선방향 검토 §3 회귀 안전장치):
- 골든은 '엔진이 *지금* 내는 출력'을 동결한다 — 자동 재생성 금지(그래야 회귀를 잡는다).
- 검증 상수는 엔진 자신(saju_engine.constants 등)에서 끌어와 드리프트를 차단한다.
- 한자·한글 echo가 있으므로 모든 파일 I/O는 명시적으로 UTF-8.
"""
from __future__ import annotations

import sys
from pathlib import Path

# ── 엔진 루트를 import 경로에 (pytest.ini pythonpath와 이중 안전) ──
ENGINE_ROOT = Path(__file__).resolve().parent.parent          # = _extract
GOLDEN_DIR = Path(__file__).resolve().parent / "_golden"
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

# ── 엔진 자신의 진실원에서 끌어온 검증 상수 (재정의 금지) ──
from saju_engine.constants import (  # noqa: E402
    STEMS, BRANCHES, KO2CODE_TEN_GOD, KO2CODE_STAGE, KO2CODE_GROUP, KO2CODE_SLOT,
)
from saju_engine.engine.strength import SCALE  # noqa: E402

VALID_STEMS = set(STEMS)
VALID_BRANCHES = set(BRANCHES)
VALID_TEN_GODS = set(KO2CODE_TEN_GOD.values())
VALID_STAGES = set(KO2CODE_STAGE.values())
VALID_SCALE = set(SCALE)
VALID_QI_XING = {"both", "qi_only", "xing_only", "neither"}
# relations.py 직접 대조로 확정한 type 코드 전수 (10종)
VALID_RELATION_TYPES = {
    "combine_3", "combine_6", "direction_group", "stem_combine",
    "clash", "punishment", "break", "harm", "wonjin", "hidden_combine",
}
VALID_RELATION_STATUS = {"formed", "half", "contended"}
# flow_signals (I8) — 운×원국 탐지 신호
VALID_ELEMENTS = {"wood", "fire", "earth", "metal", "water"}
VALID_FLOW_TYPES = VALID_RELATION_TYPES | {"stem_exposed"}     # + 천간 透出
VALID_FLOW_STATUS = {None, "formed", "half", "hua", "no_hua"}
VALID_FLOW_POSITIONS = {"year", "month", "day", "hour", "stem_self"}

PIN = {
    "schema_version": "tier1.v1.6",            # I7 가산 (불변) — F3은 schema 무관
    "engine_version": "0.2.12",                # D-075 (§A6 지역 lookup — 출생지명→경도 결정론 변환, engine 0.2.11→0.2.12)
    "prompt_pin": "saju-runtime-8.1.0",        # 릴리스 8.1.0 (D-077 ASK7 SPOF 결정론 handoff 어셈블러·검증·원진 legend; emit 불변)
    "jieqi_schema": "jieqi.v1.0",
}


def read_text(path: Path) -> str:
    # Path.read_text 는 newline 인자 미지원 → norm()이 CRLF를 흡수한다
    return path.read_text(encoding="utf-8")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # newline="" + \n 고정: Windows CRLF 변환 차단(골든 안정성)
    path.write_text(text, encoding="utf-8", newline="")


def norm(s: str) -> str:
    """CRLF/말미 개행 정규화 — 플랫폼·에디터 차이로 인한 거짓 회귀 차단."""
    return s.replace("\r\n", "\n").rstrip("\n")
