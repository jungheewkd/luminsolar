"""ASK 2~6 SILENT_BUILD stage_output 조각 → 결정론 deep-merge (P3 — tier2 재조립 제거).

각 ASK가 emit한 부분 handoff JSON(STAGE CONTRACT output 경로 — ASK2 strength+branch_climate,
ASK3 energy_map, ASK4 pattern·용희기구·clarity·disease·boundary, ASK5 yong_mechanism,
ASK6 flow.current_*·boundary.operative_*)을 단일 봉인 입력으로 병합한다.

규율:
  - 동일 path **상이값 = fail-loud**(조각 충돌·재조립 오류 차단). 동일값은 무손실 병합.
  - 입력 비파괴(deepcopy). list는 atomic leaf(원소 머지 안 함 — 충돌 비교만).
  - 조각 부재(SILENT_BUILD Disabled/verbose)면 호출자가 P1/P2로 폴백(본 모듈 비호출).
    → assemble_handoff는 build.tier2_fragments 존재 시에만 본 모듈을 쓴다.
"""
from __future__ import annotations

import copy


def _deep_merge(dst: dict, src: dict, path: tuple, idx: int) -> None:
    for k, v in src.items():
        p = path + (k,)
        if k not in dst:
            dst[k] = copy.deepcopy(v)
        elif isinstance(dst[k], dict) and isinstance(v, dict):
            _deep_merge(dst[k], v, p, idx)
        elif dst[k] != v:
            raise ValueError(f"조각 충돌 {'.'.join(p)}: 기존={dst[k]!r} ↔ 조각[{idx}]={v!r} "
                             f"— 동일 path 상이값(재조립 오류)")
        # 동일 leaf 값이면 무시(무손실)


def merge_fragments(fragments) -> dict:
    """ASK 2~6 stage_output 조각(부분 handoff dict)의 list → 단일 병합 dict.
    충돌 시 ValueError(fail-loud). 빈/비-list/비-dict 원소는 거부."""
    if not isinstance(fragments, list) or not fragments:
        raise ValueError("tier2_fragments는 비어있지 않은 list여야 — ASK 2~6 stage_output 조각")
    out: dict = {}
    for i, frag in enumerate(fragments):
        if not isinstance(frag, dict):
            raise ValueError(f"조각[{i}]가 dict 아님: {type(frag).__name__}")
        _deep_merge(out, frag, (), i)
    return out
