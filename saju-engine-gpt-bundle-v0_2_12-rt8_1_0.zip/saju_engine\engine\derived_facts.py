"""Step 8 — 파생 사실: 공망(ASK4 §3)·지장간(§②)·십성(§③)·12운성(§③-2).

전부 잠긴 chart 위의 lookup/산식 — LLM 산술 개입 0.
- 공망: 일주 60갑자 인덱스 → 旬 시작 → (旬지지+10, +11). 60일 전수가 순중공망표와 이중 진입(테스트).
- 십성: 일간 기준. 천간 십성은 년·월·시간(일간 자신은 None — '일원'), 지지 십성은 본기 기준(§③).
- 12운성: 일간 × 각 지지 (STAGE_MATRIX). 상태군 보정(+0.2/−0.3)은 Step 10(득지) 소관.
- 표기(D-029): 한글 십성·운성명 — handoff legend 코드 변환은 Step 12 emit 단일 지점에서.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

from saju_engine.assets.lookup.hidden_stems import HIDDEN_STEMS
from saju_engine.assets.lookup.ten_gods import TEN_GOD_MATRIX
from saju_engine.assets.lookup.twelve_stages import STAGE_MATRIX
from saju_engine.constants import BRANCHES
from saju_engine.engine.month_hour_pillar import FourPillars


def void_branches(day_pillar_index: int) -> Tuple[str, str]:
    decade_start = day_pillar_index - (day_pillar_index % 10)
    zb = decade_start % 12
    return BRANCHES[(zb + 10) % 12], BRANCHES[(zb + 11) % 12]


def hidden_stems_of(branch: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    return HIDDEN_STEMS[branch]


def ten_god(day_stem: str, target_stem: str) -> str:
    return TEN_GOD_MATRIX[day_stem][target_stem]


def twelve_stage(day_stem: str, branch: str) -> str:
    return STAGE_MATRIX[day_stem][branch]


@dataclass(frozen=True)
class PillarFacts:
    hidden: Tuple[Optional[str], Optional[str], Optional[str]]
    ten_god_stem: Optional[str]      # 일간 자신 = None
    ten_god_branch: str              # 본기 기준
    twelve_stage: str


@dataclass(frozen=True)
class ChartFacts:
    void: Tuple[str, str]
    year: PillarFacts
    month: PillarFacts
    day: PillarFacts
    hour: Optional[PillarFacts]      # Condition B → None (S6)


def derive_chart_facts(fp: FourPillars) -> ChartFacts:
    ds = fp.day.ganji[0]

    def pil(gz: Optional[str], is_day: bool = False) -> Optional[PillarFacts]:
        if gz is None:
            return None
        return PillarFacts(hidden=HIDDEN_STEMS[gz[1]],
                           ten_god_stem=None if is_day else TEN_GOD_MATRIX[ds][gz[0]],
                           ten_god_branch=TEN_GOD_MATRIX[ds][HIDDEN_STEMS[gz[1]][0]],
                           twelve_stage=STAGE_MATRIX[ds][gz[1]])

    return ChartFacts(void=void_branches(fp.day.index),
                      year=pil(fp.year.ganji), month=pil(fp.month.ganji),
                      day=pil(fp.day.ganji, is_day=True), hour=pil(fp.hour.ganji if fp.hour else None))
