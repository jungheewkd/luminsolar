#!/usr/bin/env python3
"""saju.handoff.v3.8 결정론 봉인(assemble) — SILENT_BUILD 조각 → 핸드오프.

ASK 1~6이 무출력 빌드(SILENT_BUILD)로 emit한 stage_output 조각(tier1_facts +
tier2_interpretation)을 받아, '새 판단 0'으로 결정론 산출 가능한 derived_lookup을
계산·병합하고 v3.8 구조를 검증한다. LLM(ASK 7)의 산문 직렬화를 기계 병합으로
대체 → 출력·절단 위험↓, 수동 LEAN·미래 외부 오케스트레이터 공용(ASK 7 RoE #12).

핵심 산출 3건:
  ① strength 재배치(R2′ 에코) — 엔진 tier1_facts.strength(결정론 SoT)를 canonical
     필드명으로 tier2_interpretation.strength에 병합하고 tier1에서 제거(ASK 7 §2013
     스키마 정합). tier1↔tier2 top-key 충돌 해소 → boundary_hold=true 명식도 봉인 가능.
  ② element_favorability — 용/희/기/구 → 5오행 favorability. boundary_hold 명식
     (strength.boundary에 강·약 가지 yong/hee/gi/gu)은 by_branch(operative_branch +
     가지별 맵), 그 외 single.
  ③ remedy_map/health_map(v3.8) — 오행→개운(방위·색·시진·직업)·건강(장부·증상)
     보편표 결정론 임베드(ref §⑪ — 명식 무관 상수, 새 판단 0).

⛔ 비목표(dual-SoT 차단): legend·spec·consumer_scope·reasoning_scaffold 등 정적
   산문 블록은 ask_modules.md <ASK 7>가 단일 SoT다 — 여기서 재생산하지 않는다.
   본 도구는 결정론 산출(derived_lookup·strength echo)·병합·검증만 담당한다.
   ※ tier1의 그 외 블록(flow_signals·time_context·chart) canonical 재구조화(true_solar_time/
     flow 중첩)는 LEAN 봉인 비목표 — ASK 7 수동 직렬화 소관(본 도구는 strength만 재배치).

입력(stdin 또는 --in FILE) = 누적 빌드 JSON:
  { "meta": {...}?, "tier1_facts": { ..., strength{verdict_center·deuk_*_raw·boundary_hold·candidates·boundary_evidence} },
    "tier2_interpretation": { yong_shen·hee_shen·gi_shin·gu_shin(.element), strength.boundary{strong_branch·weak_branch ...}? } }
산출: 봉인 핸드오프 JSON(stdout) / --check(검증만, 위반 시 exit 1).

  python3 run_emit.py --assemble --in build.json
  python3 run_emit.py --assemble --check < build.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parent.parent
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

from saju_engine.assets.lookup.attributes import STEM_ATTR, BRANCH_ATTR  # noqa: E402
from saju_engine.constants import HANJA2ELEM                            # noqa: E402

SCHEMA = "saju.handoff.v3.8"
ELEMENTS = ("wood", "fire", "earth", "metal", "water")


def _norm_elem(e):
    """오행 토큰 정규화: 한자(木火土金水) 또는 english → english, 미해석 시 None."""
    if e is None:
        return None
    e = str(e).strip()
    if e in HANJA2ELEM:
        return HANJA2ELEM[e]
    e = e.lower()
    return e if e in ELEMENTS else None


def stem_branch_element() -> dict:
    """천간10·지지12 → english 오행 (엔진 STEM_ATTR/BRANCH_ATTR 단일 SoT — 새 판단 0)."""
    out = {}
    for s, a in STEM_ATTR.items():
        out[s] = HANJA2ELEM[a["element"]]
    for b, a in BRANCH_ATTR.items():
        out[b] = HANJA2ELEM[a["element"]]
    return out


def remedy_map() -> dict:
    """오행→개운(방위·색·소재·시진·태도·직업) 보편표 (ref §⑪-1 단일 SoT — 새 판단 0)."""
    return {
        "wood": {"direction": "동", "color": "청록", "material": "나무·식물", "hours": "寅卯(03–07시)", "virtue": "성장", "occupation": "교육·출판·기획"},
        "fire": {"direction": "남", "color": "적색", "material": "조명·촛불", "hours": "巳午(09–13시)", "virtue": "표현", "occupation": "미디어·IT·서비스"},
        "earth": {"direction": "중앙·남서", "color": "황토", "material": "도자기·돌", "hours": "丑辰未戌(01–03·07–09·13–15·19–21시)", "virtue": "신뢰·포용", "occupation": "부동산·중개·관리"},
        "metal": {"direction": "서", "color": "백색", "material": "금속·철제", "hours": "申酉(15–19시)", "virtue": "결단·정리", "occupation": "금융·법무·의료"},
        "water": {"direction": "북", "color": "흑색", "material": "유리·물", "hours": "亥子(21–01시)", "virtue": "탐구", "occupation": "연구·유통·무역"},
    }


def health_map() -> dict:
    """오행→건강(장부·과다/부족 증상) 보편표 (ref §⑪-2 단일 SoT — 경향, 진단 단정 아님)."""
    return {
        "wood": {"organ": "간·담", "excess": "분노·두통·고혈압·근육경직·눈피로", "deficiency": "우유부단·시력저하·간기능저하"},
        "fire": {"organ": "심·소장", "excess": "불면·심계항진·구강염증·조급", "deficiency": "의욕저하·냉증·소화불량"},
        "earth": {"organ": "비·위", "excess": "소화불량·비만·당뇨·과도한걱정", "deficiency": "식욕부진·영양불량·근육소실"},
        "metal": {"organ": "폐·대장", "excess": "호흡기·피부·변비·우울", "deficiency": "면역저하·설사·슬픔"},
        "water": {"organ": "신·방광", "excess": "부종·신장질환·요통·공포감", "deficiency": "탈모·이명·골다공증·냉증"},
    }


# 엔진 strength(결정론 SoT) → canonical tier2.strength 필드 echo(R2′ — 엔진이 권위).
_STRENGTH_ECHO = {
    "verdict_center": "verdict_code",
    "strength_pct": "strength_pct",
    "deuk_ryeong_raw": "deuk_ryeong_pct",
    "deuk_ji_raw": "deuk_ji_pct",
    "deuk_se_raw": "deuk_se_pct",
    "boundary_hold": "boundary_hold",
}


def rehome_strength(t1: dict, t2: dict) -> None:
    """canonical v3.7 — strength는 tier2_interpretation.strength에 산다(ASK 7 SoT).

    엔진 tier1_facts.strength(결정론 SoT)를 canonical 필드명으로 tier2.strength에 병합하고
    tier1에서 제거 → ① tier1↔tier2 top-key 충돌 해소(boundary 명식 병합 가능) ② 결정론 값
    권위 보존(LLM 에코를 신뢰하지 않고 엔진 값으로 확정 = R2′). LLM이 채운 strength.boundary
    (강·약 가지 yong/hee/gi/gu·operative_branch 판단)는 보존하되, 결정론 부분(candidates·
    confidence_asymmetry=boundary_evidence echo)은 엔진에서 덮어쓴다(I7). t1/t2를 제자리 수정."""
    eng = t1.pop("strength", None)
    if eng is None:
        return
    if not isinstance(eng, dict):
        raise ValueError(f"tier1_facts.strength dict 아님(got {type(eng).__name__}) — 엔진 emit 손상")
    s2 = dict(t2.get("strength") or {})                 # LLM 제공분(boundary 등) 보존
    s2.pop("candidates", None)                          # candidates는 boundary 안에서만(결정론)
    for ek, ck in _STRENGTH_ECHO.items():
        if ek in eng:
            s2[ck] = eng[ek]                            # 엔진 값으로 결정론 필드 확정(R2′)
    if eng.get("boundary_hold"):
        llm_b = s2.get("boundary")
        b = dict(llm_b) if isinstance(llm_b, dict) else {}   # LLM strong/weak_branch·operative_branch
        b["candidates"] = eng.get("candidates")         # 결정론(SCALE 이웃) — 엔진 권위(누락 시 None)
        if eng.get("boundary_evidence") is not None:
            b["confidence_asymmetry"] = eng["boundary_evidence"]   # I7 비대칭 echo
        s2["boundary"] = b
    else:
        s2["boundary"] = None                           # 엔진 권위 — hold=False면 boundary 없음
    s2["source"] = "derived"                            # 결정론 봉인(LLM source 무력화)
    t2["strength"] = s2


def _elem_of(v, where: str = "") -> str | None:
    """god 값 → element. 부재(None/공백)는 None, present-nonempty인데 미해석이면 fail-loud
    (오타·잘못된 토큰의 조용한 손실 차단)."""
    raw = v.get("element") if isinstance(v, dict) else v
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return None
    e = _norm_elem(raw)
    if e is None:
        raise ValueError(f"{where}미해석 오행 토큰 {raw!r} — 용/희/기/구 정규화 실패")
    return e


def _favset(shen: dict, where: str = ""):
    """용/희/기/구 dict → (fav 오행집합, unf 오행집합)."""
    fav = {e for e in (_elem_of(shen.get("yong_shen"), f"{where}yong_shen "),
                       _elem_of(shen.get("hee_shen"), f"{where}hee_shen ")) if e}
    unf = {e for e in (_elem_of(shen.get("gi_shin"), f"{where}gi_shin "),
                       _elem_of(shen.get("gu_shin"), f"{where}gu_shin ")) if e}
    return fav, unf


def _single_map(fav: set, unf: set) -> dict:
    return {el: ("favorable" if el in fav else "unfavorable" if el in unf else "neutral")
            for el in ELEMENTS}


def element_favorability(t2: dict) -> dict:
    """tier2 용/희/기/구 → 5오행 favorability. **모드는 엔진 권위 boundary_hold가 결정한다**:
    boundary_hold=true → by_branch(operative_branch + 강·약 가지별 맵), false → single.
    (LLM 입력 유무로 모드를 정하면 boundary_hold와 어긋날 수 있어 금지 — R2′.)

    충돌(용/희 ∩ 기/구)은 스코프(single/strong/weak)별로 fail-loud."""
    def _check(fav, unf, where):
        c = fav & unf
        if c:
            raise ValueError(f"{where}: 용/희 ∩ 기/구 오행 충돌 {sorted(c)} — tier2 판정 불일치(용신=기신 불가)")

    strength = t2.get("strength") or {}
    hold = bool(strength.get("boundary_hold"))
    boundary = strength.get("boundary")
    fav, unf = _favset(t2, "single.")
    _check(fav, unf, "single")
    single = _single_map(fav, unf)

    if hold:                                            # boundary_hold=true → by_branch 강제
        sb = boundary.get("strong_branch") if isinstance(boundary, dict) else None
        wb = boundary.get("weak_branch") if isinstance(boundary, dict) else None
        if not (isinstance(sb, dict) and isinstance(wb, dict)):
            raise ValueError("boundary_hold=true인데 strength.boundary.strong/weak_branch(dict) 부재 "
                             "— ASK4 boundary(강·약 가지 용/희/기/구) 판단 필요")
        sf, su = _favset(sb, "strong_branch."); _check(sf, su, "strong_branch")
        wf, wu = _favset(wb, "weak_branch."); _check(wf, wu, "weak_branch")
        return {"mode": "by_branch", "single": None, "by_branch": {
            "operative_branch": boundary.get("operative_branch"),
            "strong_branch": _single_map(sf, su),
            "weak_branch": _single_map(wf, wu),
        }}
    if not (fav or unf):                                # 용/희/기/구 전무 = 판정 부재(조각 누락)
        raise ValueError("element_favorability(single): 용/희/기/구신 전무 — tier2 판정 부재"
                         "(ASK 4 조각 누락 의심). all-neutral 봉인 차단")
    return {"mode": "single", "single": single, "by_branch": None}


def _overlay_fragment_tier1(t1: dict, frag_t1: dict) -> None:
    """조각이 제공하는 tier1 필드(ASK2 branch_climate·ASK6 flow.current_*)를 생성 tier1의
    BLIND SLOT(null)에 덮는다(P3). 엔진 결정 필드(pillars 등)는 조각이 안 건드린다."""
    fc = frag_t1.get("chart") or {}
    if "branch_climate" in fc:
        t1.setdefault("chart", {})["branch_climate"] = fc["branch_climate"]
    ff = frag_t1.get("flow") or {}
    for k in ("current_daewoon", "current_se_woon"):
        if k in ff:
            t1.setdefault("flow", {})[k] = ff[k]


def assemble(build: dict) -> dict:
    engine_t1 = build.get("engine_tier1")               # P2 dual-path
    fragments = build.get("tier2_fragments")            # P3 — ASK 2~6 stage_output 조각
    frag_t1: dict = {}
    if fragments is not None:                           # 조각 deep-merge → tier2(LLM 재조립 제거)
        from tools.handoff_merge import merge_fragments
        merged = merge_fragments(fragments)
        t2 = merged.get("tier2_interpretation")
        frag_t1 = merged.get("tier1_facts") or {}       # ASK2 branch_climate·ASK6 flow.current_* 오버레이
    else:                                               # 조각 부재(verbose/단발) → legacy tier2 폴백
        t2 = build.get("tier2_interpretation")
    if engine_t1 is not None:                           # 엔진 raw → 결정론 tier1 생성(LLM 재타이핑 제거)
        from tools.handoff_verify import build_handoff_tier1
        t1 = build_handoff_tier1(engine_t1)
        _overlay_fragment_tier1(t1, frag_t1)            # BLIND SLOT(branch_climate·flow.current_*) 채움
        t1["strength"] = engine_t1.get("strength")      # rehome가 tier2로 옮김(엔진 권위 R2′)
        if isinstance(t2, dict) and not t2.get("day_master"):   # day_master 결정론 파생(조각 미선언)
            ds = engine_t1["chart"]["day"]["stem"]
            t2 = {**t2, "day_master": {"stem": ds, "element": stem_branch_element()[ds]}}
    else:                                               # legacy — LLM이 채운 tier1_facts stage_output
        t1 = build.get("tier1_facts")
    if not isinstance(t1, dict) or not t1:
        raise ValueError("tier1_facts 누락 — engine_tier1 또는 tier1_facts stage_output 필요")
    if not isinstance(t2, dict) or not t2:
        raise ValueError("tier2_interpretation 누락 — tier2_fragments 또는 tier2_interpretation 필요")
    t1, t2 = dict(t1), dict(t2)                          # 호출자 입력 비파괴(제자리 수정 회피)
    rehome_strength(t1, t2)                              # 엔진 strength → tier2(canonical)
    fav_block = element_favorability(t2)                 # 충돌 시 내부 fail-loud
    meta = build.get("meta") or (engine_t1 or {}).get("meta") or t1.get("meta") or {}
    narrative = build.get("narrative") or {}             # P4 — LLM 산문(비-load-bearing) 물리 격리
    for key, hint in (narrative.get("usage_hints") or {}).items():   # tier2 필드 usage_hint 주입(비파괴)
        if isinstance(t2.get(key), dict):
            t2[key] = {**t2[key], "usage_hint": hint}
    from tools import handoff_static as _hs               # 정적 블록 결정론 임베드(canonical 미러)
    return {
        "schema": SCHEMA,
        "spec_ref": narrative.get("spec_ref"),
        "tldr": narrative.get("tldr"),                   # ↓ narrative(LLM 산문) — load-bearing 아님
        "methodology": narrative.get("methodology"),
        "meta": meta,
        "legend": _hs.LEGEND,                            # ↓ 결정론 — LLM 저작 0
        "spec": _hs.SPEC,
        "consumer_scope": _hs.CONSUMER_SCOPE,
        "reasoning_scaffold": _hs.REASONING_SCAFFOLD,
        "tier1_facts": t1,
        "tier2_interpretation": t2,
        "derived_lookup": {
            "stem_branch_element": stem_branch_element(),
            "element_favorability": fav_block,
            "remedy_map": remedy_map(),
            "health_map": health_map(),
        },
        "derivation": narrative.get("derivation") or {},
        "limits": narrative.get("limits"),               # narrative
    }


def validate(h: dict, raw_t1: dict | None = None) -> list:
    errs = []
    if h.get("schema") != SCHEMA:
        errs.append(f"schema != {SCHEMA} (got {h.get('schema')!r})")
    t1 = h.get("tier1_facts") or {}
    t2 = h.get("tier2_interpretation") or {}
    if not t1:
        errs.append("tier1_facts 비어있음")
    if not t2:
        errs.append("tier2_interpretation 비어있음")
    overlap = set(t1) & set(t2)
    if overlap:
        errs.append(f"tier1↔tier2 top-key 누설(분리 위반): {sorted(overlap)}")
    if "strength" in t1:
        errs.append("tier1_facts에 strength 잔존 — canonical 재배치 위반(tier2_interpretation.strength이어야)")
    dl = h.get("derived_lookup") or {}
    sbe = dl.get("stem_branch_element") or {}
    if len(sbe) != 22 or any(v not in ELEMENTS for v in sbe.values()):
        errs.append(f"stem_branch_element 폐쇄 불완전(22키·5오행 기대, got {len(sbe)}키)")
    ef = dl.get("element_favorability") or {}
    errs += _validate_favorability(ef)
    # 모드 ↔ 엔진 boundary_hold 정합(자기모순 false-green 차단)
    hold = bool((t2.get("strength") or {}).get("boundary_hold"))
    mode = ef.get("mode")
    if hold and mode != "by_branch":
        errs.append(f"boundary_hold=true인데 element_favorability.mode={mode!r}(by_branch 기대)")
    if not hold and mode == "by_branch":
        errs.append("boundary_hold=false인데 element_favorability.mode=by_branch")
    for _mname in ("remedy_map", "health_map"):             # v3.8 — 개운·건강 보편표 5오행 폐쇄
        _m = dl.get(_mname) or {}
        if set(_m) != set(ELEMENTS):
            errs.append(f"{_mname} 5오행 폐쇄 불완전(got {sorted(_m)})")
    if raw_t1 is not None:                                  # P1 — 엔진 raw 대조(no-new-values)
        from tools.handoff_verify import verify_against_engine
        errs += verify_against_engine(h, raw_t1)
    return errs


def _validate_favorability(ef: dict) -> list:
    """element_favorability 폐쇄 검증 — single/by_branch 모드별 5오행 닫힘."""
    def closed(m, where):
        if set(m) != set(ELEMENTS) or any(
                v not in ("favorable", "neutral", "unfavorable") for v in m.values()):
            return [f"element_favorability.{where} 5오행 폐쇄 불완전"]
        return []

    mode = ef.get("mode")
    if mode == "single":
        return closed(ef.get("single") or {}, "single")
    if mode == "by_branch":
        by = ef.get("by_branch") or {}
        errs = []
        if by.get("operative_branch") not in ("strong_branch", "weak_branch"):
            errs.append("element_favorability.by_branch.operative_branch 미상(strong/weak_branch 기대)")
        for side in ("strong_branch", "weak_branch"):
            errs += closed(by.get(side) or {}, f"by_branch.{side}")
        return errs
    return [f"element_favorability.mode 미상: {mode!r}(single/by_branch 기대)"]


def run_cli(argv) -> int:
    if "--verify" in argv:
        return _run_verify(argv)
    check = "--check" in argv
    try:
        if "--in" in argv:
            src = Path(argv[argv.index("--in") + 1]).read_text(encoding="utf-8")
        else:
            src = sys.stdin.read()
    except (OSError, IndexError) as e:
        print(f"[assemble] 입력 파일 읽기 불가: {e}")
        return 1
    try:
        build = json.loads(src)
    except (json.JSONDecodeError, ValueError) as e:
        print(f"[assemble] 입력 JSON 파싱 불가: {e}")
        return 1
    try:
        h = assemble(build)
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        print(f"[assemble] 봉인 불가: {type(e).__name__}: {e}")
        return 1
    errs = validate(h)
    if check:
        print(f"[assemble --check] schema {SCHEMA} · 위반 {len(errs)}건")
        for x in errs:
            print("   " + x)
        return 1 if errs else 0
    if errs:
        print(f"[assemble] 검증 위반 {len(errs)}건 — 출력 보류:")
        for x in errs:
            print("   " + x)
        return 1
    print("```saju_handoff")
    print(json.dumps(h, ensure_ascii=False, indent=2))
    print("```")
    return 0


def _run_verify(argv) -> int:
    """봉인된 full handoff를 엔진 raw tier1_facts와 대조 검증(P1·접근 A).

      python3 run_emit.py --assemble --verify --handoff H.json [--raw RAW.json]

    --raw(엔진 tier1 JSON) 권장 — 외부 오케스트레이터가 엔진 호출에 쓴 원본. 미제공 시
    handoff.meta로 재산출하나 meta 오전사 시 앵커가 오염될 수 있다."""
    def _read(flag):
        return json.loads(Path(argv[argv.index(flag) + 1]).read_text(encoding="utf-8"))

    try:
        handoff = _read("--handoff")
    except (OSError, IndexError, ValueError, json.JSONDecodeError) as e:
        print(f"[verify] handoff 읽기/파싱 불가: {e}")
        return 1
    if "--raw" in argv:
        try:
            raw = _read("--raw")
        except (OSError, IndexError, ValueError, json.JSONDecodeError) as e:
            print(f"[verify] raw tier1 읽기/파싱 불가: {e}")
            return 1
    else:
        from tools.handoff_verify import engine_raw_from_meta
        print("[verify] ⚠️ --raw 미제공 → meta.birth_input로 엔진 재산출(앵커 오염 주의)")
        raw = engine_raw_from_meta(handoff)
        if raw is None:
            print("[verify] meta 재산출 불가 — --raw <엔진 tier1 JSON> 필요")
            return 1
    from tools.handoff_verify import (validate_static_blocks, validate_legend_codes,
                                      validate_boundary_consistency)
    errs = (validate(handoff, raw_t1=raw)            # 구조 + 엔진 raw 대조(증분1)
            + validate_static_blocks(handoff)         # 정적블록 canonical 대조(증분2)
            + validate_legend_codes(handoff)          # legend 코드 폐쇄(증분2)
            + validate_boundary_consistency(handoff)) # boundary 라우팅 내부정합(증분3)
    print(f"[verify] saju.handoff.v3.8 ↔ 엔진 raw + canonical(정적·legend) · 위반 {len(errs)}건")
    for x in errs:
        print("   " + x)
    return 1 if errs else 0


if __name__ == "__main__":
    raise SystemExit(run_cli(sys.argv[1:]))
