"""tier2 boundary 캡처-컨텍스트 매니페스트 (재)생성기 — 명시 실행 전용 (§4-1 Layer-1).

    python tests/gen_tier2_boundary.py                 # 캡처-컨텍스트 매니페스트 생성/갱신
    python tests/gen_tier2_boundary.py --check         # 생성 없이 diff + 캡처 상태 요약
    python tests/gen_tier2_boundary.py --capture-prompts  # 캡처 대기 케이스 풀 번들 stdout

Layer-1: 각 boundary 케이스의 캡처 컨텍스트(STAGE 슬라이스 + fixture tier1)를 **해시
매니페스트**로 동결한다. 슬라이스는 4케이스 공통(중복) → 풀 번들을 4×저장하지 않고
sha256만 잠근다(드리프트 탐지력 동일·바이트 수백). 슬라이스/엔진 드리프트 시 해시 변경
= 기존 캡처 무효화 신호. 풀 번들(LLM 붙여넣기용)은 --capture-prompts로 온디맨드 생성.

⚠️ Layer-2(captured_tier2 → assembled 골든)는 1회성 LLM 캡처 후. boundary_hold=true
   명식은 assemble_handoff strength 재배치 미구현으로 보류(docs/TIER2_BOUNDARY_GOLDENS.md).
   회귀 잠금 철학은 gen_golden.py와 동일 — 테스트는 매니페스트를 자동 재생성하지 않는다.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ENGINE_ROOT = HERE.parent
REPO_ROOT = ENGINE_ROOT.parent
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

import json                                                       # noqa: E402

from tests.tier2_boundary_corpus import (  # noqa: E402
    TIER2_BOUNDARY_CASES, capture_prompt, fixture_tier1, assembled,
    class_coverage, BOUNDARY_CLASSES,
)
from tools.assemble_slice import prompts_present                  # noqa: E402

GOLDEN_DIR = HERE / "_golden_tier2"
# 가드는 의존 슬라이서와 동일 기준(3파일) — ask_modules.md 단독 검사는 부분 배포에서
# raw FileNotFoundError 누출(슬라이서가 core_kernel·reference_tables도 읽음).
_PROMPTS_PRESENT = prompts_present()


def _norm(s: str) -> str:
    return s.replace("\r\n", "\n").rstrip("\n")


def _sha(s: str) -> str:
    return hashlib.sha256(_norm(s).encode("utf-8")).hexdigest()


def _manifest(case) -> str:
    """캡처 컨텍스트 매니페스트(결정론) — 슬라이스·tier1·번들 해시 + 캡처 상태."""
    from tools.assemble_slice import assemble_slice
    slice_txt = assemble_slice(case.capture_stage)
    t1_json = json.dumps(fixture_tier1(case.fixture), ensure_ascii=False, indent=2, sort_keys=True)
    bundle = capture_prompt(case)
    m = {
        "fixture": case.fixture,
        "boundary_class": case.boundary_class,
        "capture_stage": case.capture_stage,
        "captured": case.captured_tier2 is not None,
        "slice_sha256": _sha(slice_txt),
        "tier1_sha256": _sha(t1_json),
        "bundle_sha256": _sha(bundle),
    }
    return json.dumps(m, ensure_ascii=False, indent=2, sort_keys=True)


def _write(name: str, text: str) -> None:
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    (GOLDEN_DIR / name).write_text(text, encoding="utf-8", newline="")


def _capture_status() -> str:
    captured = sum(1 for c in TIER2_BOUNDARY_CASES if c.captured_tier2 is not None)
    awaiting = len(TIER2_BOUNDARY_CASES) - captured
    cov = class_coverage()
    covered = [k for k in BOUNDARY_CLASSES if cov.get(k)]
    line = (f"[capture] 케이스 {len(TIER2_BOUNDARY_CASES)} · 캡처완료 {captured} · "
            f"대기 {awaiting} · 클래스 {len(covered)}/{len(BOUNDARY_CLASSES)}")
    missing = [k for k in BOUNDARY_CLASSES if not cov.get(k)]
    if missing:
        line += f" · 미커버 클래스: {missing}"
    return line


def main(argv) -> int:
    if "--capture-prompts" in argv:
        if not _PROMPTS_PRESENT:
            print("[skip] 프롬프트 .md 부재(번들-only) — 캡처 프롬프트 생략.")
            return 0
        for c in TIER2_BOUNDARY_CASES:
            if c.captured_tier2 is not None:
                continue
            print(f"\n===== CAPTURE PROMPT · {c.label} ({c.boundary_class}) =====\n")
            print(capture_prompt(c))
        print("\n" + _capture_status())
        return 0

    if not _PROMPTS_PRESENT:
        print("[skip] 프롬프트 .md 부재(번들-only 배포?) — Layer-1 매니페스트 생략.")
        return 0

    check = "--check" in argv
    changed, created, ok = [], [], 0
    # Layer-1 매니페스트(전 케이스) + Layer-2 assembled 골든(캡처된 케이스만)
    items = [(f"{c.label}.manifest.json", _manifest(c)) for c in TIER2_BOUNDARY_CASES]
    for c in TIER2_BOUNDARY_CASES:
        if c.captured_tier2 is not None:                # Layer-2 — captured 후 결정론 봉인
            items.append((f"{c.label}.assembled.json",
                          json.dumps(assembled(c), ensure_ascii=False, indent=2)))
    for name, live in items:
        path = GOLDEN_DIR / name
        if check:
            if not path.exists():
                created.append(name)
            elif _norm(path.read_text(encoding="utf-8")) != _norm(live):
                changed.append(name)
            else:
                ok += 1
        else:
            _write(name, live)
            print(f"  wrote {name}")
    if check:
        print(f"[check] 일치 {ok} · 변경 {len(changed)} · 신규 {len(created)}")
        for n in changed:
            print(f"   CHANGED: {n}")
        for n in created:
            print(f"   MISSING: {n}")
        print(_capture_status())
        return 1 if (changed or created) else 0
    print(f"완료: {len(TIER2_BOUNDARY_CASES)}개 캡처-컨텍스트 매니페스트 → {GOLDEN_DIR}")
    print(_capture_status())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
