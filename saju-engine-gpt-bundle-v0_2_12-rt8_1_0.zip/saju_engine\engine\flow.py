"""Step 13 — 운(대운·세운)×원국 합충 작용 *탐지* (flow_signals) — I8.

[경계 — daily.py D-057 / relations.py D-030 철학 상속] 본 모듈은 *역법-구조 사실까지만* 소유한다:
  운 글자(대운·세운 간지) × 원국 합·충·형·파·해·암합·삼합/방국(會局)·천간합/透出의 **탐지(이진 성립 + 구조 status)**.

[daily.py와의 의도적 차이 — 검토 I8 guardrail]
  ① **旺衰·STAGE2 작용형(去/發/動) 비방출**: 일진은 점단월 사령(prev_jie)이 자명하나 대운 '사령월'은 구간
     추상이라 운 글자의 旺衰가 ill-defined(#2·#6). 세력·강도·발동 판정은 미산출 → §2-0-2 LLM 정성에 위임.
  ② **STAGE1 해소(會局 흡수·탐합망충·합처봉충=파합·충중봉합) 비실행**: 그 resolution은 ask_modules §2-0-2가
     이미 소유한다(운×원국 SoT). 엔진이 또 해소하면 SoT 이원화(#3). 본 모듈은 *탐지 사실*만 공급하고
     §2-0-2가 그 위에서 우세를 가린다.
  ③ **부호(吉/凶) 미산출**: target_element만 방출(daily.py:5 동일) — element_favorability는 프롬프트가 입힌다.

[근접성] position_tier(T1/T2)는 §④-6 #3 근접성(강도 변수)으로 구조 사실이라 방출한다(旺衰 아님).
[§2-0-3 JOIN] 각 신호에 target_position을 달아, 同 (운기둥×원국기둥)의 〔천간 hit + 지지 hit〕를
  프롬프트 §2-0-3(천극지충·천합지합 POST-SCAN JOIN)이 묶을 수 있게 한다(#5).
[재사용] relations_tables lookup만 재사용(detect_relations 전체 재사용 금지 — 운 1글자쌍 스코프, daily.py 패턴).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from saju_engine.assets.lookup.attributes import BRANCH_ATTR, STEM_ATTR
from saju_engine.assets.lookup.relations_tables import (
    AMHAP, BANGGUK, CHEONGANHAP, HAE, HYEONG, PA, SAMHAP, YUKCHUNG, YUKHAP,
)
from saju_engine.constants import HANJA2ELEM

POS_ORDER = ("year", "month", "day", "hour")
WANGJI = {"子", "午", "卯", "酉"}
T1_POS = {"day", "month"}                       # 근접 1급(일지·월지). 천간 신호도 T1.
SELF_PUNISH = set(HYEONG["자형"])
CHEONGANHAP_N = {tuple(sorted(k)): v for k, v in CHEONGANHAP.items()}
YUKHAP_N = {tuple(sorted(k)): v for k, v in YUKHAP.items()}
YUKCHUNG_N = {tuple(sorted(p)) for p in YUKCHUNG}
PA_N = {tuple(sorted(p)) for p in PA}
HAE_N = {tuple(sorted(p)) for p in HAE}
AMHAP_N = {tuple(sorted(p)) for p in AMHAP}


@dataclass(frozen=True)
class FlowSignal:
    channel: str                    # branch | stem
    type: str                       # combine_6/clash/break/harm/hidden_combine/combine_3/direction_group/punishment/stem_combine/stem_exposed
    luck_char: str                  # 운 글자 (간 or 지)
    target_position: str            # 적중 원국 자리 (year/month/day/hour) — §2-0-3 JOIN 키
    target_char: str
    target_element: str             # 무부호 — 부호는 프롬프트 element_favorability lookup
    transformed_element: Optional[str]   # 화기 성립(투출) 오행
    status: Optional[str]           # 삼합: formed/half | 천간합: hua/no_hua | else None
    position_tier: str              # T1/T2 (근접성 — 강도 변수, 旺衰 아님)
    note: str                       # 탐지 근거(삼합 완성/반합/합거 등)


def _tier(pos: str, channel: str) -> str:
    if channel == "stem":
        return "T1"
    return "T1" if pos in T1_POS else "T2"


def _detect(ns: Dict[str, Optional[str]], nb: Dict[str, Optional[str]],
            ij_s: str, ij_b: str) -> List[FlowSignal]:
    """운 간지(ij_s·ij_b) × 원국(ns·nb) 탐지 → FlowSignal 목록(旺衰·해소 무관 순수 구조)."""
    natal_stem_elems = {STEM_ATTR[s]["element"] for s in ns.values() if s}
    out: List[FlowSignal] = []

    def add(channel, type_, pos, target, elem_hanja, transformed=None, status=None, note=""):
        out.append(FlowSignal(
            channel=channel, type=type_, luck_char=(ij_s if channel == "stem" else ij_b),
            target_position=pos, target_char=target,
            target_element=HANJA2ELEM.get(elem_hanja, elem_hanja),
            transformed_element=(HANJA2ELEM.get(transformed, transformed) if transformed else None),
            status=status, position_tier=_tier(pos, channel), note=note))

    # ── 지지 쌍 (육합·충·파·해·암합) ──
    for pos, b in nb.items():
        if not b:
            continue
        key = tuple(sorted((ij_b, b)))
        if key in YUKHAP_N:
            raw = YUKHAP_N[key]
            cands = [c for c in raw if c in "木火土金水"]
            tr = next((c for c in cands if c in natal_stem_elems), None)  # 투출 only(월령 화기는 §④-4 프롬프트)
            add("branch", "combine_6", pos, b, BRANCH_ATTR[b]["element"], transformed=tr,
                note="육합 화기(투출)" if tr else "육합(투출 미충족 — 합거/월령 화기 §④-4 위임)")
        if key in YUKCHUNG_N:
            add("branch", "clash", pos, b, BRANCH_ATTR[b]["element"], note="육충")
        if key in PA_N:
            add("branch", "break", pos, b, BRANCH_ATTR[b]["element"], note="파(tier4)")
        if key in HAE_N:
            add("branch", "harm", pos, b, BRANCH_ATTR[b]["element"], note="해(tier4)")
        if key in AMHAP_N:
            add("branch", "hidden_combine", pos, b, BRANCH_ATTR[b]["element"], note="암합(§④-5)")

    # ── 삼합/방국 (運支 + 원국 지지들 = 會局) ──
    for elem, spec in SAMHAP.items():
        if ij_b not in spec["branches"]:
            continue
        distinct = {nb[p] for p in POS_ORDER if nb.get(p) in spec["branches"]} | {ij_b}
        tu = any(STEM_ATTR[s]["element"] == elem for s in ns.values() if s)
        rep = next((p for p in ("day", "month", "hour", "year") if nb.get(p) in spec["branches"]), None)
        if len(distinct) == 3 and rep:
            add("branch", "combine_3", rep, nb[rep], elem, transformed=elem, status="formed",
                note=f"삼합 {elem}局 완성({'투출' if tu else '미투출'})")
        elif len(distinct) == 2 and (distinct & WANGJI) and rep:
            add("branch", "combine_3", rep, nb[rep], elem, transformed=(elem if tu else None),
                status="half", note=f"반합 {elem}局(왕지 포함, {'투출' if tu else '미투출'})")
    for elem, spec in BANGGUK.items():
        if ij_b not in spec["branches"]:
            continue
        distinct = {nb[p] for p in POS_ORDER if nb.get(p) in spec["branches"]} | {ij_b}
        rep = next((p for p in ("day", "month", "hour", "year") if nb.get(p) in spec["branches"]), None)
        if len(distinct) == 3 and rep:
            add("branch", "direction_group", rep, nb[rep], elem, transformed=elem, status="formed",
                note=f"방국 {elem}局 완성")

    # ── 형(삼형 반형/완성 · 상형 · 자형) ──
    for trio in HYEONG["삼형"]:
        if ij_b not in trio:
            continue
        members = [(p, nb[p]) for p in POS_ORDER if nb.get(p) in trio]
        distinct = {b for _, b in members} | {ij_b}
        rep = next((p for p, _ in members), None)
        if rep and len(distinct) >= 2:
            add("branch", "punishment", rep, nb[rep], BRANCH_ATTR[nb[rep]]["element"],
                note="삼형 완성" if len(distinct) == 3 else "반형(삼형 2자)")
    for pair in HYEONG["상형"]:
        if ij_b not in pair:
            continue
        other = pair[0] if pair[1] == ij_b else pair[1]
        for p in POS_ORDER:
            if nb.get(p) == other:
                add("branch", "punishment", p, other, BRANCH_ATTR[other]["element"], note="상형(子卯)")
    if ij_b in SELF_PUNISH:
        for p in POS_ORDER:
            if nb.get(p) == ij_b:
                add("branch", "punishment", p, ij_b, BRANCH_ATTR[ij_b]["element"], note="자형(동일 지지)")

    # ── 천간: 천간합 또는 透出 ──
    stem_done = False
    for pos, s in ns.items():
        if not s:
            continue
        key = tuple(sorted((ij_s, s)))
        if key in CHEONGANHAP_N:
            spec = CHEONGANHAP_N[key]
            elem = spec["element"]
            hua = any(x in spec["required_stems"] for x in ns.values() if x)  # 투출 요건(월령 비극제 §④-4 위임)
            add("stem", "stem_combine", pos, s, STEM_ATTR[s]["element"],
                transformed=(elem if hua else None), status=("hua" if hua else "no_hua"),
                note=f"천간합 {elem}({'化 성립' if hua else '合而不化'})")
            stem_done = True
            break
    if not stem_done:
        add("stem", "stem_exposed", "stem_self", ij_s, STEM_ATTR[ij_s]["element"],
            note="천간 透出(합·극 없음)")

    return out


def flow_signals_for_luck(fp, luck_ganji: str) -> List[FlowSignal]:
    """원국(fp) × 운 간지 2자 문자열(luck_ganji, 예 '甲寅') → FlowSignal 목록.
    대운·세운 공용(layer 구분은 emitter가 부여)."""
    ns = {"year": fp.year.ganji[0], "month": fp.month.ganji[0], "day": fp.day.ganji[0],
          "hour": fp.hour.ganji[0] if fp.hour else None}
    nb = {"year": fp.year.ganji[1], "month": fp.month.ganji[1], "day": fp.day.ganji[1],
          "hour": fp.hour.ganji[1] if fp.hour else None}
    return _detect(ns, nb, luck_ganji[0], luck_ganji[1])
