"""end-to-end handoff 골든 + no-new-values 분해 불변식 (P4 — 종착).

완전 assemble(엔진 raw + 고정 조각 + 고정 narrative)을 골든 동결하고, 산출의 모든 부분이
출처(엔진 raw·조각·canonical 정적·narrative·엔진 파생)로 환원됨을 증명(발명 ZERO).
직접 실행(pytest 미가용): PYTHONUTF8=1 PYTHONPATH=. py -m pytest tests/test_handoff_golden.py
"""
from __future__ import annotations

import json

import pytest

from tools import assemble_handoff as ah
from tools import handoff_verify as hv
from tools import handoff_static as hs
from tools import gen_golden_handoff as gg
from tests.corpus import build_case, TIER1_CASES


def _norm(s: str) -> str:
    return s.replace("\r\n", "\n").strip()


def _raw(label):
    return build_case(next(c for c in TIER1_CASES if c.label == label))


# ── 골든 회귀(완전 assemble 동결) ──────────────────────────────────
@pytest.mark.parametrize("label", gg.GOLDEN_CASES)
def test_golden_matches(label):
    text = json.dumps(gg.strip_static(gg.build_golden_handoff(label)), ensure_ascii=False, indent=2)
    golden = (gg.GOLDEN_DIR / f"{label}.json").read_text(encoding="utf-8")
    assert _norm(text) == _norm(golden), f"{label} 골든 드리프트 — gen_golden_handoff.py 재생성 필요"


# ── 정적 블록은 canonical 임베드 ───────────────────────────────────
@pytest.mark.parametrize("label", gg.GOLDEN_CASES)
def test_static_blocks_are_canonical(label):
    h = gg.build_golden_handoff(label)
    assert h["legend"] == hs.LEGEND
    assert h["spec"] == hs.SPEC
    assert h["consumer_scope"] == hs.CONSUMER_SCOPE
    assert h["reasoning_scaffold"] == hs.REASONING_SCAFFOLD


# ── no-new-values 분해: 모든 부분이 출처로 환원(발명 ZERO) ─────────
@pytest.mark.parametrize("label", gg.GOLDEN_CASES)
def test_no_new_values_decomposition(label):
    raw = _raw(label)
    h = gg.build_golden_handoff(label)
    # ① tier1 역법 사실·강약 canonical = 엔진 raw (round-trip)
    assert hv.verify_against_engine(h, raw) == []
    # ② 정적 블록·legend 코드 = canonical
    assert hv.validate_static_blocks(h) == []
    assert hv.validate_legend_codes(h) == []
    # ③ tier2 판정 = ASK 2~6 조각
    assert h["tier2_interpretation"]["pattern"]["code"] == "jong_gyeok"
    assert h["tier2_interpretation"]["yong_mechanism"] == ["suppress"]
    assert h["tier1_facts"]["flow"]["current_se_woon"]["year"] == 2026   # ASK6 조각
    assert h["tier1_facts"]["chart"]["branch_climate"]["month"]["temp"] == "warm"  # ASK2 조각
    # ④ day_master = 엔진 결정론 파생
    assert h["tier2_interpretation"]["day_master"]["stem"] == raw["chart"]["day"]["stem"]
    # ⑤ narrative = 격리 입력(LLM 산문)
    assert h["tldr"] == gg.FIXED_NARRATIVE["tldr"]
    assert h["methodology"] == gg.FIXED_NARRATIVE["methodology"]
    assert h["tier2_interpretation"]["yong_shen"]["usage_hint"] == gg.FIXED_NARRATIVE["usage_hints"]["yong_shen"]
    # ⑥ 구조 검증
    assert ah.validate(h) == []


# ── 완전 handoff 형상: load-bearing(결정론) + narrative(LLM) 분리 ──
def test_complete_handoff_shape():
    h = gg.build_golden_handoff("samhap_full")
    for k in ("schema", "meta", "legend", "spec", "consumer_scope", "reasoning_scaffold",
              "tier1_facts", "tier2_interpretation", "derived_lookup"):
        assert k in h, f"load-bearing 키 {k} 누락"
    for k in ("tldr", "methodology", "limits"):     # narrative(LLM 산문)
        assert k in h


def test_narrative_absent_yields_nulls():
    """narrative 미제공 시 산문 슬롯은 null(결정론 부분은 그대로) — 격리 확인."""
    raw = _raw("samhap_full")
    h = ah.assemble({"engine_tier1": raw, "tier2_fragments": gg.FIXED_FRAGMENTS})
    assert h["tldr"] is None and h["limits"] is None
    assert h["legend"] == hs.LEGEND                  # 결정론 부분은 narrative와 무관
    assert hv.verify_against_engine(h, raw) == []
