"""Step 11 — 매화역수 시간기점 산출 (§⑨-1·⑨-2·⑨-3, ASK 13 결정론부).

- 年數 = **음력 세차** 지지 순서수(KLC — 설날 경계. 입춘 기준 사주 년주와 다른 축임을 주의).
- 月數·日數 = KLC 음력 월(1~12)·일. **윤달 특칙 없음** — §⑨-2가 '월 (1~12)'로만 규정, 윤달도 월수 그대로
  (is_intercalation 플래그만 동봉 — 표기용).
- 時數 = hour_branch_divination(clock) 순서수 — 진태양시·DST 보정 비적용(§⑨-2 ⚠️, S2 매화측 확정).
- 검산 echo(KERNEL [1] 상속): 年/月/日/時數·중간합·上下卦수·動爻를 결과에 전부 동봉(암산 단정 금지).
- 작명 감사 3조(§⑨-2 v5.6.1): ① 괘명은 HEX_MATRIX lookup만 ② 純卦 앵커 ③ U+4DC0+(序−1) 직교 — 테스트 잠금.
- 互卦 = "(선택) MVP 출력 생략 가능" — 엔진은 산출(결정론 공짜), 스키마/골든 노출은 보류(C4 — Step 12 판단).
- 體用(§⑨-3): 動爻 든 괘 = 用, 用→體 방향 판정 → legend 코드.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Tuple

from korean_lunar_calendar import KoreanLunarCalendar

from saju_engine.assets.lookup.trigrams import TRIGRAMS
from saju_engine.assets.lookup.hexagrams import HEX_MATRIX
from saju_engine.constants import (
    BRANCH_INDEX, FIVE_CONTROLS, FIVE_GENERATES, MAEHWA_LINE_MOD, MAEHWA_TRIGRAM_MOD,
)
from saju_engine.engine.hour_branch import hour_branch_divination

_BIN2NAME = {v["binary"]: v["name"] for v in TRIGRAMS.values()}
_NAME2TRI = {v["name"]: v for v in TRIGRAMS.values()}


def ti_yong_verdict(ti_e: str, yong_e: str) -> str:
    """§⑨-3 — 用→體 방향: 用生體 大吉 / 比和 吉 / 體克用 小吉 / 體生用 설기 / 用克體 凶."""
    if FIVE_GENERATES[yong_e] == ti_e: return "yong_sheng_ti"
    if ti_e == yong_e: return "bi_he"
    if FIVE_CONTROLS[ti_e] == yong_e: return "ti_ke_yong"
    if FIVE_GENERATES[ti_e] == yong_e: return "ti_sheng_yong"
    return "yong_ke_ti"


@dataclass(frozen=True)
class Hexa:
    name: str
    no: int
    glyph: str


@dataclass(frozen=True)
class MaehwaResult:
    clock_dt: datetime
    lunar_year_ganji: str          # 세차 2자
    lunar_year_branch: str
    lunar_month: int
    lunar_day: int
    is_intercalation: bool
    year_n: int; month_n: int; day_n: int; hour_n: int          # 검산 echo
    sum_umd: int; sum_umdh: int                                  # 중간합 echo
    upper_n: int; lower_n: int; moving_line: int
    upper_trigram: str; lower_trigram: str
    ben: Hexa; zhi: Hexa; hu: Hexa                               # 互卦 = 선택 출력(엔진은 산출)
    ti_trigram: str; yong_trigram: str
    ti_element: str
    verdict: str                                                  # TiYongVerdict legend code


def _hexa(upper: str, lower: str) -> Hexa:
    c = HEX_MATRIX[(upper, lower)]
    return Hexa(name=c["name"], no=c["no"], glyph=c["glyph"])


def cast_maehwa(clock_dt: datetime) -> MaehwaResult:
    c = KoreanLunarCalendar()
    assert c.setSolarDate(clock_dt.year, clock_dt.month, clock_dt.day), f"KLC 범위 밖: {clock_dt.date()}"
    chi = c.getChineseGapJaString()
    year_gz = chi.split()[0][:2]
    iso = c.LunarIsoFormat()
    lm, ld = int(iso[5:7]), int(iso[8:10])
    inter = "Intercalation" in iso

    yn = BRANCH_INDEX[year_gz[1]] + 1
    hn = BRANCH_INDEX[hour_branch_divination(clock_dt)] + 1
    s1, s2 = yn + lm + ld, yn + lm + ld + hn
    up_n = s1 % MAEHWA_TRIGRAM_MOD or 8
    low_n = s2 % MAEHWA_TRIGRAM_MOD or 8
    mv = s2 % MAEHWA_LINE_MOD or 6

    up, low = TRIGRAMS[up_n]["name"], TRIGRAMS[low_n]["name"]
    ben = _hexa(up, low)
    lines = list(TRIGRAMS[low_n]["binary"] + TRIGRAMS[up_n]["binary"])   # 初→上
    lines[mv - 1] = "1" if lines[mv - 1] == "0" else "0"
    zhi = _hexa(_BIN2NAME["".join(lines[3:6])], _BIN2NAME["".join(lines[0:3])])
    raw = TRIGRAMS[low_n]["binary"] + TRIGRAMS[up_n]["binary"]
    hu = _hexa(_BIN2NAME[raw[2:5]], _BIN2NAME[raw[1:4]])                 # 上互 3·4·5 / 下互 2·3·4

    yong, ti = (low, up) if mv <= 3 else (up, low)                       # 動爻 든 괘 = 用
    ti_e = _NAME2TRI[ti]["element"]
    return MaehwaResult(clock_dt=clock_dt, lunar_year_ganji=year_gz, lunar_year_branch=year_gz[1],
                        lunar_month=lm, lunar_day=ld, is_intercalation=inter,
                        year_n=yn, month_n=lm, day_n=ld, hour_n=hn, sum_umd=s1, sum_umdh=s2,
                        upper_n=up_n, lower_n=low_n, moving_line=mv,
                        upper_trigram=up, lower_trigram=low, ben=ben, zhi=zhi, hu=hu,
                        ti_trigram=ti, yong_trigram=yong, ti_element=ti_e,
                        verdict=ti_yong_verdict(ti_e, _NAME2TRI[yong]["element"]))
