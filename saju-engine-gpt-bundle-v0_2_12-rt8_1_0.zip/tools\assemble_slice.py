#!/usr/bin/env python3
"""모듈별 STAGE 슬라이스 추출기 — 2중 런타임 공용 단일 슬라이서.

한 ASK 모듈을 자기완결 system 프롬프트로 추출한다:
    SLICE = MODULE_PREAMBLE  (MODULE CONTRACT + §2 GLOBAL KERNEL + §① — 전 모듈 동일 = 캐시 prefix)
          + <ASK N> 본문
          + reads_reference 가 선언한 §섹션 (reference_tables.md)

수동 LEAN 모드(슬라이스를 새 턴에 붙여넣어 API 컨텍스트 재현)·미래 외부 오케스트레이터
(per-module API system 프롬프트)가 동일 슬라이서를 쓴다. reads_reference 는
gen_manifest.parse_contracts(ask_modules.md) 가 유일 SoT(매니페스트 캐시 비의존).

    python tools/assemble_slice.py ask_4         # ask_4 슬라이스를 stdout 출력
    python tools/assemble_slice.py --check        # 전 모듈 앵커·ref 해소 검증(실패 시 exit 1)

섹션 위치는 renumber-safe 앵커로 찾는다(헤더 워딩 변경에 불변):
  core_kernel.md:  <!--KERNEL-->…<!--/KERNEL-->,  <!--REF:§①-->…<!--/REF:§①-->
  ask_modules.md:  <!--MODULE_CONTRACT-->…<!--/MODULE_CONTRACT-->,  <ASK N>…</ASK N>
  reference_tables.md:  <!--REF:§X--> (다음 <!--REF: 앵커 또는 EOF 까지)
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
ENGINE_ROOT = HERE.parent.parent
REPO_ROOT = ENGINE_ROOT.parent
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

from tools import gen_manifest as gm  # noqa: E402  (reads_reference SoT)

CORE = REPO_ROOT / "core_kernel.md"
ASK = REPO_ROOT / "ask_modules.md"
REF = REPO_ROOT / "reference_tables.md"


def prompts_present() -> bool:
    """슬라이스 조립에 필요한 프롬프트 3파일 전부 존재 여부(가드 단일 SoT).

    번들-only 배포는 .md 부재 → 슬라이서·소비처(gen_tier2_boundary 등)가 이 술어로
    graceful skip한다. 부분 동봉(일부만 존재) 시 assemble_slice가 raw FileNotFoundError를
    내지 않도록 **3파일 모두**를 본다(소비처가 ask_modules.md 단독만 보면 불일치 발생)."""
    return ASK.exists() and CORE.exists() and REF.exists()

# reference_tables.md 에 앵커된 정규 §섹션(시리즈) — 등장 순서 무관, 앵커 id로 조회
_REF_SERIES = {"§②", "§③", "§③-2", "§④", "§⑤", "§⑦", "§⑧", "§⑨", "월간지표", "§⑩", "§⑪"}


# ───────────────────────── 추출 헬퍼 ─────────────────────────
def _between(text: str, start: str, end: str) -> str:
    i = text.find(start)
    if i == -1:
        raise KeyError(f"앵커 부재: {start}")
    j = text.find(end, i + len(start))
    if j == -1:
        raise KeyError(f"종료 앵커 부재: {end} (시작 {start} 이후)")
    return text[i + len(start):j].strip("\n")


def _ref_series(text: str, anchor_id: str) -> str:
    """<!--REF:{id}--> 부터 다음 <!--REF: 앵커(또는 EOF)까지."""
    start = f"<!--REF:{anchor_id}-->"
    i = text.find(start)
    if i == -1:
        raise KeyError(f"REF 앵커 부재: {start}")
    nxt = text.find("<!--REF:", i + len(start))
    body = text[i + len(start): nxt if nxt != -1 else len(text)]
    return body.strip("\n")


def _ask_body(text: str, module_id: str) -> str:
    tag = "ASK " + module_id[len("ask_"):].replace("_", "-")   # ask_7 → 'ASK 7'
    m = re.search(rf"(?s)<{re.escape(tag)}>.*?</{re.escape(tag)}>", text)
    if not m:
        raise KeyError(f"모듈 블록 부재: <{tag}>")
    return m.group(0).strip("\n")


def normalize_ref(entry: str) -> str | None:
    """reads_reference 항목 → 정규 앵커 id (§①/§②/…/§③-2/월간지표) 또는 None."""
    e = re.sub(r"^(Core|ref|reference_tables\.md)\s+", "", entry.strip())
    e = e.split("(")[0].strip()                       # 주석 제거
    if ("월간지" in e) or ("년도별" in e):
        return "월간지표"
    m = re.match(r"§(③-2|[①②③④⑤⑥⑦⑧⑨⑩⑪])", e)        # ③-2 를 ③ 보다 먼저
    if not m:
        return None
    base = m.group(1)
    return "§③-2" if base == "③-2" else "§" + base


# ───────────────────────── 조립 ─────────────────────────
def assemble_slice(module_id: str) -> str:
    contracts = gm.parse_contracts(ASK.read_text(encoding="utf-8"))
    if module_id not in contracts:
        raise KeyError(f"STAGE CONTRACT 부재: {module_id}")
    c = contracts[module_id]
    core_txt, ask_txt, ref_txt = (CORE.read_text(encoding="utf-8"),
                                  ASK.read_text(encoding="utf-8"),
                                  REF.read_text(encoding="utf-8"))

    preamble = "\n\n".join([
        _between(ask_txt, "<!--MODULE_CONTRACT-->", "<!--/MODULE_CONTRACT-->"),
        _between(core_txt, "<!--KERNEL-->", "<!--/KERNEL-->"),
        _between(core_txt, "<!--REF:§①-->", "<!--/REF:§①-->"),
    ])
    body = _ask_body(ask_txt, module_id)

    ref_blocks, seen = [], set()
    for r in c["reads_reference"]:
        cid = normalize_ref(r)
        if cid is None:
            raise ValueError(f"{module_id}: reads_reference 해소 불가 — {r!r}")
        if cid == "§①" or cid in seen:        # §①=preamble 에 이미 포함
            continue
        seen.add(cid)
        if cid not in _REF_SERIES:
            raise ValueError(f"{module_id}: 미지원 §섹션 — {cid} (from {r!r})")
        ref_blocks.append(_ref_series(ref_txt, cid))

    sep = "\n\n" + ("=" * 8) + "\n\n"
    out = [f"<!-- SLICE module={module_id} tier={c['tier']} -->",
           "<!-- ── MODULE_PREAMBLE (전 모듈 공통·캐시 prefix) ── -->", preamble,
           f"<!-- ── 모듈 본문 <{module_id}> ── -->", body]
    if ref_blocks:
        out += ["<!-- ── reads_reference §섹션 ── -->", "\n\n".join(ref_blocks)]
    return sep.join(out) + "\n"


def check_all() -> list[str]:
    """전 모듈 슬라이스 조립 가능성(앵커 존재·ref 해소·본문 존재) 검증."""
    errs: list[str] = []
    contracts = gm.parse_contracts(ASK.read_text(encoding="utf-8"))
    for mid in gm.BUILD_RANK:
        if mid not in contracts:
            errs.append(f"[누락] {mid} STAGE CONTRACT 없음"); continue
        try:
            s = assemble_slice(mid)
            if "<ASK " not in s or "MODULE CONTRACT" not in s or "GLOBAL KERNEL" not in s:
                errs.append(f"[불완전] {mid}: preamble/본문 결손")
        except (KeyError, ValueError) as e:
            errs.append(f"[조립실패] {mid}: {e}")
    return errs


def main(argv: list[str]) -> int:
    if not prompts_present():
        print("[skip] 프롬프트 .md 부재(번들-only 배포?) — 슬라이스 생략.")
        return 0
    if "--check" in argv:
        errs = check_all()
        n = len(gm.BUILD_RANK)
        print(f"[check] 모듈 {n}개 · 조립 {'전부 성공' if not errs else f'{len(errs)}건 실패'}")
        for e in errs:
            print("   " + e)
        return 1 if errs else 0
    targets = [a for a in argv if not a.startswith("-")]
    if len(targets) != 1:
        print("사용: python tools/assemble_slice.py <module_id>  |  --check")
        return 2
    try:
        sys.stdout.write(assemble_slice(targets[0]))
        return 0
    except (KeyError, ValueError) as e:
        print(f"[fail] {e}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
