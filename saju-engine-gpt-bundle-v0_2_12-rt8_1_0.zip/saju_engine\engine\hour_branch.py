"""Step 6 — 시지 함수 2종 (S2 / CONVENTIONS §3·§6).

모듈 수준 분리(D-026): natal(진태양시)과 divination(역법 시각)은 같은 경계 산식을 공유하되
서로 대체 호출 금지 — Step 7(월·시주)은 natal만, Step 11(매화)은 divination만 import한다.
인자명이 곧 계약이다: solar_dt를 받는 함수에 clock_dt를 넘기는 실수가 코드리뷰에서 보이도록.

경계: 반개구간 [시작,끝), 정각 = 다음 시진 (§2-2 — 05:00은 寅의 끝이 아니라 卯의 시작).
子시는 23시·0시 두 조각이며 일진 귀속과는 독립(S4 — 일진은 day_pillar 모듈이 clock 날짜로만 결정).
산식 ((h+1)//2) % 12 은 constants.HOUR_BRANCH_INTERVALS·§① 시각열과 1440분 전수 동치(테스트 잠금).
"""
from __future__ import annotations

from datetime import datetime

from saju_engine.constants import BRANCHES


def _branch_of_hour(h: int) -> str:
    return BRANCHES[((h + 1) // 2) % 12]


def hour_branch_natal(solar_dt: datetime) -> str:
    """사주 원국 시지 — 진태양시 전용 (§A6)."""
    return _branch_of_hour(solar_dt.hour)


def hour_branch_divination(clock_dt: datetime) -> str:
    """매화 時數용 시지 — 占은 역법 시각 기준, 진태양시 보정 미적용 (§⑨-2)."""
    return _branch_of_hour(clock_dt.hour)
