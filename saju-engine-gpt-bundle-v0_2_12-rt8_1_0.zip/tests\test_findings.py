"""R2 발견 잠복 결함 박제 — xfail(strict)로 추적.

각 결함은 '바라는 동작'을 단언하되 strict xfail로 표시한다. 결함이 고쳐지면
xfail이 '예기치 않게 통과'하고 strict가 이를 실패로 보고 → 마커 제거를 강제한다.
이로써 R2는 결함을 '발견 + 회귀 추적' 둘 다 한다.

발견 목록:
  F1  solar_terms.py 최상위 `import openpyxl` — emit standalone의 'stdlib-only' 계약 위반.
      (Code Interpreter엔 openpyxl이 있어 잠복. 순수 stdlib 환경에선 import 실패.)
  F2  run_emit.py가 LookupError만 포착 → 경도 범위밖·잘못된 성별의 ValueError가
      traceback째 누출(KERNEL ON_FAIL ⓔ '1줄 한국어 안내' 계약 위반). Feedback 별첨 건.
  F3  비-UTF8 Windows 로케일에서 CLI가 cp949 미수록 한자(爲·剝 등) 출력 시 크래시.
      → README 'Known portability' 참고. 본 파일은 UTF-8 양성 계약만 단언.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys

import pytest

from tests.conftest import ENGINE_ROOT

PY = sys.executable
CLI_ENV = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}


def _run_cli(*args):
    return subprocess.run([PY, "run_emit.py", *args], cwd=str(ENGINE_ROOT),
                          env=CLI_ENV, capture_output=True, text=True, encoding="utf-8")


# ── F1 (D-062 수정 완료 — xfail 해제) ─────────────────────────────
@pytest.mark.finding
def test_f1_solar_terms_stdlib_only():
    """solar_terms.py에 모듈-레벨 `import openpyxl`가 없어야 한다(쓰는 함수 안으로 지연)."""
    src = (ENGINE_ROOT / "saju_engine" / "assets" / "solar_terms.py").read_text(encoding="utf-8")
    module_level = []
    for line in src.splitlines():
        if re.match(r"^(def|class)\s", line):
            break
        if re.match(r"^import\s+openpyxl\b", line):
            module_level.append(line)
    assert not module_level, f"최상위 openpyxl import 존재: {module_level}"


# ── F2 (D-063 수정 완료 — xfail 해제) ─────────────────────────────
@pytest.mark.finding
def test_f2_longitude_out_of_range_no_traceback():
    r = _run_cli("1990-05-15T08:30", "F", "200")
    assert r.returncode != 0
    assert "Traceback" not in r.stderr, "경도 범위밖이 traceback째 누출(친화 1줄 안내여야 함)"
    assert "입력값 오류" in r.stderr


@pytest.mark.finding
def test_f2_bad_gender_no_traceback():
    r = _run_cli("1990-05-15T08:30", "X")
    assert r.returncode != 0
    assert "Traceback" not in r.stderr, "잘못된 성별이 traceback째 누출(친화 1줄 안내여야 함)"
    assert "입력값 오류" in r.stderr


@pytest.mark.finding
def test_f2_unparseable_input_no_traceback():
    """D-063: 잘못된 날짜/경도 문자열도 traceback 없이 1줄 안내."""
    r = _run_cli("not-a-date", "F")
    assert r.returncode != 0
    assert "Traceback" not in r.stderr
    assert "입력 파싱 불가" in r.stderr


# ── 양성 계약(통과해야 함) — 결함 박제와 대비되는 '정상 fail-loud' 잠금 ──
# ── F3 (D-068 수정 완료) — 비-UTF8 로케일 stdout 크래시 ───────────
# cp949 시뮬: PYTHONUTF8 제거 + PYTHONIOENCODING=cp949. 출력의 '—'(U+2014)가 cp949 미수록이라
# _force_utf8_io 없으면 UnicodeEncodeError로 크래시한다(전 모드 note/basis에 em-dash 존재).
CP949_ENV = {k: v for k, v in os.environ.items() if k != "PYTHONUTF8"}
CP949_ENV["PYTHONIOENCODING"] = "cp949"


def _run_cli_cp949(*args):
    return subprocess.run([PY, "run_emit.py", *args], cwd=str(ENGINE_ROOT),
                          env=CP949_ENV, capture_output=True, text=True, encoding="utf-8")


@pytest.mark.finding
@pytest.mark.parametrize("args,fence", [
    (["--jieqi", "2026"], "```jieqi_facts"),
    (["1990-05-15T08:30", "F", "--divination", "2026-06-14T14:00"], "```tier1_facts"),
    (["1990-05-15T08:30", "F"], "```tier1_facts"),
])
def test_f3_non_utf8_locale_no_crash(args, fence):
    """D-068: cp949 stdout에서도 _force_utf8_io로 크래시 없이 산출(PYTHONUTF8 불요)."""
    r = _run_cli_cp949(*args)
    assert r.returncode == 0, f"cp949 로케일 크래시: {r.stderr[:300]}"
    assert r.stdout.lstrip().startswith(fence)
    assert "UnicodeEncodeError" not in r.stderr


@pytest.mark.finding
def test_coverage_out_of_range_is_clean():
    """커버리지 밖(1949)은 LookupError가 포착되어 traceback 없이 1줄 한국어로 종료한다."""
    r = _run_cli("1949-05-15T08:30", "F")
    assert r.returncode != 0
    assert "Traceback" not in r.stderr
    assert ("절기 미수록" in r.stderr) or ("지원 출생 범위" in r.stderr)
