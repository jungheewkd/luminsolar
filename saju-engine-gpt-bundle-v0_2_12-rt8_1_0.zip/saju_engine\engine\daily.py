"""Step 12 — 일진×원국 일일 작용 신호 (divination.daily_signals) — §⑨-3-bis v2.

[경계 — D-057] 본 모듈은 *역법-구조* 사실까지만 소유한다(relations.py D-030 동일 철학):
  일진×원국 작용 탐지 · STAGE 1 상호해소(會局·탐합망충·합처봉충·충중봉합) · STAGE 2 작용형/旺衰/강도.
  부호(吉/凶/중립)는 용신 의존(tier2/ASK4) → 미산출. target_element만 넘기고 프롬프트가 입힌다(§⑨-3-bis v2 §4).
[旺衰] 대상(원국) = 12운성 band(STAGE_GROUP) 환산 / 일진 = 점단월 사령 旺相休囚死(_ryeong_state 복제).
  점단월 = st.prev_jie(divination_dt) 1회 lookup. 절기 커버리지 밖이면 iljin_wangshui=None·작용형 clash_even 강등(fail 안 함, §⑨-3-bis v2 §3-2).
[재사용] relations_tables lookup만 재사용 — detect_relations 전체 재사용 금지(원국 내부 중복 탐지 방지, 일진 1글자 스코프).
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional

from saju_engine.assets.lookup.attributes import BRANCH_ATTR, STEM_ATTR
from saju_engine.assets.lookup.relations_tables import (
    AMHAP, BANGGUK, CHEONGANHAP, HAE, HYEONG, PA, SAMHAP, YUKCHUNG, YUKHAP,
)
from saju_engine.assets.lookup.twelve_stages import STAGE_GROUP
from saju_engine.assets.solar_terms import JIE_TO_MONTH_BRANCH, SolarTerms
from saju_engine.constants import FIVE_CONTROLS, FIVE_GENERATES, HANJA2ELEM
from saju_engine.engine.day_pillar import day_pillar

POS_ORDER = ("year", "month", "day", "hour")
WANGJI = {"子", "午", "卯", "酉"}
T1_POS = {"day", "month"}                       # 근접 1급(일지·월지). 천간 신호도 T1.
SELF_PUNISH = set(HYEONG["자형"])
CHEONGANHAP_N = {tuple(sorted(k)): v for k, v in CHEONGANHAP.items()}
YUKHAP_N = {tuple(sorted(k)): v for k, v in YUKHAP.items()}
YUKCHUNG_N = {tuple(sorted(p)) for p in YUKCHUNG}
PA_N = {tuple(sorted(p)) for p in PA}
HAE_N = {tuple(sorted(p)) for p in HAE}
AMHAP_N = {tuple(sorted(p)) for p in AMHAP}
_BAND2WS = {"生旺祿": "wang", "中立": "jung", "衰絶期": "soe"}
_RYEONG2WS = {"旺": "wang", "相": "wang", "休": "jung", "囚": "soe", "死": "soe"}
_STRONG_HAP = {"combine_3", "direction_group", "combine_6", "stem_combine"}  # 탐합 자격(암합 제외)


@dataclass(frozen=True)
class DailySignal:
    channel: str
    type: str
    iljin_char: str
    target_position: str
    target_char: str
    target_element: str
    transformed_element: Optional[str]
    action: str
    magnitude_class: str
    position_tier: str
    iljin_wangshui: Optional[str]
    target_wangshui: Optional[str]
    action_basis: str
    resolution: str
    basis: str


def _ryeong_state(day_e: str, month_e: str) -> str:
    """strength._ryeong_state 복제(private import 회피, S8 단일정의는 향후 승격 검토)."""
    if day_e == month_e: return "旺"
    if FIVE_GENERATES[month_e] == day_e: return "相"
    if FIVE_GENERATES[day_e] == month_e: return "休"
    if FIVE_CONTROLS[day_e] == month_e: return "囚"
    return "死"


def _div_month_elem(divination_dt: datetime, st: SolarTerms) -> Optional[str]:
    try:
        jie, _ = st.prev_jie(divination_dt)
    except (LookupError, KeyError, ValueError, IndexError):
        return None
    return BRANCH_ATTR[JIE_TO_MONTH_BRANCH[jie]]["element"]


def _ij_ws(elem_hanja: str, month_e: Optional[str]) -> Optional[str]:
    return None if month_e is None else _RYEONG2WS[_ryeong_state(elem_hanja, month_e)]


def _tg_ws(stage_ko: Optional[str]) -> Optional[str]:
    if not stage_ko:
        return None
    return _BAND2WS.get(STAGE_GROUP.get(stage_ko, ""), None)


def _tier(pos: str, channel: str) -> str:
    if channel == "stem":
        return "T1"
    return "T1" if pos in T1_POS else "T2"


def daily_signals_for_chart(fp, cf, divination_dt: datetime, st, rels):
    """반환 (survived: List[DailySignal], voided: List[DailySignal], meta: dict)."""
    nb = {"year": fp.year.ganji[1], "month": fp.month.ganji[1], "day": fp.day.ganji[1],
          "hour": fp.hour.ganji[1] if fp.hour else None}
    ns = {"year": fp.year.ganji[0], "month": fp.month.ganji[0], "day": fp.day.ganji[0],
          "hour": fp.hour.ganji[0] if fp.hour else None}
    stage = {"year": cf.year.twelve_stage, "month": cf.month.twelve_stage,
             "day": cf.day.twelve_stage, "hour": cf.hour.twelve_stage if fp.hour else None}
    dg = day_pillar(divination_dt.date())
    ij_s, ij_b = dg[0], dg[1]
    month_e = _div_month_elem(divination_dt, st)
    ij_b_ws = _ij_ws(BRANCH_ATTR[ij_b]["element"], month_e)
    ij_s_ws = _ij_ws(STEM_ATTR[ij_s]["element"], month_e)
    natal_stem_elems = {STEM_ATTR[s]["element"] for s in ns.values() if s}

    # 원국 내부 합/충 위치 집합 (S3/S4 참조)
    clash_pos = {p for h in rels if h.type == "clash" for p in h.positions}
    combine_pos = {p for h in rels if h.type in ("combine_6", "combine_3", "direction_group") for p in h.positions}

    # ── 탐지: 일진 지지 × 원국 지지 (쌍 작용) ──
    cand: List[dict] = []   # {channel,type,pos,target,members,elem,transformed,...}
    for pos, b in nb.items():
        if not b:
            continue
        key = tuple(sorted((ij_b, b)))
        if key in YUKHAP_N:
            raw = YUKHAP_N[key]
            cands = [c for c in raw if c in "木火土金水"]
            tr = next((c for c in cands if c in natal_stem_elems), None)  # 투출 only(월령 화기는 프롬프트 §④-4 정밀화)
            cand.append(dict(channel="branch", type="combine_6", pos=pos, target=b,
                             elem=BRANCH_ATTR[b]["element"], transformed=tr,
                             note="화기 성립(투출)" if tr else "합거(투출 미충족 — 월령 화기 §④-4 위임)"))
        if key in YUKCHUNG_N:
            cand.append(dict(channel="branch", type="clash", pos=pos, target=b,
                             elem=BRANCH_ATTR[b]["element"], transformed=None, note="육충"))
        if key in PA_N:
            cand.append(dict(channel="branch", type="break", pos=pos, target=b,
                             elem=BRANCH_ATTR[b]["element"], transformed=None, note="파(tier4)"))
        if key in HAE_N:
            cand.append(dict(channel="branch", type="harm", pos=pos, target=b,
                             elem=BRANCH_ATTR[b]["element"], transformed=None, note="해(tier4)"))
        if key in AMHAP_N:
            cand.append(dict(channel="branch", type="hidden_combine", pos=pos, target=b,
                             elem=BRANCH_ATTR[b]["element"], transformed=None, note="암합(§④-5)"))

    # ── 삼합/방국 (일진 지지 + 원국 지지들) ──
    huiju_branches = set()   # 會局 참여 지지(S1 voiding 대상)
    for elem, spec in SAMHAP.items():
        if ij_b not in spec["branches"]:
            continue
        members = [(p, nb[p]) for p in POS_ORDER if nb.get(p) in spec["branches"]]
        distinct = {b for _, b in members} | {ij_b}
        tu = any(STEM_ATTR[s]["element"] == elem for s in ns.values() if s)
        rep = next((p for p in ("day", "month", "hour", "year") if nb.get(p) in spec["branches"]), None)
        if len(distinct) == 3 and rep:
            huiju_branches |= distinct
            cand.append(dict(channel="branch", type="combine_3", pos=rep, target=nb[rep],
                             elem=HANJA2ELEM[elem], transformed=HANJA2ELEM[elem], status="formed",
                             note=f"삼합 {elem}局 완성({'투출' if tu else '미투출'})"))
        elif len(distinct) == 2 and (distinct & WANGJI) and rep:
            huiju_branches |= distinct
            cand.append(dict(channel="branch", type="combine_3", pos=rep, target=nb[rep],
                             elem=HANJA2ELEM[elem], transformed=HANJA2ELEM[elem] if tu else None,
                             status="half", note=f"반합 {elem}局(왕지 포함, {'투출' if tu else '미투출'})"))
    for elem, spec in BANGGUK.items():
        if ij_b not in spec["branches"]:
            continue
        members = [(p, nb[p]) for p in POS_ORDER if nb.get(p) in spec["branches"]]
        distinct = {b for _, b in members} | {ij_b}
        rep = next((p for p in ("day", "month", "hour", "year") if nb.get(p) in spec["branches"]), None)
        if len(distinct) == 3 and rep:
            huiju_branches |= distinct
            cand.append(dict(channel="branch", type="direction_group", pos=rep, target=nb[rep],
                             elem=HANJA2ELEM[elem], transformed=HANJA2ELEM[elem], status="formed",
                             note=f"방국 {elem}局 완성"))

    # ── 형(삼형 반형/완성 · 상형 · 자형) ──
    for trio in HYEONG["삼형"]:
        if ij_b not in trio:
            continue
        members = [(p, nb[p]) for p in POS_ORDER if nb.get(p) in trio]
        distinct = {b for _, b in members} | {ij_b}
        rep = next((p for p, b in members), None)
        if rep and len(distinct) >= 2:
            cand.append(dict(channel="branch", type="punishment", pos=rep, target=nb[rep],
                             elem=BRANCH_ATTR[nb[rep]]["element"], transformed=None,
                             note="삼형 완성" if len(distinct) == 3 else "반형(삼형 2자)"))
    for pair in HYEONG["상형"]:
        if ij_b not in pair:
            continue
        other = pair[0] if pair[1] == ij_b else pair[1]
        for p in POS_ORDER:
            if nb.get(p) == other:
                cand.append(dict(channel="branch", type="punishment", pos=p, target=other,
                                 elem=BRANCH_ATTR[other]["element"], transformed=None, note="상형(子卯)"))
    if ij_b in SELF_PUNISH:
        for p in POS_ORDER:
            if nb.get(p) == ij_b:
                cand.append(dict(channel="branch", type="punishment", pos=p, target=ij_b,
                                 elem=BRANCH_ATTR[ij_b]["element"], transformed=None, note="자형(동일 지지)"))

    # ── 천간: 천간합 또는 透出 ──
    stem_done = False
    for pos, s in ns.items():
        if not s:
            continue
        key = tuple(sorted((ij_s, s)))
        if key in CHEONGANHAP_N:
            spec = CHEONGANHAP_N[key]
            elem = spec["element"]
            hua = any(x in spec["required_stems"] for x in ns.values() if x)  # 투출 요건(월령 비극제는 §④-4 위임)
            cand.append(dict(channel="stem", type="stem_combine", pos=pos, target=s,
                             elem=STEM_ATTR[s]["element"], transformed=(HANJA2ELEM[elem] if hua else None),
                             status=("hua" if hua else "no_hua"),
                             note=f"천간합 {elem}({'化 성립' if hua else '合而不化'})"))
            stem_done = True
            break
    if not stem_done:
        cand.append(dict(channel="stem", type="stem_exposed", pos="stem_self", target=ij_s,
                         elem=STEM_ATTR[ij_s]["element"], transformed=None, note="천간 透出(합·극 없음)"))

    # ── STAGE 1 해소 ──
    survived, voided = [], []
    branch_haps = [c for c in cand if c["channel"] == "branch" and c["type"] in _STRONG_HAP]
    branch_chungs = [c for c in cand if c["channel"] == "branch" and c["type"] == "clash"]
    has_strong_hap = bool(branch_haps)

    def emit(c, action, mag, action_basis, resolution, basis):
        elem_code = c["elem"] if c["elem"] in ("wood","fire","earth","metal","water") else HANJA2ELEM.get(c["elem"], c["elem"])
        tg_ws = _tg_ws(stage.get(c["pos"])) if c["pos"] in stage else None
        ij_ws = ij_s_ws if c["channel"] == "stem" else ij_b_ws
        sig = DailySignal(
            channel=c["channel"], type=c["type"], iljin_char=(ij_s if c["channel"] == "stem" else ij_b),
            target_position=c["pos"], target_char=c["target"], target_element=elem_code,
            transformed_element=c.get("transformed"), action=action, magnitude_class=mag,
            position_tier=_tier(c["pos"], c["channel"]), iljin_wangshui=ij_ws, target_wangshui=tg_ws,
            action_basis=action_basis, resolution=resolution, basis=basis)
        (survived if resolution == "survived" else voided).append(sig)

    for c in cand:
        t, pos = c["type"], c["pos"]
        # S1: 會局 참여 지지에 걸린 일진발 육합/육충 무효
        if has_strong_hap and t in ("combine_6", "clash") and c["target"] in huiju_branches:
            emit(c, "remove", "weak", "—", "voided_huiju_S1", f"S1 會局 우선 — {c['note']} 무효")
            continue
        # S3: 합 대상이 원국 내부에서 이미 충받음 → 合處逢沖. 단 會局(삼합·방국)은 견고(會局>沖)하여
        #     비왕지 한 글자 피충으로 깨지지 않으므로 약한 합(육합·암합)에만 적용(왕지 피충 시 약화는 §④ 위임 — 문서화 단순화).
        if t in ("combine_6", "hidden_combine") and pos in clash_pos:
            emit(c, "remove", "weak", "—", "voided_hapcheo_S3", f"S3 合處逢沖 — {c['target']} 원국 내 피충, 합 불성")
            continue
        # S4: 충 대상이 원국 내부에서 합으로 묶임 → 沖中逢合
        if t == "clash" and pos in combine_pos:
            emit(c, "clash_even", "weak", "—", "voided_chunghap_S4", f"S4 沖中逢合 — {c['target']} 원국 내 합, 충 해소")
            continue
        # S2: 일진 지지가 강한 합 + 충 동시 → 탐합망충(충 무효, 단 旺 대상은 弱발동 잔존)
        if t == "clash" and has_strong_hap:
            tg = _tg_ws(stage.get(pos))
            if tg == "wang":
                emit(c, "rouse", "weak", "S2 예외 — 旺 대상 충, 弱발동(부호는 프롬프트)", "survived",
                     "S2 탐합망충 예외 — 旺 대상이라 弱잔존")
            else:
                emit(c, "remove", "weak", "—", "voided_tanhap_S2", "S2 탐합망충 — 강한 합 우선, 충 무효")
            continue
        # ── 잔존 → STAGE 2 작용형/강도 분류 ──
        if t in ("combine_6", "combine_3", "direction_group"):
            mag = "mid" if c.get("status") == "half" else "strong"
            emit(c, "remove", mag, f"합 → 去/化 ({c['note']})", "survived", f"S5/S1 — {c['note']}")
        elif t == "hidden_combine":
            emit(c, "remove", "weak", "암합 → 弱去", "survived", f"S5 — {c['note']}")
        elif t == "clash":
            tg = _tg_ws(stage.get(pos)) or "jung"
            ij = ij_b_ws or "jung"
            if ij == "wang" and tg == "soe":
                emit(c, "remove", "strong", "旺者沖衰 → 衰者拔", "survived", "S5 — 일진발 단독 충")
            elif ij == "soe" and tg == "wang":
                emit(c, "rouse", "strong", "衰者沖旺 → 旺神發", "survived", "S5 — 일진발 단독 충")
            else:
                emit(c, "clash_even", "mid", f"동급 충({ij}·{tg}) → 動", "survived", "S5 — 일진발 단독 충")
        elif t == "punishment":
            emit(c, "friction", "weak", "형 → 마찰", "survived", f"S5 — {c['note']}")
        elif t in ("break", "harm"):
            emit(c, "friction", "weak", f"{c['note']} → 마찰", "survived", f"S5 — {c['note']}")
        elif t == "stem_combine":
            if c.get("status") == "hua":
                emit(c, "remove", "strong", "천간합 化 성립 → 化神", "survived", f"S6 — {c['note']}")
            else:
                emit(c, "remove", "weak", "合而不化 → 弱去", "survived", f"S6 — {c['note']}")
        elif t == "stem_exposed":
            emit(c, "expose", "mid", "천간 透出 → 일간 직접 작용", "survived", f"S6 — {c['note']}")

    meta = {"divination_month_branch": (JIE_TO_MONTH_BRANCH.get(st.prev_jie(divination_dt)[0])
                                        if month_e else None),
            "divination_month_element": (HANJA2ELEM[month_e] if month_e else None),
            "iljin_stem_element": HANJA2ELEM[STEM_ATTR[ij_s]["element"]],
            "iljin_branch_element": HANJA2ELEM[BRANCH_ATTR[ij_b]["element"]],
            "natal_relations_ref": "relations[]"}
    return survived, voided, meta
