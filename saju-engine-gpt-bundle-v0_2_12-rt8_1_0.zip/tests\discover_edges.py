"""엣지케이스 명식 발견기 — 코퍼스 확장용 유틸 (배포 비대상, 테스트 아님).

    python tests/discover_edges.py

build_tier1_dict를 결정론 그리드에 돌려 각 코드 경로(qi_xing·triggers·년지캡·
삼합 등)를 '실제로 타는' 입력을 버킷별로 수집한다. corpus.py의 핀 케이스는
모두 본 도구의 실측으로 골랐다 — 추측 금지. 새 회귀 케이스가 필요하면 여기서
후보를 찾아 corpus.TIER1_CASES에 추가하고 gen_golden.py로 베이스라인을 만든다.
"""
from __future__ import annotations

import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parent.parent
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

import json
from datetime import datetime
from tools.emit_tier1_standalone import build_tier1_dict

LIMIT = 4
buckets: dict[str, list] = {k: [] for k in (
    "qi_neither", "qi_only", "xing_only", "qi_both",
    "boundary_hold", "trig_a_numeric", "trig_c_day_clash", "trig_d_resource", "trig_e_climate",
    "year_cap_hit", "khc_clash_tie", "verdict_strong", "verdict_weak", "verdict_balanced",
    "samhap_full", "samhap_half", "void_present", "dst_applied",
    # ── tier2 boundary-증거 클래스 (가종/가격·순수 통관·교착 비등 raw 증거) ──
    "natal_contended",        # 쟁합(D-031) — 가종/가격·비등 정성판단의 원시 증거
    "combine_6_formed",       # 육합 성립 — 비등(육합∥삼합) 후보
    "stem_combine_formed",    # 천간합 성립 — 가합(false-combine) 증거
    "samhap_pure",            # 삼합 formed + 동일 명식 내 clash 無 — 순수 통관(samhap_full와 분리)
)}


def add(key, rec):
    if len(buckets[key]) < LIMIT:
        buckets[key].append(rec)


def want_more():
    return any(len(v) < LIMIT for v in buckets.values())


def main():
    count = 0
    for year in range(1952, 2035):
        for month in range(1, 13):
            for day in (1, 11, 21):
                for t in ("01:30", "08:30", "14:30", "23:30"):
                    for g in ("M", "F"):
                        try:
                            dt = datetime.fromisoformat(f"{year:04d}-{month:02d}-{day:02d}T{t}")
                            d = build_tier1_dict(dt, has_time=True, gender=g)
                        except Exception:
                            continue
                        count += 1
                        s, rels = d["strength"], d["relations"]
                        rel_sum = [f'{r["type"]}:{r["status"]}' for r in rels]
                        rec = {"birth": dt.isoformat(), "gender": g, "qi": s["qi_xing"],
                               "verdict": s["verdict_center"], "pct": s["strength_pct"],
                               "hold": s["boundary_hold"], "rels": rel_sum}
                        qi = s["qi_xing"]
                        add({"neither": "qi_neither", "qi_only": "qi_only",
                             "xing_only": "xing_only", "both": "qi_both"}[qi], rec)
                        if s["boundary_hold"]:
                            add("boundary_hold", rec)
                        tg = s["triggers"]
                        for tk, bk in (("a_numeric_band", "trig_a_numeric"),
                                       ("c_day_branch_clash", "trig_c_day_clash"),
                                       ("d_resource_excess", "trig_d_resource"),
                                       ("e_climate_nullified", "trig_e_climate")):
                            if tg.get(tk):
                                add(bk, rec)
                        if sum(r["adj"] for r in s["roots"] if r["position"] == "year") > 40:
                            add("year_cap_hit", rec)
                        if any(v["basis"] == "clash" for v in (s.get("khc_applied") or {}).values()):
                            add("khc_clash_tie", rec)
                        add({"strong": "verdict_strong", "weak": "verdict_weak",
                             "balanced": "verdict_balanced"}.get(s["verdict_center"], "qi_both"), rec)
                        samhap_formed = any(r["type"] == "combine_3" and r["status"] == "formed" for r in rels)
                        has_clash = any(r["type"] == "clash" for r in rels)
                        if samhap_formed:
                            add("samhap_full", rec)
                        if any(r["type"] == "combine_3" and r["status"] == "half" for r in rels):
                            add("samhap_half", rec)
                        # ── tier2 boundary-증거 클래스 ──
                        if any(r["status"] == "contended" for r in rels):
                            add("natal_contended", rec)
                        if any(r["type"] == "combine_6" and r["status"] == "formed" for r in rels):
                            add("combine_6_formed", rec)
                        if any(r["type"] == "stem_combine" and r["status"] == "formed" for r in rels):
                            add("stem_combine_formed", rec)
                        if samhap_formed and not has_clash:
                            add("samhap_pure", rec)
                        if d["void_branches"]:
                            add("void_present", rec)
                        if d["time_context"]["dst_applied"]:
                            add("dst_applied", rec)
            if not want_more():
                break
        if not want_more():
            break
    print(f"# 스캔 명식 수: {count}")
    for k, v in buckets.items():
        print(f"\n## {k}  (n={len(v)})")
        for rec in v[:2]:
            print("   ", json.dumps(rec, ensure_ascii=False))


if __name__ == "__main__":
    main()
