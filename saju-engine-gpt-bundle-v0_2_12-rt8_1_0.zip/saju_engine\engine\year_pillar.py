"""Step 4 — 년주 엔진 (§A1·§A2, CONVENTIONS §4·§8).

- 입춘 `>=` 소유 규칙 (D-003): boundary_dt >= 당해 입춘 → 당해, 미만 → 전년.
- S1 시그니처 강제: boundary_dt만 받는다 — clock/solar 오접속을 타입 수준에서 차단.
- 절기 제공자 주입(D-022): SolarTerms를 명시 인자로 — Step 14 ephemeris 교체 솔기.
- 커버리지 창(D-021): 1951-01-01 ~ 2035-12-31 (extended 로더, D-049 — 필요한 건 '당해 달력연도의
  입춘' 단 하나. 1951년 1월 출생은 lichun(1951)로 판정해 effective 1950이 되므로 유효).
  창 밖 → SolarTerms가 LookupError로 fail-loud ("2026 절벽"은 D-049로 2035까지 이연).
  ※ 파이프라인 전체 가용 시작은 1951-01-06 12:31(소한) — 그 이전 1월 출생은 월주 prev_jie 부재로
    fail-loud (1948~1950 미지원: 검증된 절기 데이터 부재 — Step 0-A 문구 정정은 P2 소관).
- derivation echo 의미론(D-021): lichun_dt = *판정 기준*이 된 당해 달력연도 입춘
  (effective가 전년이어도 비교에 쓰인 입춘을 echo — 검산 블록 표시용).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Tuple

from saju_engine.assets.solar_terms import SolarTerms
from saju_engine.constants import sexagenary_from_index, year_sexagenary_index


@dataclass(frozen=True)
class YearPillarResult:
    ganji: str
    index: int
    effective_year: int
    lichun_dt: datetime  # 판정 기준 입춘 (당해 달력연도)


def effective_saju_year(boundary_dt: datetime, st: SolarTerms) -> Tuple[int, datetime]:
    """명리학적 유효 연도. CONVENTIONS §4: `boundary_dt >= 입춘` → 새 해 소유."""
    lichun = st.lichun(boundary_dt.year)
    eff = boundary_dt.year if boundary_dt >= lichun else boundary_dt.year - 1
    return eff, lichun


def year_pillar_for_birth(boundary_dt: datetime, st: SolarTerms) -> YearPillarResult:
    eff, lichun = effective_saju_year(boundary_dt, st)
    idx = year_sexagenary_index(eff)
    return YearPillarResult(ganji=sexagenary_from_index(idx), index=idx,
                            effective_year=eff, lichun_dt=lichun)
