"""assemble_slice CI 게이트 — 전 모듈 슬라이스 조립 가능성·구조·최소 컨텍스트 단언.

직접 실행(pytest 미가용 환경):  python tools/assemble_slice.py --check
"""
from __future__ import annotations

import pytest

from tools import assemble_slice as asl

pytestmark = pytest.mark.skipif(
    not (asl.ASK.exists() and asl.CORE.exists() and asl.REF.exists()),
    reason="프롬프트 .md 부재(번들-only 배포)",
)

MODULES = ["ask_1", "ask_2", "ask_3", "ask_4", "ask_5", "ask_6", "ask_7"]


def test_all_modules_assemble_clean():
    assert asl.check_all() == []


@pytest.mark.parametrize("mid", MODULES)
def test_slice_carries_preamble_and_body(mid):
    s = asl.assemble_slice(mid)
    tag = "ASK " + mid[len("ask_"):].replace("_", "-")
    for marker in ("MODULE CONTRACT", "GLOBAL KERNEL", "### ① 천간", f"<{tag}>"):
        assert marker in s, f"{mid} 슬라이스에 {marker!r} 결손"


def test_lean_module_excludes_unneeded_sections():
    """최소-컨텍스트 불변식: ask_5(병약, lookup 0)는 §④/§⑦/§⑨/§⑩을 끌어오지 않는다."""
    s = asl.assemble_slice("ask_5")
    for h in ("### ④ 합충", "### ⑦ 고전", "### ⑨ 주역", "### ⑩ 신살"):
        assert h not in s, f"ask_5 슬라이스가 불필요 섹션 {h!r} 포함(과대 번들 — fidelity leak)"


def test_ref_normalization():
    assert asl.normalize_ref("Core §①") == "§①"
    assert asl.normalize_ref("ref §③-2-ⓐ (생명력 밴드 PRIMARY)") == "§③-2"
    assert asl.normalize_ref("reference_tables.md §⑦ (⑦-0-1·⑦-3)") == "§⑦"
    assert asl.normalize_ref("ref §년도별 월간지 표") == "월간지표"
